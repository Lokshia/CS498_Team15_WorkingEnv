# Team15 无视觉托箱：真机控制适配候选

先给 TA 看 deployment/hardware_bridge/docs/TA_QUESTIONS_ZH.md（或英文版）。
安装与运行看 deployment/hardware_bridge/README_ZH.md。

保留 deployment/hardware_bridge 与 deployment/team15_proprio_package 并排结构。
默认运行只做离线预检。现场参数模板未填写；不能直接启动真实机器人。
76项软件测试及新动作链3次20秒0.5kg部署仿真通过；未连接真实机器人。
本包具备电机命令和模式切换代码，必须完成现场配置、标定和TA主持的测试后使用。
