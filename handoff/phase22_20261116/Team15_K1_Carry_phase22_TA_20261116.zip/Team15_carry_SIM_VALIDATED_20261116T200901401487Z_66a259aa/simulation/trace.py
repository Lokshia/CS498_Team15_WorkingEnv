"""Map native single-episode measurements to the formal training scorer schema."""
from __future__ import annotations
import numpy as np
from .qualification import qualify


NATIVE_FIELDS = {
    'command':'command', 'base_velocity':'base_linear_velocity_b',
    'base_position':'base_position_w', 'valid_hold':'valid_hold',
    'robot_tilt_deg':'trunk_tilt_deg', 'robot_force_n':'external_trunk_force_n',
    'box_force_n':'external_box_force_n', 'target':'joint_target', 'qd':'joint_velocity',
    'foot_contact':'foot_contact', 'foot_force':'foot_force_n', 'obs_actor':'obs_actor',
}


def native_trace(rows):
    """One original episode: never reset, concatenate, relabel, or omit rows."""
    trace={'time_s':np.asarray([row['time_s'] for row in rows],dtype=np.float64),
           'active_original_episode':np.ones((len(rows),1),dtype=bool)}
    for target,source in NATIVE_FIELDS.items():
        trace[target]=np.asarray([row[source] for row in rows])[:,None,...]
    for target,source in (('requested_command','requested_command'),('q','joint_position'),('foot_position_w','foot_position_w'),('foot_velocity_w','foot_velocity_w')):
        if rows and source in rows[0]:trace[target]=np.asarray([row[source] for row in rows])[:,None,...]
    # Only explicitly braced episodes have these measured fields. Never
    # fabricate support load fractions for archived strict-policy traces.
    for key in ('arm_force_n','trunk_force_n','arm_load_share','total_arm_load_share',
                'trunk_load_share','reference_load_n','actual_payload_mass_kg',
                'left_forearm_contact','right_forearm_contact','payload_disallowed_contact'):
        if rows and key in rows[0]:
            trace[key]=np.asarray([row[key] for row in rows])[:,None,...]
    return trace


def qualify_native(rows, evaluation):
    trace=native_trace(rows)
    result=qualify(trace,evaluation)
    return trace,result
