"""Qualify saved carry-walk traces without running a simulator or changing training.

The old evaluation.json success field is diagnostic only. This scorer requires
the original episode, real commanded progress, exercised disturbances and a
complete recovery window. It never joins successful reset fragments together.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np

SCHEMA = "team15-carry-qualification-v1"
BRACED_SCHEMA = "team15-braced-carry-qualification-v1"
NATIVE_BRACED_SCHEMA = "team15-native-braced-carry-qualification-v1"
BRACED_PROFILES = ("braced_contact_v1", "braced_contact_native_v1")
QUALIFICATION_METHODS = ("instantaneous_v1", "walking_window_v2", "walking_recovery_window_v3")
WALKING_WINDOW_S = 1.0
RECOVERY_WINDOW_CRITERIA = {
    "moving_average_window_s": 1.0,
    "command_constancy_tolerance": 1e-6,
    "method": "For a fully moving, constant-command recovery interval, norm of signed XY error means in complete contiguous 1 s windows; standing remains raw",
    "mixed_commands": "Rejected, including start/stop, speed or direction transitions; no selective moving fragments",
    "raw_diagnostics_required": True,
}
STOPPING_CRITERIA = {
    "zero_command_tolerance": 1e-6,
    "settling_time_s": 1.0,
    "minimum_scoring_duration_s": 2.0,
    "method": "Raw samples after each post-movement zero-command transition; no velocity/yaw averaging",
}
BRACED_CRITERIA = {
    "support_start_s": 2.0,
    "minimum_support_observation_s": 2.0,
    "total_arm_load_share_p05_min": 0.5,
    "per_arm_load_share_p05_min": 0.1,
    "maximum_consecutive_low_support_steps": 6,
    "support_groups": {"left": ["left_hand_collision", "left_hand_end_collision"],
                       "right": ["right_hand_collision", "right_hand_end_collision"]},
    "allowed_brace_geoms": ["trunk_collision"],
    "denominator": "actual_payload_mass_kg * actual_gravity_m_s2 + max(-applied_box_force_world_z_n, 0)",
    "interpretation": "Quasi-static reference load, not an exact dynamic load partition; ratios may exceed one during acceleration",
}
NATIVE_BRACED_CRITERIA = {
    **BRACED_CRITERIA,
    "support_groups": {"left": ["left_hand_collision"], "right": ["right_hand_collision"]},
    "allowed_brace_geoms": ["trunk_collision", "trunk_lower_collision"],
    "geometry_source": "official_k1_mesh",
}
MOTION_DIAGNOSTICS = {
    "steady_start_s": 3.0,
    "minimum_spectral_duration_s": 3.0,
    "spectral_band_hz": [8.0, 20.0],
    "spectral_reference_band_hz": [0.5, 24.0],
    "method": "Mean-removed Hann-window Welch PSD, up to 256 samples/segment, 50% overlap, 50Hz control-rate traces",
    "hard_gate": False,
}
CRITERIA = {
    "steady_start_s": 3.0,
    "moving_command_threshold_m_s": 0.005,
    "min_moving_duration_s": 2.0,
    "max_vector_velocity_rmse_floor_m_s": 0.02,
    "max_vector_velocity_rmse_fraction": 0.5,
    "minimum_directed_progress_fraction": 0.6,
    "minimum_moving_fraction": 0.8,
    "moving_fraction_speed_fraction": 0.25,
    "standing_max_velocity_rmse_m_s": 0.05,
    "standing_max_xy_drift_m": 0.10,
    "max_trunk_tilt_p95_deg": 10.0,
    "max_trunk_tilt_deg": 20.0,
    "max_yaw_rate_rmse_rad_s": 0.15,
    "force_impulse_ratio_range": [0.8, 1.2],
    "force_peak_ratio_range": [0.8, 1.05],
    "recovery_start_after_force_s": 0.5,
    "recovery_end_after_force_s": 2.0,
    "recovery_velocity_error_p95_floor_m_s": 0.05,
    "recovery_velocity_error_p95_fraction": 0.5,
    "contact_min_airtime_s": 0.04,
    "landing_force_window_s": 0.06,
}


def _rms_vector(values):
    return float(np.sqrt(np.mean(np.sum(np.square(values), axis=-1))))


def _walking_window_means(values, moving, dt):
    """Complete contiguous 1 s windows; never concatenate separate moving bouts."""
    count = round(WALKING_WINDOW_S / dt)
    if count < 1 or not math.isclose(count*dt, WALKING_WINDOW_S, abs_tol=1e-8):
        raise ValueError("Walking window must contain an integer number of control intervals")
    values = np.asarray(values, dtype=float)
    if len(values) < count:
        return np.empty((0,)+values.shape[1:])
    sums = np.concatenate((np.zeros((1,)+values.shape[1:]), np.cumsum(values, axis=0)))
    eligible = np.convolve(np.asarray(moving, dtype=int), np.ones(count, dtype=int), mode="valid") == count
    return ((sums[count:]-sums[:-count])/count)[eligible]


def _stopping(data, time_s, dt, complete):
    """Check each full zero-command bout after movement, without smoothing."""
    cmd=data("command");vel=data("base_velocity");pos=data("base_position")
    zero=np.linalg.norm(cmd,axis=-1)<=STOPPING_CRITERIA["zero_command_tolerance"]
    moving=np.linalg.norm(cmd[:,:2],axis=-1)>CRITERIA["moving_command_threshold_m_s"]
    after_moving=np.maximum.accumulate(moving)
    requested=zero & after_moving
    if not requested.any():
        return {"requested":False,"passed":None,"status":"not_requested","bouts":[]}
    padded=np.r_[False,requested,False].astype(int)
    starts=np.flatnonzero(np.diff(padded)==1);ends=np.flatnonzero(np.diff(padded)==-1)
    settle=round(STOPPING_CRITERIA["settling_time_s"]/dt)
    minimum=round(STOPPING_CRITERIA["minimum_scoring_duration_s"]/dt)
    bouts=[]
    for start,end in zip(starts,ends):
        first=start+settle
        enough=end-first>=minimum
        row={"zero_command_start_s":float(time_s[start]-dt),"zero_command_duration_s":float((end-start)*dt),
             "settling_time_s":STOPPING_CRITERIA["settling_time_s"],
             "scored_duration_s":float(max(0,end-first)*dt),"enough_samples":bool(enough),"passed":False}
        if first<end:
            indices=slice(first,end)
            rmse=_rms_vector(vel[indices,:2])
            drift=float(np.linalg.norm(pos[indices,:2]-pos[first,:2],axis=-1).max())
            tilt=data("robot_tilt_deg")[indices]
            yaw=float(np.sqrt(np.mean(data("obs_actor")[indices,2]**2)))
            posture=bool(np.quantile(tilt,.95)<=CRITERIA["max_trunk_tilt_p95_deg"] and tilt.max()<=CRITERIA["max_trunk_tilt_deg"])
            passed=bool(complete and enough and rmse<=CRITERIA["standing_max_velocity_rmse_m_s"]
                and drift<=CRITERIA["standing_max_xy_drift_m"] and posture and yaw<=CRITERIA["max_yaw_rate_rmse_rad_s"])
            row.update(passed=passed,raw_planar_velocity_rmse_m_s=rmse,max_xy_drift_m=drift,
                       posture_passed=posture,raw_yaw_rate_rmse_rad_s=yaw)
        bouts.append(row)
    passed=bool(all(row["passed"] for row in bouts))
    return {"requested":True,"passed":passed,"status":"passed" if passed else "failed","bouts":bouts,
            "interpretation":"Every post-movement zero-command bout needs 1 s settling plus at least 2 s of original raw samples; all remaining samples in that bout are scored."}


def _contact_profile(evaluation):
    declaration = evaluation.get("contact_schema")
    requested = evaluation.get("conditions", {}).get("contact_profile")
    if declaration is None:
        if requested not in (None, "forearms"):
            raise ValueError("Braced evaluation requires explicit contact_schema")
        return "strict_forearm_v1"
    if not isinstance(declaration, dict):
        raise ValueError("contact_schema must be an explicit object")
    profile = declaration.get("profile")
    if profile not in ("strict_forearm_v1", *BRACED_PROFILES):
        raise ValueError(f"Unknown contact schema: {profile}")
    if profile == "strict_forearm_v1" and requested not in (None, "forearms"):
        raise ValueError("Requested contact profile disagrees with contact schema")
    if profile in BRACED_PROFILES:
        native = profile == "braced_contact_native_v1"
        criteria = NATIVE_BRACED_CRITERIA if native else BRACED_CRITERIA
        if requested not in (None, "braced"):
            raise ValueError("Requested contact profile disagrees with contact schema")
        if declaration.get("schema_version") != (2 if native else 1):
            raise ValueError("Unsupported braced contact schema version")
        if declaration.get("support_groups") != criteria["support_groups"]:
            raise ValueError("Braced support groups differ from audited arm geoms")
        if declaration.get("brace_geoms") != criteria["allowed_brace_geoms"]:
            raise ValueError("Braced contact permits only the declared trunk geom")
        for field, expected in (("min_total_support_fraction", .5), ("min_per_arm_support_fraction", .1),
                                ("max_support_gap_steps", 6)):
            if declaration.get(field) != expected:
                raise ValueError(f"Braced contact threshold mismatch: {field}")
        if native and (declaration.get("geometry_source") != "official_k1_mesh"
                or declaration.get("support_force_threshold_n") != 1e-6
                or declaration.get("payload_attachment") != "free_body_no_weld_no_assistive_force"):
            raise ValueError("Native braced contact requires official geometry and measured free-body support")
    return profile


def _trace_validation(trace, evaluation):
    required = ("time_s", "active_original_episode", "command", "base_velocity",
                "base_position", "valid_hold", "robot_tilt_deg", "robot_force_n",
                "box_force_n", "target", "qd", "foot_contact", "foot_force", "obs_actor")
    missing = [key for key in required if key not in trace]
    if missing:
        raise ValueError(f"Missing trace fields: {missing}")
    t = np.asarray(trace["time_s"], dtype=float)
    dt = float(evaluation.get("control_dt_s", 0.02))
    if not math.isfinite(dt) or dt <= 0 or len(t) < 2:
        raise ValueError("A positive timestep and at least two trace rows are required")
    if not np.isfinite(t).all() or not np.allclose(t, np.arange(1, len(t)+1)*dt, rtol=0, atol=1e-6):
        raise ValueError("Trace must start at dt and have uniform control-interval timestamps")
    masks = np.asarray(trace["active_original_episode"], dtype=bool)
    if masks.ndim != 2 or masks.shape[0] != len(t):
        raise ValueError("Original-episode mask must have shape [time, environment]")
    if np.any(np.diff(masks.astype(int), axis=0) > 0):
        raise ValueError("Original episode reactivated after failure; reset fragments cannot be joined")
    if not masks[0].all():
        raise ValueError("Every slot must start with its original episode")
    if masks.shape[1] != int(evaluation["num_envs"]):
        raise ValueError("Environment count differs between trace and evaluation metadata")
    for key in required[2:]:
        values = np.asarray(trace[key])
        if values.shape[:2] != masks.shape:
            raise ValueError(f"Invalid time/environment axes for {key}")
        if not np.isfinite(values[masks]).all():
            raise ValueError(f"Nonfinite original-episode values in {key}")
    for key, suffix in (("q", (22,)), ("foot_position_w", (2, 3)), ("foot_velocity_w", (2, 3))):
        if key in trace:
            values = np.asarray(trace[key])
            if values.shape != masks.shape + suffix or not np.isfinite(values[masks]).all():
                raise ValueError(f"Invalid optional motion diagnostic field: {key}")
    expected = round(float(evaluation["seconds"]) / dt)
    if expected < 2 or not math.isclose(expected * dt, float(evaluation["seconds"]), abs_tol=1e-7):
        raise ValueError("Episode duration must be a multiple of the control timestep")
    if len(t) > expected:
        raise ValueError("Trace exceeds declared original episode duration")
    if _contact_profile(evaluation) in BRACED_PROFILES:
        braced_shapes = {"arm_force_n": (2, 3), "trunk_force_n": (3,), "actual_payload_mass_kg": (),
                         "reference_load_n": (), "arm_load_share": (2,), "total_arm_load_share": (),
                         "trunk_load_share": (), "left_forearm_contact": (), "right_forearm_contact": (),
                         "payload_disallowed_contact": ()}
        for key, suffix in braced_shapes.items():
            if key not in trace:
                raise ValueError(f"Braced trace lacks auditable field: {key}")
            values = np.asarray(trace[key])
            if values.shape != masks.shape + suffix or not np.isfinite(values[masks]).all():
                raise ValueError(f"Invalid braced trace field: {key}")
        if np.any(np.asarray(trace["actual_payload_mass_kg"])[masks] <= 0):
            raise ValueError("Actual payload mass must be strictly positive")
        gravity = evaluation.get("actual_gravity_m_s2")
        if not isinstance(gravity, (int, float)) or not math.isfinite(gravity) or gravity <= 0:
            raise ValueError("Braced evaluation must record positive actual_gravity_m_s2")
    return t, masks, dt, expected


def _braced_support(data, time_s, dt, gravity, complete, profile="braced_contact_v1"):
    arm_force = data("arm_force_n")
    trunk_force = data("trunk_force_n")
    actual_mass = data("actual_payload_mass_kg")
    downward_pressure = np.maximum(-data("box_force_n")[:, 2], 0)
    reference = actual_mass * gravity + downward_pressure
    upward = np.maximum(arm_force[:, :, 2], 0)
    shares = upward / reference[:, None]
    total = shares.sum(axis=-1)
    trunk_share = np.maximum(trunk_force[:, 2], 0) / reference
    # Recompute from raw N and kg, rather than trusting cached share values.
    for key, expected in (("reference_load_n", reference), ("arm_load_share", shares),
                          ("total_arm_load_share", total), ("trunk_load_share", trunk_share)):
        if not np.allclose(data(key), expected, rtol=2e-5, atol=2e-5):
            raise ValueError(f"Braced force/reference accounting mismatch: {key}")
    contacts = np.column_stack((data("left_forearm_contact"), data("right_forearm_contact"))).astype(bool)
    if np.any((~contacts) & (upward > 1e-5)):
        raise ValueError("Braced upward support force appears without recorded arm contact")
    steady = time_s >= BRACED_CRITERIA["support_start_s"]
    enough = steady.sum()*dt >= BRACED_CRITERIA["minimum_support_observation_s"]-1e-8
    summary = {"required": True, "passed": False, "contact_schema": profile,
               "support_start_s": BRACED_CRITERIA["support_start_s"],
               "observed_support_seconds": float(steady.sum()*dt), "enough_original_samples": bool(enough),
               "reference_load_formula": BRACED_CRITERIA["denominator"],
               "interpretation": BRACED_CRITERIA["interpretation"]}
    if not steady.any():
        summary["reason"] = "Original episode ended before support scoring window"
        return summary
    ss, ts = shares[steady], total[steady]
    threshold_total = BRACED_CRITERIA["total_arm_load_share_p05_min"]
    threshold_side = BRACED_CRITERIA["per_arm_load_share_p05_min"]
    p05_total = float(np.quantile(ts, .05))
    p05_sides = np.quantile(ss, .05, axis=0)
    good_sample = (ts >= threshold_total-1e-7) & (ss >= threshold_side-1e-7).all(axis=-1) & contacts[steady].all(axis=-1)
    longest = current = 0
    for ok in good_sample:
        current = 0 if ok else current+1
        longest = max(longest, current)
    forbidden = bool(data("payload_disallowed_contact").astype(bool).any())
    passed = bool(complete and enough and p05_total >= threshold_total-1e-7
                  and np.all(p05_sides >= threshold_side-1e-7)
                  and longest <= BRACED_CRITERIA["maximum_consecutive_low_support_steps"] and not forbidden)
    summary.update(passed=passed, total_arm_load_share_p05=p05_total,
        per_arm_load_share_p05=p05_sides.tolist(), total_arm_load_share_min=float(ts.min()),
        per_arm_load_share_min=ss.min(axis=0).tolist(), total_arm_load_share_mean=float(ts.mean()),
        per_arm_upward_force_mean_n=upward[steady].mean(axis=0).tolist(),
        total_arm_load_share_below_min_fraction=float(np.mean(ts<threshold_total)),
        per_arm_load_share_below_min_fraction=np.mean(ss<threshold_side, axis=0).tolist(),
        longest_consecutive_low_support_steps=int(longest), longest_consecutive_low_support_seconds=float(longest*dt),
        both_arm_contact_fraction=float(contacts[steady].all(axis=-1).mean()),
        payload_mass_min_max_kg=[float(actual_mass.min()), float(actual_mass.max())],
        reference_load_min_max_n=[float(reference[steady].min()), float(reference[steady].max())],
        downward_pressure_max_n=float(downward_pressure.max()),
        trunk_upward_load_share_mean=float(trunk_share[steady].mean()),
        trunk_upward_load_share_max=float(trunk_share[steady].max()),
        trunk_force_max_n=float(np.linalg.norm(trunk_force[steady], axis=-1).max()),
        forbidden_contact_seen=forbidden)
    return summary


def _foot_diagnostics(contact, force, dt, position=None, velocity=None):
    result = []
    for foot, label in enumerate(("left", "right")):
        c = contact[:, foot].astype(bool)
        fz = force[:, foot, 2]
        up = np.flatnonzero(c[:-1] & ~c[1:]) + 1
        down = np.flatnonzero(~c[:-1] & c[1:]) + 1
        landings = []
        for land in down:
            earlier = up[up < land]
            if len(earlier) == 0:
                continue
            airtime = (land - earlier[-1]) * dt
            if airtime + 1e-10 < CRITERIA["contact_min_airtime_s"]:
                continue
            stop = min(len(fz), land + max(1, round(CRITERIA["landing_force_window_s"] / dt)))
            event = {"time_s": float((land+1)*dt), "preceding_airtime_s": float(airtime),
                             "sampled_peak_vertical_force_n": float(fz[land:stop].max()),
                             "sampled_vertical_impulse_ns": float(np.maximum(fz[land:stop], 0).sum()*dt)}
            if position is not None:
                event["body_origin_planar_travel_m"] = float(np.linalg.norm(position[land, foot, :2]-position[earlier[-1], foot, :2]))
            landings.append(event)
        row = {"foot": label, "raw_liftoff_transitions": int(len(up)),
                       "raw_touchdown_transitions": int(len(down)), "qualified_contact_cycles": len(landings),
                       "ground_contact_fraction": float(c.mean()),
                       "sampled_vertical_force_max_n": float(fz.max()),
                       "sampled_loading_rate_max_n_s": float(np.maximum(np.diff(fz)/dt, 0).max()) if len(fz)>1 else 0.,
                       "landings": landings}
        if velocity is not None:
            grounded_speed = np.linalg.norm(velocity[c, foot, :2], axis=-1)
            row["grounded_body_origin_planar_speed_m_s"] = ({"rms": float(np.sqrt(np.mean(grounded_speed**2))),
                "p95": float(np.quantile(grounded_speed, .95)), "max": float(grounded_speed.max())} if len(grounded_speed) else None)
        result.append(row)
    return {"feet": result,
            "body_position_available": position is not None, "body_velocity_available": velocity is not None,
            "limitations": "Contact cycles/body-origin travel are diagnostics, not certified gait quality. Foot-body origin speed includes rotation about a planted contact and is not identical to contact-point slip. Forces sampled at control rate can miss substep impact peaks."}


def _spectrum(values, dt):
    sample_rate = 1.0/dt
    if len(values)*dt < MOTION_DIAGNOSTICS["minimum_spectral_duration_s"]-1e-8:
        return {"available": False, "reason": "Too little original steady data for frequency estimate"}
    if not math.isclose(sample_rate, 50., abs_tol=1e-6):
        return {"available": False, "reason": "Diagnostic protocol expects 50Hz control-rate trace"}
    segment_length = min(256, len(values))
    hop = max(1, segment_length//2)
    window = np.hanning(segment_length)
    segments = []
    for start in range(0, len(values)-segment_length+1, hop):
        segment = np.asarray(values[start:start+segment_length], dtype=float)
        transformed = np.fft.rfft((segment-segment.mean())*window)
        power = abs(transformed)**2 / (sample_rate*np.square(window).sum())
        power[1:-1 if segment_length % 2 == 0 else None] *= 2
        segments.append(power)
    psd = np.mean(segments, axis=0)
    freq = np.fft.rfftfreq(segment_length, dt)
    df = sample_rate/segment_length
    low, high = MOTION_DIAGNOSTICS["spectral_band_hz"]
    ref_low, ref_high = MOTION_DIAGNOSTICS["spectral_reference_band_hz"]
    band = (freq>=low)&(freq<=high)
    reference = (freq>=ref_low)&(freq<=ref_high)
    band_power = float(psd[band].sum()*df)
    reference_power = float(psd[reference].sum()*df)
    negligible = reference_power <= 1e-18
    return {"available": True, "sample_rate_hz": sample_rate, "samples": len(values),
            "frequency_resolution_hz": df, "segments": len(segments),
            "band_hz": [low, high], "reference_band_hz": [ref_low, ref_high],
            "band_power_fraction": 0. if negligible else band_power/reference_power,
            "band_rms_rad": float(math.sqrt(max(0.,band_power))),
            "reference_rms_rad": float(math.sqrt(max(0.,reference_power))),
            "negligible_reference_signal": negligible,
            "peak_in_band_hz": None if negligible else float(freq[band][np.argmax(psd[band])])}


def _ankle_motion(data, time_s, dt, evaluation, q_available):
    steady = time_s >= MOTION_DIAGNOSTICS["steady_start_s"]
    commands = data("command")[steady]
    moving = bool(len(commands) and np.any(np.linalg.norm(commands[:, :2], axis=-1)>.005))
    result = {"hard_gate": False, "condition": "walking_command" if moving else "standing_command",
              "steady_start_s": MOTION_DIAGNOSTICS["steady_start_s"], "steady_seconds": float(steady.sum()*dt),
              "protocol": MOTION_DIAGNOSTICS, "measured_q_available": q_available,
              "interpretation": "Compare standing and walking separately. Simulation 50Hz diagnostics are not directly amplitude-equivalent to the real-robot 500Hz state bag. A large ratio on a tiny signal is not by itself severe shaking."}
    names = evaluation.get("physical_contract", {}).get("joint_names")
    indexes = []
    if names:
        normalized = ["".join(x.lower().split("/")[-1].replace("_", "").replace("joint", "").split()) for x in names]
        for query in ("leftankleroll", "rightankleroll"):
            matches = [i for i,name in enumerate(normalized) if name==query]
            if len(matches)!=1:
                result.update(available=False, reason="Could not identify unique ankle-roll joints in physical contract")
                return result
            indexes.append(matches[0])
        result["joint_index_source"] = "physical_contract.joint_names"
    else:
        indexes = [15,21]
        result["joint_index_source"] = "Assumed canonical 22-joint K1 serial order; joint names absent"
    result["available"] = bool(steady.any())
    joints = []
    for side,index in zip(("left","right"),indexes):
        target = data("target")[steady,index]
        velocity = data("qd")[steady,index]
        delta = np.diff(target)
        absolute_stats = lambda value: ({"p95_abs":float(np.quantile(abs(value),.95)),"max_abs":float(abs(value).max())} if len(value) else None)
        row = {"side":side,"index":index,"target_delta_rad":absolute_stats(delta),
               "target_speed_rad_s":absolute_stats(delta/dt),
               "measured_velocity_rad_s":({"rms":float(np.sqrt(np.mean(velocity**2))),**absolute_stats(velocity)} if len(velocity) else None),
               "target_angle_spectrum":_spectrum(target,dt),
               "measured_angle_spectrum":_spectrum(data("q")[steady,index],dt) if q_available else {"available":False,"reason":"Measured q absent"}}
        joints.append(row)
    result["ankle_roll_joints"] = joints
    return result


def _disturbance(force, requested_peak, duration, t, dt, error, command_speed, tilt, valid_hold, kind, *, method="instantaneous_v1", command=None, original_complete=True):
    if requested_peak <= 0:
        return {"requested": False, "passed": None, "status": "not_requested"}
    mag = np.linalg.norm(force, axis=-1)
    hit = np.flatnonzero(mag > 1e-6)
    expected_impulse = requested_peak * duration / 2.0  # integral of sinÂ² pulse
    actual_impulse = float(mag.sum()*dt)
    peak = float(mag.max())
    reasons = []
    if not len(hit):
        return {"requested": True, "passed": False, "status": "not_exercised", "reasons": ["No nonzero applied force was recorded"],
                "expected_impulse_ns": expected_impulse, "actual_impulse_ns": actual_impulse}
    if kind == "push":
        direction_ok = bool(np.max(abs(force[:, 2])) <= max(1e-5, requested_peak*.01))
    else:
        direction_ok = bool(np.max(np.linalg.norm(force[:, :2], axis=-1)) <= max(1e-5, requested_peak*.01)
                            and np.max(force[:, 2]) <= 1e-5)
    impulse_ratio, peak_ratio = actual_impulse / expected_impulse, peak / requested_peak
    ir, pr = CRITERIA["force_impulse_ratio_range"], CRITERIA["force_peak_ratio_range"]
    exercised = bool(ir[0] <= impulse_ratio <= ir[1] and pr[0] <= peak_ratio <= pr[1] and direction_ok)
    if not exercised:
        reasons.append("Recorded pulse direction, peak or impulse differs from requested sin-squared pulse")
    end = float(t[hit[-1]])
    begin_recovery = end + CRITERIA["recovery_start_after_force_s"]
    end_recovery = end + CRITERIA["recovery_end_after_force_s"]
    window = (t >= begin_recovery-1e-8) & (t <= end_recovery+1e-8)
    required_samples = round((end_recovery-begin_recovery)/dt) + 1
    complete_window = bool(t[-1] >= end_recovery - dt*.1 and window.sum() >= required_samples-1)
    velocity_p95 = tilt_p95 = limit = raw_velocity_p95 = None
    recovery_method = "raw_instantaneous"
    complete_average_windows = None
    recovery_command_class = None
    recovery_eligible = True
    recovered = False
    if complete_window:
        raw_velocity_p95 = float(np.quantile(np.linalg.norm(error[window], axis=-1), .95))
        velocity_p95 = raw_velocity_p95
        if method == "walking_recovery_window_v3":
            if command is None or np.shape(command) != (len(t), 3):
                raise ValueError("V3 recovery requires recorded original XYZ command samples")
            moving = command_speed[window] > CRITERIA["moving_command_threshold_m_s"]
            constant = bool(np.max(abs(command[window]-command[window][0])) <= RECOVERY_WINDOW_CRITERIA["command_constancy_tolerance"])
            stationary = bool(np.max(abs(command[window])) <= RECOVERY_WINDOW_CRITERIA["command_constancy_tolerance"])
            if moving.all() and constant:
                recovery_command_class = "constant_moving"
                recovery_method = "signed_error_complete_1s_windows"
                # A row describes the preceding control interval. Both ends of
                # every averaged interval must lie inside the recovery window.
                full_intervals = (t-dt >= begin_recovery-1e-8) & (t <= end_recovery+1e-8)
                averaged = _walking_window_means(error, full_intervals, dt)
                complete_average_windows = len(averaged)
                velocity_p95 = float(np.quantile(np.linalg.norm(averaged, axis=-1), .95)) if len(averaged) else None
                recovery_eligible = bool(len(averaged))
                if not recovery_eligible:
                    reasons.append("No complete contiguous 1 s signed-error window inside recovery interval")
            elif not moving.any() and stationary:
                recovery_command_class = "standing"
            else:
                recovery_command_class = "mixed_or_changing_command"
                recovery_eligible = False
                reasons.append("V3 recovery rejects mixed or changing commands; it cannot select only convenient moving fragments")
            if not original_complete:
                recovery_eligible = False
                reasons.append("V3 recovery requires the complete original episode")
        tilt_p95 = float(np.quantile(tilt[window], .95))
        limit = max(CRITERIA["recovery_velocity_error_p95_floor_m_s"],
                    CRITERIA["recovery_velocity_error_p95_fraction"]*float(np.mean(command_speed[window])))
        recovered = bool(recovery_eligible and velocity_p95 is not None and velocity_p95 <= limit and tilt_p95 <= CRITERIA["max_trunk_tilt_p95_deg"] and valid_hold[window].all())
        if not recovered:
            reasons.append("Recovery velocity, trunk tilt or box-hold criterion failed")
    else:
        reasons.append("Original episode does not contain the entire recovery window")
    return {"requested": True, "passed": bool(exercised and complete_window and recovered),
            "status": "passed" if exercised and complete_window and recovered else "failed",
            "reasons": reasons, "direction_correct": direction_ok, "force_exercised": exercised,
            "peak_force_n": peak, "actual_impulse_ns": actual_impulse, "expected_impulse_ns": expected_impulse,
            "impulse_ratio": impulse_ratio, "first_nonzero_interval_end_s": float(t[hit[0]]),
            "last_nonzero_interval_end_s": end, "recovery_window_s": [begin_recovery, end_recovery],
            "recovery_window_complete": complete_window, "recovery_samples": int(window.sum()),
            "recovery_velocity_error_p95_m_s": velocity_p95, "recovery_velocity_error_limit_m_s": limit,
            "raw_recovery_velocity_error_p95_m_s": raw_velocity_p95,
            "recovery_error_method": recovery_method, "recovery_command_class": recovery_command_class,
            "complete_recovery_average_windows": complete_average_windows,
            "recovery_average_window_s": RECOVERY_WINDOW_CRITERIA["moving_average_window_s"] if recovery_method == "signed_error_complete_1s_windows" else 0.,
            "recovery_trunk_tilt_p95_deg": tilt_p95, "recovered": recovered}


def qualify(trace, evaluation):
    t, masks, dt, required = _trace_validation(trace, evaluation)
    method = evaluation.get("qualification_method", "instantaneous_v1")
    if method not in QUALIFICATION_METHODS:
        raise ValueError(f"Unknown qualification method: {method}")
    windowed = method in ("walking_window_v2", "walking_recovery_window_v3")
    profile = _contact_profile(evaluation)
    conditions = evaluation.get("conditions", {})
    source_episodes = {int(row["slot"]): row for row in evaluation.get("episodes", [])}
    results = []
    for j in range(masks.shape[1]):
        keep = masks[:, j]
        tt = t[keep]
        data = lambda key: np.asarray(trace[key])[keep, j]
        source = source_episodes.get(j, {})
        # The source flag is needed because a terminal event on the last row
        # otherwise has the same mask length as a completed episode.
        complete = bool(len(tt)==required and source.get("completed_without_termination") is True)
        valid_hold = data("valid_hold").astype(bool)
        hold = bool(complete and valid_hold.all())
        cmd, vel, pos = data("command"), data("base_velocity"), data("base_position")
        tilt = data("robot_tilt_deg")
        steady = tt >= CRITERIA["steady_start_s"]
        speed = np.linalg.norm(cmd[:, :2], axis=-1)
        moving = steady & (speed > CRITERIA["moving_command_threshold_m_s"])
        err = vel[:, :2] - cmd[:, :2]
        posture = bool(steady.any() and np.quantile(tilt[steady], .95) <= CRITERIA["max_trunk_tilt_p95_deg"]
                       and tilt[steady].max() <= CRITERIA["max_trunk_tilt_deg"])
        gyro_z = data("obs_actor")[:, 2]
        yaw_rmse = float(np.sqrt(np.mean((gyro_z[steady]-cmd[steady, 2])**2))) if steady.any() else None
        yaw_ok = bool(yaw_rmse is not None and yaw_rmse <= CRITERIA["max_yaw_rate_rmse_rad_s"])
        standing = {"requested": not moving.any(), "passed": None, "status": "not_requested"}
        walking = {"requested": bool(moving.any()), "passed": None, "status": "not_requested"}
        if moving.any():
            unit = cmd[moving, :2] / speed[moving, None]
            along = np.sum(vel[moving, :2]*unit, axis=-1)
            requested_path = float(speed[moving].sum()*dt)
            progress = float(along.sum()*dt)
            fraction = float(np.mean(along >= CRITERIA["moving_fraction_speed_fraction"]*speed[moving]))
            raw_rmse = _rms_vector(err[moving])
            raw_yaw_rmse = float(np.sqrt(np.mean((gyro_z[moving]-cmd[moving, 2])**2)))
            rmse = raw_rmse
            windows = None
            walk_yaw_rmse, walk_yaw_ok = yaw_rmse, yaw_ok
            if windowed:
                averaged = _walking_window_means(err, moving, dt)
                averaged_yaw = _walking_window_means(gyro_z-cmd[:, 2], moving, dt)
                windows = len(averaged)
                rmse = _rms_vector(averaged) if windows else None
                walk_yaw_rmse = float(np.sqrt(np.mean(averaged_yaw**2))) if windows else None
                walk_yaw_ok = bool(walk_yaw_rmse is not None and walk_yaw_rmse <= CRITERIA["max_yaw_rate_rmse_rad_s"])
            limit = max(CRITERIA["max_vector_velocity_rmse_floor_m_s"],
                        CRITERIA["max_vector_velocity_rmse_fraction"]*float(speed[moving].mean()))
            # World positions are sampled every .2 s to suppress high-frequency
            # jitter in path length. Signed direction is checked in body velocity.
            pp = pos[moving, :2]
            stride = max(1, round(.2/dt))
            sampled = pp[np.unique(np.r_[np.arange(0, len(pp), stride), len(pp)-1])]
            path = float(np.linalg.norm(np.diff(sampled, axis=0), axis=-1).sum())
            net = float(np.linalg.norm(pp[-1]-pp[0]))
            path_ok = path >= CRITERIA["minimum_directed_progress_fraction"]*requested_path
            # Constant straight commands additionally require net displacement.
            straight = bool(np.max(abs(cmd[moving, 2])) < .01 and np.max(np.linalg.norm(unit-unit[0], axis=-1)) < .05)
            if straight:
                path_ok = bool(path_ok and net >= CRITERIA["minimum_directed_progress_fraction"]*requested_path)
            passed = bool(complete and moving.sum()*dt >= CRITERIA["min_moving_duration_s"]
                          and rmse is not None and rmse <= limit and progress >= CRITERIA["minimum_directed_progress_fraction"]*requested_path
                          and fraction >= CRITERIA["minimum_moving_fraction"] and path_ok and posture and walk_yaw_ok)
            walking = {"requested": True, "passed": passed, "status": "passed" if passed else "failed",
                "moving_duration_s": float(moving.sum()*dt), "vector_velocity_rmse_m_s": rmse,
                "velocity_rmse_limit_m_s": limit, "requested_path_m": requested_path,
                "body_frame_directed_progress_m": progress, "progress_fraction": progress/requested_path,
                "moving_fraction": fraction, "sampled_world_path_m": path, "net_world_displacement_m": net,
                "straight_command_net_displacement_required": straight, "posture_passed": posture,
                "yaw_rate_rmse_rad_s": walk_yaw_rmse, "yaw_tracking_passed": walk_yaw_ok,
                "qualification_method": method, "tracking_window_s": WALKING_WINDOW_S if windowed else 0.,
                "complete_tracking_windows": windows, "raw_vector_velocity_rmse_m_s": raw_rmse,
                "raw_moving_yaw_rate_rmse_rad_s": raw_yaw_rmse,
                "mean_body_velocity_error_xy_m_s": err[moving].mean(axis=0).tolist(),
                "gait_quality": "Directed locomotion only; foot drag/step lengths cannot be verified from available trace fields"}
        else:
            rmse = _rms_vector(vel[steady, :2]) if steady.any() else None
            drift = float(np.linalg.norm(pos[steady, :2]-pos[steady, :2][0], axis=-1).max()) if steady.any() else None
            passed = bool(complete and steady.sum()*dt >= CRITERIA["min_moving_duration_s"] and rmse is not None
                          and rmse <= CRITERIA["standing_max_velocity_rmse_m_s"]
                          and drift <= CRITERIA["standing_max_xy_drift_m"] and posture and yaw_ok)
            standing = {"requested": True, "passed": passed, "status": "passed" if passed else "failed",
                        "vector_velocity_rmse_m_s": rmse, "max_xy_drift_m": drift,
                        "posture_passed": posture, "yaw_rate_rmse_rad_s": yaw_rmse}
        push = _disturbance(data("robot_force_n"), float(conditions.get("push_n", 0)), float(conditions.get("push_duration", .4)),
                            tt, dt, err, speed, tilt, valid_hold, "push", method=method, command=cmd, original_complete=complete)
        press = _disturbance(data("box_force_n"), float(conditions.get("pressure_n", 0)), float(conditions.get("pressure_duration", 1)),
                             tt, dt, err, speed, tilt, valid_hold, "press", method=method, command=cmd, original_complete=complete)
        target_speed = abs(np.diff(data("target"), axis=0)) / dt
        limit = evaluation.get("action_filter", {}).get("max_target_speed_rad_s")
        if limit is None:
            scalar = conditions.get("target_speed_limit")
            limit = [scalar]*data("target").shape[-1] if scalar is not None else None
        slew_known = limit is not None
        slew_ok = bool(slew_known and np.all(target_speed <= np.asarray(limit)+1e-4))
        support = (_braced_support(data, tt, dt, float(evaluation["actual_gravity_m_s2"]), complete, profile)
                   if profile in BRACED_PROFILES else {"required": False, "passed": None, "contact_schema": profile})
        stopping=(_stopping(data,tt,dt,complete) if windowed else
                  {"requested":False,"passed":None,"status":"not_evaluated_v1","bouts":[]})
        motion_ok = walking["passed"] if walking["requested"] else standing["passed"]
        overall = bool(hold and motion_ok and slew_ok and (not support["required"] or support["passed"])
                       and all(not x["requested"] or x["passed"] for x in (push, press, stopping)))
        results.append({"slot": j, "original_episode_complete": complete, "original_rows": int(keep.sum()),
            "box_hold_passed": hold, "standing": standing, "walking": walking, "push": push,
            "pressure": press, "stopping":stopping, "command_slew_passed": slew_ok, "command_slew_limit_available": slew_known,
            "target_speed_max_rad_s": float(target_speed.max()) if target_speed.size else 0.,
            "measured_joint_speed_rms_rad_s": float(np.sqrt(np.mean(data("qd")**2))),
            "measured_joint_speed_max_rad_s": float(abs(data("qd")).max()),
            "braced_arm_support": support,
            "foot_diagnostics": _foot_diagnostics(data("foot_contact"), data("foot_force"), dt,
                data("foot_position_w") if "foot_position_w" in trace else None,
                data("foot_velocity_w") if "foot_velocity_w" in trace else None),
            "ankle_motion_diagnostics": _ankle_motion(data, tt, dt, evaluation, "q" in trace),
            "combined_qualified": overall})
    counts = {}
    for key in ("standing", "walking", "push", "pressure", "stopping"):
        selected = [row[key] for row in results if row[key]["requested"]]
        counts[key] = {"requested_episodes": len(selected), "passed_episodes": sum(x["passed"] is True for x in selected)}
    schema = NATIVE_BRACED_SCHEMA if profile == "braced_contact_native_v1" else BRACED_SCHEMA if profile == "braced_contact_v1" else SCHEMA
    if windowed:
        schema = schema.removesuffix("v1")+("v3" if method == "walking_recovery_window_v3" else "v2")
    return {"schema": schema, "qualification_method": method,
            "walking_tracking_window_s": WALKING_WINDOW_S if windowed else 0.,
            "stopping_criteria":STOPPING_CRITERIA if windowed else None,
            "moving_recovery_criteria": RECOVERY_WINDOW_CRITERIA if method == "walking_recovery_window_v3" else None,
            "contact_profile": profile, "contact_schema": evaluation.get("contact_schema"),
            "criteria": CRITERIA, "braced_criteria": NATIVE_BRACED_CRITERIA if profile == "braced_contact_native_v1" else BRACED_CRITERIA if profile == "braced_contact_v1" else None,
            "braced_arm_support_passed_episodes": sum(x["braced_arm_support"]["passed"] is True for x in results),
            "num_episodes": len(results),
            "combined_qualified_episodes": sum(x["combined_qualified"] for x in results),
            "box_hold_passed_episodes": sum(x["box_hold_passed"] for x in results), "by_condition": counts,
            "episodes": results,
            "limitations": ["Simulation qualification only; not real-robot validation.",
                "External force impulse is not a mass/inertia change; mass conditions must be evaluated separately.",
                "Target slew compliance does not prove absence of physical oscillation; measured joint-speed and contact diagnostics remain separate.",
                "Foot contact/body-origin diagnostics do not certify stepping geometry or exclude dragging.",
                "Gyro-z approximates commanded body yaw rate; full world-yaw trajectory is unavailable.",
                "Windowed walking tracking averages signed errors over complete moving windows; it is not a smoothness or no-shaking certificate. Raw diagnostics and all other gates remain separate.",
                "V3 changes only constant-moving-command recovery velocity error to complete 1 s signed-error means; raw recovery errors remain reported. Standing recovery, stopping, support and other gates are unchanged."]}

