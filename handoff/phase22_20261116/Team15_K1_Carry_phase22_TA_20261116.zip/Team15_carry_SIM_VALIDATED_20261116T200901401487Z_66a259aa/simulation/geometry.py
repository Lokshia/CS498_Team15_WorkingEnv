"""Extracted fixed geometry initialization only; no policy/task registration."""
import math
from collections.abc import Sequence

ACTION_DIM = 22


JOINT_NAMES = (
    "aahead_yaw_joint", "aahead_pitch_joint",
    "aaleft_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_elbow_pitch_joint", "left_elbow_yaw_joint",
    "aaright_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_elbow_pitch_joint", "right_elbow_yaw_joint",
    "left_hip_pitch_joint", "left_hip_roll_joint", "left_hip_yaw_joint", "left_knee_pitch_joint", "left_ankle_pitch_joint", "left_ankle_roll_joint",
    "right_hip_pitch_joint", "right_hip_roll_joint", "right_hip_yaw_joint", "right_knee_pitch_joint", "right_ankle_pitch_joint", "right_ankle_roll_joint",
)


DEFAULT_JOINT_POS = (
    0., 0.,
    0., -math.pi / 2, 0., -(math.pi / 2 - .06),
    0., math.pi / 2, 0., math.pi / 2 - .06,
    -.4, 0., 0., .8, -.4, 0.,
    -.4, 0., 0., .8, -.4, 0.,
)


SIM_INIT_POS = (0., 0., .5181737009342727)


def joint_permutation(controller_names: Sequence[str]) -> list[int]:
    """Canonical actor index -> controller index; reject missing/extra names."""
    names = list(controller_names)
    if len(names) != ACTION_DIM or len(set(names)) != ACTION_DIM or set(names) != set(JOINT_NAMES):
        raise ValueError("Expected exactly the 22 named Team15 K1 joints")
    return [names.index(name) for name in JOINT_NAMES]
