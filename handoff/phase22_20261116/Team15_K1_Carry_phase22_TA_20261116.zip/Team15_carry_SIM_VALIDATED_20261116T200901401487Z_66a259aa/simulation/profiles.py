"""Measured light-chest-bracing profile on the original official geometry."""
from __future__ import annotations
import hashlib
import numpy as np
from . import measurements
from .scene import SUPPORT_GEOMS


BRACED_PROFILES=('braced_contact_v1','braced_contact_native_v1')
PAIR_COMPONENTS=['tangent_1','tangent_2','torsional','rolling_1','rolling_2']


def verify_source_xml(raw,physical,mapping=None):
    """New exports may normalize CRLF only; archived contracts remain raw-strict."""
    expected=(physical.get('native_physics_audit') or {}).get('source_xml_sha256')
    actual=hashlib.sha256(raw).hexdigest()
    canonical=hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()
    declaration=mapping or {}
    expected_canonical=declaration.get('source_xml_canonical_sha256')
    if expected_canonical is None:
        if actual!=expected:raise ValueError('Native source XML differs from the actual training asset')
    elif (declaration.get('source_xml_sha256')!=expected
            or declaration.get('source_xml_canonicalization')!='CRLF_to_LF_only'
            or canonical!=expected_canonical):
        raise ValueError('Native canonical XML differs from the verified training asset')
    return dict(actual_source_xml_sha256=actual,training_source_xml_sha256=expected,
        actual_source_xml_canonical_sha256=canonical,canonical_validation_used=expected_canonical is not None,
        raw_bytes_identical=actual==expected)


def validate_training_materials(physical,profile='braced_contact_v1'):
    if profile not in BRACED_PROFILES:raise ValueError('Unsupported braced material profile')
    native=profile=='braced_contact_native_v1'
    pairs=(physical or {}).get('effective_payload_contact_materials',{})
    suffixes=('_hand_collision',) if native else ('_hand_collision','_hand_end_collision')
    names=['robot/'+side+suffix for side in ('left','right') for suffix in suffixes]
    names+=['robot/trunk_collision','robot/trunk_lower_collision'] if native else ['robot/trunk_collision']
    # Native support pairs currently implement exactly this contact material.
    # A changed training material needs an explicit scene revision, not fallback.
    expected=np.array([.7,.7,.005,.0001,.0001] if native else [.7,.005,.0001])
    if native and (physical or {}).get('physics_profile')!='native_deploy':
        raise ValueError('Native contact profile must originate from native_deploy training physics')
    for name in names:
        pair=pairs.get(name,{})
        friction=np.asarray(pair.get('friction'),dtype=float)
        if friction.shape!=expected.shape or not np.isfinite(friction).all() or not np.allclose(friction,expected,rtol=0,atol=1e-12):
            raise ValueError(f'Missing or unsupported measured training contact friction for {name}')
        if native and (pair.get('source')!='explicit MuJoCo pair' or pair.get('condim')!=3
                or pair.get('friction_components')!=PAIR_COMPONENTS
                or pair.get('solref')!=[.0105,1.] or pair.get('solimp')!=[.9,.95,.001,.5,2.]):
            raise ValueError(f'Native explicit pair metadata mismatch for {name}')
    return expected.tolist()


def physical_mapping(brace_names,profile='braced_contact_v1',physical=None):
    if profile=='braced_contact_native_v1':
        audit=(physical or {}).get('native_physics_audit') or {}
        source_hash=audit.get('source_xml_sha256','')
        if len(source_hash)!=64 or any(c not in '0123456789abcdef' for c in source_hash) or not audit.get('meshes'):
            raise ValueError('Native geometry mapping requires source XML and mesh hashes')
        return dict(schema='team15-native-contact-mapping-v2',robot_geometry='same original official K1 collision shapes; renamed only',
            support_groups={side:dict(training_geoms=[side+'_hand_collision'],native_geoms=[geom],
                difference='Same official forearm collision mesh; no cylinder or auxiliary end sphere')
                for side,geom in zip(('left','right'),SUPPORT_GEOMS)},
            chest=dict(training_geoms=['trunk_collision','trunk_lower_collision'],native_geoms=list(brace_names),
                difference='Same original official torso box and cylinder; renamed only'),
            source_xml_sha256=source_hash,source_meshes=audit['meshes'],
            training_native_physics_audit=audit,
            effective_pair_friction=[.7,.7,.005,.0001,.0001],friction_components=PAIR_COMPONENTS,
            contact_force_convention='sum signed world-frame force on payload, per group; clamp Z nonnegative after summing',
            warning='Source geometry alignment is not a numerical trajectory equivalence or hardware validation claim; independent sim2sim qualification remains required')
    if profile!='braced_contact_v1':raise ValueError('Unknown physical mapping profile')
    return dict(schema='team15-native-contact-mapping-v1',robot_geometry='original official K1 collision shapes',
        support_groups={side:dict(training_geoms=[side+'_hand_collision',side+'_hand_end_collision'],
            native_geoms=[geom],difference='Training cylinder plus end sphere; native original full forearm mesh, no added support surface')
            for side,geom in zip(('left','right'),SUPPORT_GEOMS)},
        chest=dict(training_geoms=['trunk_collision'],native_geoms=list(brace_names),
            difference='Training torso collision; native original torso box and cylinder'),
        contact_force_convention='sum signed world-frame force on payload, per group; clamp Z nonnegative after summing',
        effective_friction=[.7,.005,.0001],
        warning='Matched friction does not make differing collision geometry identical; independent sim2sim qualification is required')


def model_audit(controller):
    report,layout=measurements.model_audit(controller)
    scene=controller.scene_audit
    schema=scene.get('contact_schema',{})
    if schema.get('profile') not in BRACED_PROFILES:
        raise ValueError('Braced measurements require an explicitly braced physical scene')
    layout['brace']=[controller.mj_model.geom(name).id for name in scene['brace_geom_names']]
    layout['schema']=schema
    gravity=controller.mj_model.opt.gravity
    if not np.allclose(gravity[:2],0) or gravity[2]>=0:
        raise ValueError('Braced vertical load accounting requires downward world-Z gravity')
    report['contact_schema']=schema
    report['physical_mapping']=scene['physical_mapping']
    return report,layout


def contact_sample(model,data,layout):
    import mujoco
    feet,support,box,ground=layout['feet'],layout['support'],layout['payload_geom'],layout['ground']
    braces=layout['brace'];allowed=set(support)|set(braces)
    foot_force=np.zeros((2,3));foot_contact=np.zeros(2,bool)
    arm_force=np.zeros((2,3));arm_found=np.zeros(2,bool);trunk_force=np.zeros(3)
    forbidden=False;loaded_forbidden=False
    for index in range(data.ncon):
        c=data.contact[index];pair=(int(c.geom1),int(c.geom2))
        if box not in pair and ground not in pair:continue
        local=np.zeros(6);mujoco.mj_contactForce(model,data,index,local)
        world=c.frame.reshape(3,3).T@local[:3]
        if ground in pair:
            for i,foot in enumerate(feet):
                if foot in pair:
                    foot_contact[i]=True;foot_force[i]+=world if c.geom2==foot else -world
        if box in pair:
            other=pair[1] if pair[0]==box else pair[0]
            on_box=world if c.geom2==box else -world
            if other in support:
                i=support.index(other);arm_force[i]+=on_box;arm_found[i]=True
            elif other in braces:trunk_force+=on_box
            elif other not in allowed:
                forbidden=True;loaded_forbidden |= bool(np.dot(on_box,on_box)>1e-12)
    schema=layout['schema'];mass=float(model.body_mass[layout['payload_body']])
    reference=float(mass*(-model.opt.gravity[2])+
        max(0.,-float(data.xfrc_applied[layout['payload_body'],2])))
    share=np.maximum(arm_force[:,2],0)/max(reference,1e-6)
    real=arm_found&(arm_force[:,2]>schema['support_force_threshold_n'])
    supported=bool(real.all() and share.sum()>=schema['min_total_support_fraction']
                   and (share>=schema['min_per_arm_support_fraction']).all())
    return dict(foot_force_n=foot_force,foot_contact=foot_contact,
        forearm_force_on_payload_n=arm_force,forearm_contact=real,
        payload_forearm_supported=supported,forbidden_contact=forbidden,loaded_forbidden_contact=loaded_forbidden,
        arm_force_n=arm_force,trunk_force_n=trunk_force,arm_load_share=share,total_arm_load_share=float(share.sum()),
        trunk_load_share=float(max(trunk_force[2],0)/max(reference,1e-6)),reference_load_n=reference,
        actual_payload_mass_kg=mass,left_forearm_contact=bool(real[0]),right_forearm_contact=bool(real[1]))


def sample(controller,layout,origin_xy,reference_height,support_gap,forbidden_substep):
    row,_=measurements.sample(controller,layout,origin_xy,reference_height,support_gap,False)
    contact=contact_sample(controller.mj_model,controller.mj_data,layout)
    gap=0 if contact['payload_forearm_supported'] else support_gap+1
    forbidden=bool(contact['forbidden_contact'] or forbidden_substep)
    lost=gap>layout['schema']['max_support_gap_steps']
    row.update({key:contact[key] for key in ('foot_force_n','foot_contact','forearm_force_on_payload_n',
        'forearm_contact','payload_forearm_supported','arm_force_n','trunk_force_n','arm_load_share',
        'total_arm_load_share','trunk_load_share','reference_load_n','actual_payload_mass_kg',
        'left_forearm_contact','right_forearm_contact')})
    row.update(payload_disallowed_contact=forbidden,support_gap_steps=gap,support_lost=lost,
        valid_hold=bool(row['payload_tilt_deg']<10 and abs(row['height_error_m'])<.05
                        and not row['fell'] and not forbidden and not lost))
    return row,gap
