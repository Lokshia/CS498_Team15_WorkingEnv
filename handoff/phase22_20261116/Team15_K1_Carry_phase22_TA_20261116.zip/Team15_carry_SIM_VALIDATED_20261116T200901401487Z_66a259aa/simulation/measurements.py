"""Extracted physical measurements; not the historical standing scorer."""
import math
import numpy as np

def model_audit(controller):
    import mujoco
    from .geometry import JOINT_NAMES
    m, d, cfg = controller.mj_model, controller.mj_data, controller.cfg
    joints = np.array([m.joint(name).id for name in JOINT_NAMES], dtype=int)
    if len(set(joints.tolist())) != 22 or (m.nq, m.nv, m.nu) != (36, 34, 22):
        raise ValueError("Expected 22 actuated hinges plus free robot and free box")
    if m.neq != 0 or (m.jnt_type == mujoco.mjtJoint.mjJNT_FREE).sum() != 2:
        raise ValueError("Box or robot is constrained")
    if not np.array_equal(m.actuator_trnid[:, 0], joints):
        raise ValueError("Actuator joint mapping differs from controller ordering")
    if not np.allclose(m.actuator_gear[:, 0], 1) or not np.allclose(m.actuator_gear[:, 1:], 0):
        raise ValueError("Unexpected actuator gearing")
    payload_body = m.body("team15_payload").id
    payload_geom = m.geom("team15_payload_box").id
    payload_joint = m.joint("team15_payload_free").id
    mass = float(m.body_mass[payload_body])
    half_size = m.geom_size[payload_geom]
    expected_inertia = mass*np.array((half_size[1]**2+half_size[2]**2,
                                     half_size[0]**2+half_size[2]**2,
                                     half_size[0]**2+half_size[1]**2))/3
    if (m.geom_type[payload_geom] != mujoco.mjtGeom.mjGEOM_BOX
            or not np.isfinite(mass) or mass <= 0 or not np.all(half_size > 0)
            or not np.allclose(m.geom_pos[payload_geom], 0., rtol=0., atol=1e-12)
            or not np.allclose(m.geom_quat[payload_geom], [1., 0., 0., 0.], rtol=0., atol=1e-12)
            or not np.allclose(m.body_ipos[payload_body], 0., rtol=0., atol=1e-12)
            or not np.allclose(m.body_iquat[payload_body], [1., 0., 0., 0.], rtol=0., atol=1e-12)
            or not np.all(m.body_inertia[payload_body] > 0)
            or not np.allclose(m.body_inertia[payload_body], expected_inertia, rtol=1e-12, atol=1e-12)):
        raise ValueError("Payload must have the centred inertial frame and inertia of the homogeneous box")
    if m.jnt_type[payload_joint] != mujoco.mjtJoint.mjJNT_FREE:
        raise ValueError("Payload is not a free body")
    base_joint = next(i for i in range(m.njnt)
                      if m.jnt_type[i] == mujoco.mjtJoint.mjJNT_FREE and i != payload_joint)
    ground = m.geom("ground").id
    feet = []
    for side in ("left", "right"):
        body = m.body(f"{side}_ankle_roll_link").id
        geoms = [i for i in range(m.ngeom) if m.geom_bodyid[i] == body
                 and m.geom_type[i] == mujoco.mjtGeom.mjGEOM_BOX]
        if len(geoms) != 1:
            raise ValueError("Expected one sole collision box per foot")
        feet.append(geoms[0])
    scene_audit = controller.scene_audit
    support_names = scene_audit["support_geom_names"]
    if len(support_names) != 2:
        raise ValueError("Two named forearm support surfaces are required")
    support = [m.geom(name).id for name in support_names]
    auxiliary = [m.geom(name).id for name in scene_audit.get("allowed_auxiliary_geom_names", [])]
    layout = dict(joints=joints, qadr=m.jnt_qposadr[joints].copy(), vadr=m.jnt_dofadr[joints].copy(),
                  ground=ground, feet=feet, support=support, auxiliary=auxiliary,
                  payload_body=payload_body, payload_geom=payload_geom,
                  payload_qadr=int(m.jnt_qposadr[payload_joint]), payload_vadr=int(m.jnt_dofadr[payload_joint]),
                  base_qadr=int(m.jnt_qposadr[base_joint]), base_vadr=int(m.jnt_dofadr[base_joint]),
                  trunk=m.body("trunk").id)
    ranges = m.jnt_range[joints]
    if not m.jnt_limited[joints].all() or not np.isfinite(ranges).all():
        raise ValueError("Joint limit audit requires 22 finite limited joints")
    report = dict(nq=m.nq, nv=m.nv, nu=m.nu, equality_constraints=m.neq,
                  joint_names=list(JOINT_NAMES), robot_mass_kg=float(m.body_mass.sum()-m.body_mass[payload_body]),
                  payload_mass_kg=float(m.body_mass[payload_body]), payload_half_size_m=m.geom_size[payload_geom].tolist(),
                  payload_inertia_kg_m2=m.body_inertia[payload_body].tolist(),
                  payload_local_center_of_mass_m=m.body_ipos[payload_body].tolist(),
                  payload_local_inertial_orientation_wxyz=m.body_iquat[payload_body].tolist(),
                  payload_expected_uniform_box_inertia_kg_m2=expected_inertia.tolist(),
                  payload_qpos_address=layout["payload_qadr"], joint_qpos_addresses=layout["qadr"].tolist(),
                  joint_dof_addresses=layout["vadr"].tolist(), joint_ranges_rad=ranges.tolist(),
                  actuator_joint_ids=m.actuator_trnid[:, 0].tolist(),
                  xml_actuator_force_limits=m.actuator_forcerange.tolist(),
                  configured_effort_limits=list(cfg.robot.effort_limit),
                  policy_dt_s=cfg.policy_dt, physics_dt_s=float(m.opt.timestep), decimation=cfg.mujoco.decimation,
                  simulation_kp=list(cfg.robot.joint_stiffness), simulation_kd=list(cfg.robot.joint_damping),
                  integrator=int(m.opt.integrator), impratio=float(m.opt.impratio),
                  ground_friction=m.geom_friction[ground].tolist(), sole_friction=m.geom_friction[feet].tolist(),
                  payload_friction=m.geom_friction[payload_geom].tolist(),
                  support_friction=m.geom_friction[support].tolist(), scene=scene_audit,
                  note="Official robot asset plus documented payload/contact overlay and 22-joint index adapter; not an unchanged upstream controller.")
    return report, layout


def contact_sample(model, data, layout):
    """World forces on feet/box; never supplies observations to the actor."""
    import mujoco
    feet, support, box, ground = layout["feet"], layout["support"], layout["payload_geom"], layout["ground"]
    foot_force = np.zeros((2, 3)); foot_contact = np.zeros(2, bool)
    support_force = np.zeros((2, 3)); support_contact = np.zeros(2, bool)
    forbidden = False; loaded_forbidden = False
    allowed = set(support) | set(layout["auxiliary"])
    for index in range(data.ncon):
        c = data.contact[index]
        pair = (int(c.geom1), int(c.geom2))
        if box not in pair and ground not in pair:
            continue
        local = np.zeros(6)
        mujoco.mj_contactForce(model, data, index, local)
        world = c.frame.reshape(3, 3).T @ local[:3]
        if ground in pair:
            for i, foot in enumerate(feet):
                if foot in pair:
                    foot_contact[i] = True
                    foot_force[i] += world if c.geom2 == foot else -world
        if box in pair:
            other = pair[1] if pair[0] == box else pair[0]
            force_on_box = world if c.geom2 == box else -world
            if other in support:
                i = support.index(other)
                support_contact[i] = True
                support_force[i] += force_on_box
            elif other not in allowed:
                forbidden = True
                loaded_forbidden |= bool(np.dot(force_on_box, force_on_box) > 1e-12)
    return dict(foot_force_n=foot_force, foot_contact=foot_contact,
                forearm_force_on_payload_n=support_force, forearm_contact=support_contact,
                payload_forearm_supported=bool((support_contact & (support_force[:, 2] > 1e-6)).all()),
                forbidden_contact=forbidden, loaded_forbidden_contact=loaded_forbidden)


def sample(controller, layout, origin_xy, reference_height, support_gap, forbidden_substep):
    m, d = controller.mj_model, controller.mj_data
    contact = contact_sample(m, d, layout)
    support_gap = 0 if contact["payload_forearm_supported"] else support_gap + 1
    box = layout["payload_body"]
    angle = lambda value: math.degrees(math.acos(float(np.clip(value, -1, 1))))
    sole_tilts = [angle(d.geom_xmat[g].reshape(3, 3)[2, 2]) for g in layout["feet"]]
    trunk_tilt = angle(d.xmat[layout["trunk"]].reshape(3, 3)[2, 2])
    payload_tilt = angle(d.xmat[box].reshape(3, 3)[2, 2])
    payload_height = float(d.xpos[box, 2])
    height_error = payload_height-reference_height
    base_qadr = layout["base_qadr"]
    base_height = float(d.qpos[base_qadr+2])
    forbidden = bool(contact["forbidden_contact"] or forbidden_substep)
    fell = bool(base_height < .28 or trunk_tilt > 60 or payload_height < .20)
    valid = bool(payload_tilt < 10 and abs(height_error) < .05 and not fell
                 and not forbidden and support_gap <= 6)
    ranges = m.jnt_range[layout["joints"]]
    qpos, qvel = d.qpos[layout["qadr"]].copy(), d.qvel[layout["vadr"]].copy()
    excess = np.maximum(np.maximum(ranges[:, 0]-qpos, qpos-ranges[:, 1]), 0.)
    row = dict(time_s=float(d.time), foot_tilt_deg=sole_tilts,
               foot_force_n=contact["foot_force_n"], foot_contact=contact["foot_contact"],
               trunk_tilt_deg=trunk_tilt, base_height_m=base_height,
               drift_m=float(np.linalg.norm(d.qpos[base_qadr:base_qadr+2]-origin_xy)),
               joint_position=qpos, joint_velocity=qvel, actuator_torque=d.qfrc_actuator[layout["vadr"]].copy(),
               actual_joint_limit_excess_rad=excess,
               payload_position_w=d.xpos[box].copy(), payload_height_m=payload_height,
               payload_tilt_deg=payload_tilt, height_error_m=height_error,
               forearm_contact=contact["forearm_contact"],
               forearm_force_on_payload_n=contact["forearm_force_on_payload_n"],
               payload_forearm_supported=contact["payload_forearm_supported"],
               payload_disallowed_contact=forbidden, support_gap_steps=support_gap,
               support_lost=support_gap > 6, fell=fell, valid_hold=valid)
    return row, support_gap
