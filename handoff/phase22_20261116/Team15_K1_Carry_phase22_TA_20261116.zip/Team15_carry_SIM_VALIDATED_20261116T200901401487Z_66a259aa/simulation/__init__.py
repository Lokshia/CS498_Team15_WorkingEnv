"""Standalone simulation support; does not register deployment tasks."""
