"""Empty-hand balance/motion diagnostic. Contains no box-hold metrics."""
import numpy as np
from .qualification import CRITERIA,_rms_vector,_foot_diagnostics,_ankle_motion


def qualify_empty(trace,metadata,failure=None):
    t=np.asarray(trace['time_s']);dt=float(metadata['control_dt_s'])
    expected=round(metadata['seconds']/dt)
    complete=bool(failure is None and len(t)==expected)
    if len(t)<2:return dict(schema='team15-native-empty-carry-v1',empty_hand_passed=False,failure=failure or 'too_few_frames')
    if not np.allclose(t,np.arange(1,len(t)+1)*dt,rtol=0,atol=1e-6):raise ValueError('Empty trace timestamps must be uniform from dt')
    for key,value in trace.items():
        if not np.isfinite(value).all():raise ValueError(f'Nonfinite empty-hand trace: {key}')
    cmd,vel,pos=trace['command'],trace['base_velocity'],trace['base_position']
    tilt=trace['robot_tilt_deg'];steady=t>=CRITERIA['steady_start_s']
    moving=steady&(np.linalg.norm(cmd[:,:2],axis=-1)>CRITERIA['moving_command_threshold_m_s'])
    posture=bool(steady.any() and np.quantile(tilt[steady],.95)<=10 and tilt[steady].max()<=20)
    yaw_rmse=float(np.sqrt(np.mean((trace['obs_actor'][steady,2]-cmd[steady,2])**2))) if steady.any() else None
    yaw_ok=yaw_rmse is not None and yaw_rmse<=CRITERIA['max_yaw_rate_rmse_rad_s']
    if moving.any():
        speeds=np.linalg.norm(cmd[moving,:2],axis=-1);unit=cmd[moving,:2]/speeds[:,None]
        along=np.sum(vel[moving,:2]*unit,axis=-1);requested=float(speeds.sum()*dt)
        progress=float(along.sum()*dt);fraction=float((along>=.25*speeds).mean())
        rmse=_rms_vector(vel[moving,:2]-cmd[moving,:2]);limit=max(.02,.5*float(speeds.mean()))
        pp=pos[moving,:2];stride=max(1,round(.2/dt));sampled=pp[np.unique(np.r_[np.arange(0,len(pp),stride),len(pp)-1])]
        path=float(np.linalg.norm(np.diff(sampled,axis=0),axis=-1).sum());net=float(np.linalg.norm(pp[-1]-pp[0]))
        straight=bool(np.max(abs(cmd[moving,2]))<.01 and np.max(np.linalg.norm(unit-unit[0],axis=-1))<.05)
        motion=bool(complete and moving.sum()*dt>=2 and rmse<=limit and progress>=.6*requested
            and fraction>=.8 and path>=.6*requested and (not straight or net>=.6*requested) and posture and yaw_ok)
        result=dict(condition='walking_start_stop',motion_passed=motion,vector_velocity_rmse_m_s=rmse,
            velocity_limit_m_s=limit,requested_path_m=requested,directed_progress_m=progress,
            progress_fraction=progress/requested,moving_fraction=fraction,world_path_m=path,world_net_m=net)
    else:
        rmse=_rms_vector(vel[steady,:2]) if steady.any() else None
        drift=float(np.linalg.norm(pos[steady,:2]-pos[steady,:2][0],axis=-1).max()) if steady.any() else None
        motion=bool(complete and steady.sum()*dt>=2 and rmse is not None and rmse<=.05 and drift<=.1 and posture and yaw_ok)
        result=dict(condition='standing',motion_passed=motion,vector_velocity_rmse_m_s=rmse,max_xy_drift_m=drift)
    if metadata.get('scenario')=='walk' and not moving.any():
        motion=False;result.update(motion_passed=False,reason='Requested walking sequence was not exercised')
    # Include the very first target relative to measured initial q in slew checks.
    limit=np.asarray(metadata['action_filter']['max_target_speed_rad_s'])
    slew=bool(np.all(abs(trace['target_speed_rad_s'])<=limit+1e-4))
    final=(t>=metadata['seconds']-2)&(np.linalg.norm(cmd,axis=-1)<1e-6)
    settled=bool(final.sum()*dt>=1.98 and np.quantile(np.linalg.norm(vel[final,:2],axis=-1),.95)<=.05
        and np.quantile(tilt[final],.95)<=10 and np.quantile(np.linalg.norm(trace['obs_actor'][final,:3],axis=-1),.95)<=.3)
    data=lambda key:trace[key]
    upright_height=bool(np.min(pos[:,2])>=.28)
    return dict(schema='team15-native-empty-carry-v1',no_payload_present=True,hardware_validated=False,
        empty_hand_passed=bool(complete and motion and slew and settled and upright_height),original_episode_complete=complete,
        upright_height_passed=upright_height,
        failure=failure,steps_completed=len(t),steps_expected=expected,posture_passed=posture,
        maximum_trunk_tilt_deg=float(tilt.max()),minimum_base_height_m=float(pos[:,2].min()),
        yaw_rate_rmse_rad_s=yaw_rmse,command_slew_passed=slew,final_stop_settled=settled,
        motion=result,foot_diagnostics=_foot_diagnostics(trace['foot_contact'],trace['foot_force'],dt,
            trace['foot_position_w'],trace['foot_velocity_w']),
        ankle_motion_diagnostics=_ankle_motion(data,t,dt,metadata,True),
        limitations=['Pure official robot scene, no box of any mass and no artificial support.',
            'Starts in raised-arm nominal pose; physical arm raising, control-mode transfer, and loading are not tested.',
            'Separate empty-hand diagnostic, never counted as a box-hold success.',
            'Foot contact/body-origin traces do not prove a safe or natural gait; no hardware validation.'])
