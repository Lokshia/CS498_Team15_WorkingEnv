# Self-contained native carrying simulation

This directory is simulation support, not an upstream task. It neither registers nor imports a historical policy. The only policy used by `tests/run_carry_sim.py` is the installed `tasks.team15_carry` model. No legacy model weights are included.

Dependencies remain the official `booster_deploy` checkout and `booster_assets` checkout, plus their Python dependencies. The package does not need the old `team15_proprio_package` directory at runtime.

## Physical model

The official K1 robot geometry and motors are combined in memory with a free box. The box has half-size `(0.10, 0.20, 0.06)` metres, the requested positive mass and homogeneous cuboid inertia. Explicit forearm support contact pairs have sliding friction 0.7. No weld, hidden supporting force, runtime pose reset, or box-state input to the actor is added. The simulator addresses all 22 robot hinges explicitly so the free box coordinates cannot leak into robot observations.

Both forearms must provide upward support. Gaps longer than six control steps (0.12 s at 50 Hz) fail; initialization gets no additional grace. Measured forces are simulation diagnostics only.

## Source and integrity

`PROVENANCE.json` records complete SHA-256 values of each source file and extracted output. Historical source paths record where the files lived when extracted; the originals have since been archived. These paths are provenance, not installation instructions or runtime dependencies.

| File | Source | Source SHA-256 |
|---|---|---|
| scene.py | historical tasks/team15_proprio/scene.py | `117ae56b6ce15ff1c7dab514dba4c9e298bdc2a47c9635f196ff73183881123e` |
| simulator.py | historical tasks/team15_proprio/simulator.py | `4e9af9f696b80965393cf58e40716122172530768ca4147ce869dd8fcdef7d6b` |
| geometry.py | selected geometry constants from historical contract.py | `a0c2ec9d86fcec24bfc39f049313d24a68e3260827f881e47b2b23ba63ecc43d` |
| measurements.py | model_audit, contact_sample, sample from historical validate_package.py | `600d75f8d41ce7ffd2430baf1e89317e5ce7c8971ded2db8520910d9c8cb1c06` |
| qualification.py | formal scripts/score_carry.py qualification core, including explicit braced profile | current complete source hash in `PROVENANCE.json` |

The initial extraction changed only imports and the controller name. Its initial hashes remain in `PROVENANCE.json.initial_extracted_outputs`. A subsequent explicitly selected braced branch adds payload metadata forwarding and chest friction pairs. The default strict path is retained and tested against the original diagnostic trajectory. Historical model hashes, registrations, and static-posture scoring are excluded. `trace.py` converts native measurements into the formal scorer's array schema without discarding or resetting failed episodes.

## Qualification

The selected scorer constants and function ASTs are identical to the formal training scorer. Overall qualification is the AND of full uninterrupted box hold, commanded locomotion or standing, target slew compliance, and every requested force pulse and recovery. Force direction, peak and impulse are checked. An unexercised disturbance fails; a standing policy cannot pass a walking command. Acceptance uses planar vector RMSE, sustained directed progress, sampled world displacement and the complete post-disturbance recovery window.

Physics preservation and scorer parity are tested by `tests/test_simulation_package.py`. The 20-second diagnostic before/after comparison is evidence of extraction equivalence, not evidence that its unfinished policy qualifies for walking.

The default `instantaneous_v1` remains available for historical comparisons.
Explicit `walking_window_v2` uses complete contiguous 1-second moving windows
only for velocity/yaw tracking means. Raw diagnostics remain visible; this is not
a no-shaking guarantee. Its additional stopping gate checks every zero-command
bout after movement, requiring 1 second to settle and at least 2 seconds of raw
velocity, drift, posture and yaw measurements. All remaining samples in that bout
are scored. Missing time fails, rather than joining separate short pauses. Pure
standing and protocols with no post-movement stop retain their original checks.
Release packaging requires one explicitly selected method across all loaded
acceptance and stress evidence; it cannot combine favorable v1/v2 results.

`EXTRACTION_VALIDATION.json` records two seed-19013 diagnostic runs: walking and walking with an 8 N side push plus 3 N downward pressure. Each completed 1,000 control steps. All 35 shared physical trajectory fields were bitwise equal before/after extraction (maximum absolute difference 0). Both unfinished-policy walking qualifications correctly failed. Thirty deployment tests passed with the official upstream dependency on the Python path.

## Explicit braced contact

`braced_contact_v1` permits physical chest contact while requiring the two arms to carry at least 50% of reference load together and at least 10% each. Reference load is the measured model mass times gravity plus the downward external pressure applied in that physics interval. Each arm must have actual upward contact force; support gaps get at most six control steps. Chest force is recorded separately and never credited to the arms. Formal qualification additionally checks steady support-force percentiles and cache consistency against raw N/kg measurements.

The original official forearm collision mesh maps to each training cylinder plus end sphere. No hidden end sphere or support shelf is added. The two official torso colliders are preserved; two explicit box/chest contact pairs use measured training effective friction `[0.7, 0.005, 0.0001]` rather than the official torso's default sliding friction 1.0. Missing or different training material metadata is rejected. `physical_mapping` records the geometry mismatch, which independent sim2sim still has to validate.

`BRACED_PHYSICS_VALIDATION.json` confirms identical original geometry, inertias, actuator mapping/limits, and initial pose; only the two explicit chest contact pairs are added. A repeat strict diagnostic after adding the branch again matched all 35 physical fields across 1,000 steps bitwise. This is a physics/accounting audit, not a claim that a trained braced walking model passed.

`braced_contact_native_v1` (contact schema 2) is separate from the archived profile above. Training uses the official forearm collision meshes and both official chest colliders, renamed only; no hand-end sphere is expected. `physical_mapping` binds the training source XML and every mesh SHA-256, and `scene.py` verifies the local files. It preserves the same native physical geometry and initialization. Actual pair friction stays five-dimensional `[0.7, 0.7, 0.005, 0.0001, 0.0001]`, with condim 3, solref `[0.0105, 1]`, and solimp `[0.9, 0.95, 0.001, 0.5, 2]`; unsupported or missing metadata fails explicitly. New raw-force scoring keeps the same arm shares, six-step grace, and opt-in v2 raw stopping criteria. A shared physical source does not certify numerical trajectory equivalence across GPU/Warp and native CPU simulation.

Portable exports also bind `source_xml_canonical_sha256`: only CRLF is replaced with LF after raw training-source verification during export. Native XML validation uses this declared canonical hash when available and preserves both observed raw and training raw hashes in the audit. XML value/whitespace changes still fail; old contracts without this declaration retain exact raw-byte checks. Mesh files always remain byte-exact.

## Pure empty-hand diagnostic

`empty_qualification.py` scores genuine no-payload runs from the original upstream
`MujocoController`. `tests/run_carry_empty_sim.py` adds no bodies, inertias,
constraints, or forces. It only replaces interactive stdin command polling with
a declared stand/start-walk-stop sequence and records state/contact data. The same
native 75-input actor runs without box observations. Empty results are separate
from loaded qualification: three original 20-second zero-command standing seeds
are required for a simulation-qualified handoff; empty walking is reported
separately and does not expand the claim of a box-carrying policy. Arm raising,
physical loading, and real hardware mode transitions are outside this test.

