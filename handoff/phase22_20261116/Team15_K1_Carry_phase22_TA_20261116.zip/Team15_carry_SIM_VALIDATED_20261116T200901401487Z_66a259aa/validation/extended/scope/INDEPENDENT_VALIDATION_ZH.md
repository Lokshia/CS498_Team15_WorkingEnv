# Phase22 final3450：独立停步姿态与不退化验证

候选 checkpoint SHA256：`a2451e547f6bb232b36e289c4dea478fa11d23322fa44a7f0ff1bfbf67fabd10`。

结论：本轮候选明显改善停步后的脚底平放和侧偏，同时通过原有行走、受推、压箱和停步协议。它还不是完全对称站立；恢复过程中也不能称为全面无抖动。没有真机验证。

## 冻结原协议

使用原 `walking_recovery_window_v3` 与官方 cecc00f 部署核心、原 contact/PD/动作过滤接口，门槛没有改变。

| 验证 | 结果 | 解释 |
|---|---|---|
| native 开发 seed29013 stand/walk/combined | 3/3 | 开发筛选，不等于独立泛化 |
| native 五场景 × 三个对照 seeds78660–78662 | 15/15 | 与 phase18 同 seed、相同命令/扰动；phase18 也是15/15 |
| native 真正空手 stand seeds78670–78672 | 3/3 | 无箱子；读取 empty_hand_passed，不使用通用 passed 字段 |
| 原 GPU 环境 combined 8 slots seed99613 | 8/8 | walk/push/pressure/stop/box/双臂承托均通过；与 native 分列 |
| 35秒晚扰动诊断：22秒推、28秒压 | 1/1 | 单独的延长诊断，不计入20秒原协议成功率 |

证据：`reports/prototypes/posture_anchor_final3450_extended_verdict.json`，内含来源 SHA、原始 GPU episodes 及晚时段逐项诊断；完整 native 输出目录 `reports/prototypes/native_posture_runs/phase22_stop12_anchor1_final3450_extended_native/`。

## 停步后17–20秒

同一个开发 seed 的 combined 条件：

| 指标 | Phase18 | Phase22 final |
|---|---:|---:|
| 躯干倾角 p95 | 8.15° | 5.03° |
| 躯干 roll 均值 | −8.11° | −4.89° |
| 左脚底倾角 p95 | 15.62° | 约0.00° |
| 右脚底倾角 p95 | 约0.01° | 约0.01° |
| 下肢 mirror RMS | 20.48° | 16.31° |
| 相对 carry nominal 的下肢角度 RMS | 26.65° | 12.07° |
| 右脚向上支撑冲量比例 | 76.5% | 68.5% |
| 停步窗口最大平面漂移 | 1.41 cm | 1.22 cm |

15条对照轨迹中，两脚停步倾角 p95 均不超过0.02°，右脚支撑份额66.0–69.6%。combined 三个 seeds 的平均躯干倾角 p95 从9.069°降到5.089°，mirror RMS 从21.471°降到16.143°，右脚支撑份额从78.06%降到68.88%。这些平均值只针对明确列出的三条 combined 对照，不混入站立或失败筛选。

预先额外固定的更严目标（躯干≤5°、双脚≤5°、mirror下降至少25%、各脚30–70%）并未全部达标：部分躯干约5.0–5.13°，mirror改善不足25%。这些目标不能在训练后放宽，也不替代冻结原 v3。

## 晚扰动后的限制

35秒诊断中，晚推的恢复速度误差 p95 为0.00318 m/s，晚压为0.00324 m/s。32–35秒左脚倾角 p95为0.872°、躯干倾角5.098°，比midpoint晚压后左脚7.30°改善。但右脚支撑份额回到74.6%，所以仍存在长时间扰动后单侧承重偏大。

独立固定窗口 HF 审查见 `reports/posture_jitter_comparison_20261116T041133Z.json`：combined 推后下肢5–25Hz RMS为0.37197 rad/s，低于phase21父模型0.4468，但高于phase18约0.1368。压后与停步较安静。步态/瞬态本身也包含高频，不能只用频带占比判定抽搐；同样不能把停步较静当作全部恢复动作更平滑。

## 候选过程保留

- phase22 midpoint3250原native15仅14/15：combined seed78662的yaw RMSE0.150758>0.15。final修复此项；没有忽略该失败。
- phase23更高停步奖励权重24的final姿态更正，但combined压力恢复速度0.051806>0.05，只过2/3，因此没有凭站姿选它。
- 本次通过范围为0.5kg箱子、0.1m/s慢行、约8N短推与3N压箱及当前物理配置。不能外推3–5kg或真机安全承载能力。
