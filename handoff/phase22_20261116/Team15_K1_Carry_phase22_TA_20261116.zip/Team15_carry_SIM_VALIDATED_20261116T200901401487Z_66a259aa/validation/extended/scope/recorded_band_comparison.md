# Recorded-band oscillation comparison

Matched seed29013; original20s native traces. Diagnostic only; failed runs remain in every table. A small mean velocity is not evidence of no shaking. Window labels describe the combined scenario clock; stand/walk rows at the same clock are controls without those disturbances.

Logs:50Hz, Nyquist25Hz; dynamics:200Hz. Reported high band:5–25Hz after linear detrend and Hann window. Targets use alpha0.35 (~3.48Hz linear cutoff),3rad/s slew limit, and joint limits. Actual nonlinear filtering does not establish physical smoothness.

## walking_3p5_5p5

| Model/scenario | Native pass | Actual lower dq HF RMS | Actual upper dq HF RMS | Target lower velocity HF RMS | Lower dq total RMS | Foot contact switches L/R | Lower acceleration p95 |
|---|---|---:|---:|---:|---:|---|---:|
| phase18/stand | True | 0.01633 | 0.03915 | 0.04408 | 0.02490 | 0/0 | 2.186 |
| phase18/walk | True | 0.34287 | 0.09153 | 0.30838 | 0.84602 | 8/2 | 33.322 |
| phase18/combined | True | 0.34287 | 0.09153 | 0.30838 | 0.84602 | 8/2 | 33.322 |
| phase22mid/stand | True | 0.00126 | 0.03825 | 0.00646 | 0.00398 | 0/0 | 0.205 |
| phase22mid/walk | True | 0.37784 | 0.10056 | 0.40502 | 0.91223 | 6/4 | 34.640 |
| phase22mid/combined | True | 0.37784 | 0.10056 | 0.40502 | 0.91223 | 6/4 | 34.640 |
| phase23mid/stand | True | 0.00121 | 0.03528 | 0.00805 | 0.00256 | 0/0 | 0.218 |
| phase23mid/walk | True | 0.41783 | 0.10400 | 0.45119 | 0.89407 | 8/4 | 35.224 |
| phase23mid/combined | False | 0.41783 | 0.10400 | 0.45119 | 0.89407 | 8/4 | 35.224 |
| phase22final/stand | True | 0.00124 | 0.03551 | 0.00631 | 0.00606 | 0/0 | 0.210 |
| phase22final/walk | True | 0.38594 | 0.11209 | 0.40562 | 0.89924 | 2/4 | 33.028 |
| phase22final/combined | True | 0.38594 | 0.11209 | 0.40562 | 0.89924 | 2/4 | 33.028 |
| phase23final/stand | True | 0.00001 | 0.00010 | 0.00002 | 0.00207 | 0/0 | 0.002 |
| phase23final/walk | True | 0.36981 | 0.10996 | 0.40780 | 0.87383 | 4/4 | 31.673 |
| phase23final/combined | False | 0.36981 | 0.10996 | 0.40780 | 0.87383 | 4/4 | 31.673 |
## post_push_6p3_8p3

| Model/scenario | Native pass | Actual lower dq HF RMS | Actual upper dq HF RMS | Target lower velocity HF RMS | Lower dq total RMS | Foot contact switches L/R | Lower acceleration p95 |
|---|---|---:|---:|---:|---:|---|---:|
| phase18/stand | True | 0.00400 | 0.03574 | 0.00845 | 0.00457 | 0/0 | 0.373 |
| phase18/walk | True | 0.15841 | 0.04940 | 0.23832 | 0.85829 | 17/4 | 35.866 |
| phase18/combined | True | 0.13678 | 0.04803 | 0.20139 | 0.83582 | 8/2 | 31.379 |
| phase22mid/stand | True | 0.00120 | 0.03586 | 0.00660 | 0.00199 | 0/0 | 0.221 |
| phase22mid/walk | True | 0.40887 | 0.11862 | 0.46872 | 0.91493 | 22/2 | 34.577 |
| phase22mid/combined | True | 0.41789 | 0.11584 | 0.49239 | 0.89396 | 14/2 | 32.975 |
| phase23mid/stand | True | 0.00118 | 0.03579 | 0.00782 | 0.00260 | 0/0 | 0.199 |
| phase23mid/walk | True | 0.45963 | 0.12094 | 0.50078 | 0.91613 | 16/6 | 38.575 |
| phase23mid/combined | False | 0.44067 | 0.11489 | 0.54135 | 0.89704 | 8/4 | 36.739 |
| phase22final/stand | True | 0.00128 | 0.03666 | 0.00641 | 0.00268 | 0/0 | 0.206 |
| phase22final/walk | True | 0.37692 | 0.11045 | 0.48135 | 0.90773 | 16/6 | 37.432 |
| phase22final/combined | True | 0.37197 | 0.11959 | 0.45272 | 0.90637 | 18/4 | 33.614 |
| phase23final/stand | True | 0.00000 | 0.00000 | 0.00000 | 0.00206 | 0/0 | 0.000 |
| phase23final/walk | True | 0.42153 | 0.11856 | 0.57019 | 0.89156 | 14/4 | 34.175 |
| phase23final/combined | False | 0.42796 | 0.10780 | 0.54411 | 0.89153 | 13/4 | 33.696 |
## post_press_11_13

| Model/scenario | Native pass | Actual lower dq HF RMS | Actual upper dq HF RMS | Target lower velocity HF RMS | Lower dq total RMS | Foot contact switches L/R | Lower acceleration p95 |
|---|---|---:|---:|---:|---:|---|---:|
| phase18/stand | True | 0.00106 | 0.03887 | 0.00958 | 0.00320 | 0/0 | 0.211 |
| phase18/walk | True | 0.13078 | 0.04732 | 0.18050 | 0.82584 | 16/2 | 34.700 |
| phase18/combined | True | 0.17731 | 0.04771 | 0.22422 | 0.91371 | 11/2 | 32.217 |
| phase22mid/stand | True | 0.00113 | 0.03992 | 0.00725 | 0.00147 | 0/0 | 0.212 |
| phase22mid/walk | True | 0.11721 | 0.04856 | 0.18616 | 0.91045 | 8/4 | 35.931 |
| phase22mid/combined | True | 0.11190 | 0.04399 | 0.18654 | 0.89267 | 14/2 | 35.743 |
| phase23mid/stand | True | 0.00112 | 0.02772 | 0.00674 | 0.00182 | 0/0 | 0.187 |
| phase23mid/walk | True | 0.35580 | 0.11270 | 0.37828 | 0.90558 | 14/2 | 37.673 |
| phase23mid/combined | False | 0.33341 | 0.11069 | 0.36796 | 0.91480 | 20/6 | 38.028 |
| phase22final/stand | True | 0.00119 | 0.03248 | 0.00623 | 0.00138 | 0/0 | 0.205 |
| phase22final/walk | True | 0.06025 | 0.03430 | 0.13248 | 0.84954 | 16/4 | 31.035 |
| phase22final/combined | True | 0.05804 | 0.03601 | 0.13518 | 0.80929 | 16/3 | 28.702 |
| phase23final/stand | True | 0.00138 | 0.03851 | 0.00745 | 0.00211 | 0/0 | 0.211 |
| phase23final/walk | True | 0.08856 | 0.04870 | 0.17894 | 0.86867 | 24/4 | 33.401 |
| phase23final/combined | False | 0.08976 | 0.04462 | 0.16927 | 0.82530 | 20/4 | 30.493 |
## stopped_17_20

| Model/scenario | Native pass | Actual lower dq HF RMS | Actual upper dq HF RMS | Target lower velocity HF RMS | Lower dq total RMS | Foot contact switches L/R | Lower acceleration p95 |
|---|---|---:|---:|---:|---:|---|---:|
| phase18/stand | True | 0.00103 | 0.03397 | 0.01019 | 0.00835 | 0/0 | 0.209 |
| phase18/walk | True | 0.00136 | 0.03434 | 0.01232 | 0.03893 | 0/0 | 0.228 |
| phase18/combined | True | 0.00044 | 0.01255 | 0.00435 | 0.00611 | 0/0 | 0.080 |
| phase22mid/stand | True | 0.00114 | 0.03969 | 0.00728 | 0.00150 | 0/0 | 0.213 |
| phase22mid/walk | True | 0.00108 | 0.00044 | 0.00156 | 0.01264 | 0/0 | 0.258 |
| phase22mid/combined | True | 0.00021 | 0.00004 | 0.00018 | 0.01076 | 0/0 | 0.025 |
| phase23mid/stand | True | 0.00116 | 0.03560 | 0.00751 | 0.00134 | 0/0 | 0.193 |
| phase23mid/walk | True | 0.00035 | 0.00014 | 0.00039 | 0.00696 | 0/0 | 0.036 |
| phase23mid/combined | False | 0.00199 | 0.00049 | 0.00298 | 0.01768 | 0/0 | 0.548 |
| phase22final/stand | True | 0.00139 | 0.03686 | 0.00692 | 0.00169 | 0/0 | 0.258 |
| phase22final/walk | True | 0.00010 | 0.00169 | 0.00053 | 0.00869 | 0/0 | 0.031 |
| phase22final/combined | True | 0.00027 | 0.00028 | 0.00085 | 0.00853 | 0/0 | 0.042 |
| phase23final/stand | True | 0.00116 | 0.03692 | 0.00766 | 0.00163 | 0/0 | 0.175 |
| phase23final/walk | True | 0.00007 | 0.00063 | 0.00040 | 0.00572 | 0/0 | 0.010 |
| phase23final/combined | False | 0.00046 | 0.00668 | 0.00188 | 0.00716 | 0/0 | 0.074 |

Units:velocity rad/s; acceleration rad/s². JSON also contains upper limbs, actual/target position spectra,5–12/12–25Hz sub-bands, high-band fractions, top5 joints, sign reversals,>1N load switches,contact force spectra, source hashes and target-speed consistency check.

Numerical checks passed:unit-amplitude10Hz sine recoversRMS1/sqrt(2),linear trend has negligible high-band leakage,and one-sided spectral density obeys windowed Parseval equality. An exact analyzer source copy is saved beside this report.

Interpretation limits: >25Hz vibration/aliasing is unobservable here. Walking and impact transients can create legitimate high-frequency energy. These metrics must be read alongside posture, box retention and the unchanged native qualification results. No new pass threshold is introduced.
