import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import tempfile
import hashlib

SPEC=importlib.util.spec_from_file_location('ta_preflight',Path(__file__).resolve().parents[1]/'scripts/ta_readonly_preflight.py')
module=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(module)


def message(n=22):
    return SimpleNamespace(imu_state=SimpleNamespace(rpy=[0.,0.,0.],gyro=[0.,0.,0.],acc=[0.,0.,9.81]),
        motor_state_serial=[SimpleNamespace(q=0.,dq=0.,tau_est=0.,mode=0,lost=0) for _ in range(n)],
        motor_state_parallel=[])


class PreflightTest(unittest.TestCase):
    def test_serial_22_and_finite_required(self):
        self.assertTrue(module.state_summary(message())['expected_dimensions_and_finite'])
        self.assertFalse(module.state_summary(message(23))['expected_dimensions_and_finite'])
        self.assertFalse(module.state_summary(message(0))['expected_dimensions_and_finite'])
        bad=message();bad.imu_state.gyro=[0.,float('nan'),0.]
        summary=module.state_summary(bad)
        self.assertFalse(summary['expected_dimensions_and_finite'])
        self.assertIsNone(summary['imu']['gyro'][1])
        json.dumps(summary,allow_nan=False)

    def test_imu_shape_and_motor_infinity_rejected(self):
        bad=message();bad.imu_state.rpy=[0.,0.]
        self.assertFalse(module.state_summary(bad)['expected_dimensions_and_finite'])
        bad=message();bad.motor_state_serial[2].q=float('inf')
        self.assertFalse(module.state_summary(bad)['expected_dimensions_and_finite'])

    def test_dirty_core_does_not_hide_behind_matching_commit(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);path=root/'core.py';path.write_bytes(b'x=1\r\n')
            reference={'commit':'abc','files':{'core.py':hashlib.sha256(b'x=1\n').hexdigest()}}
            with patch.object(module.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='abc\n')):
                self.assertTrue(module.inspect_checkout(root,reference)['core_source_matches'])
                path.write_bytes(b'x=2\n')
                result=module.inspect_checkout(root,reference)
                self.assertTrue(result['matches_reference_commit'])
                self.assertFalse(result['core_source_matches'])
                path.unlink()
                self.assertFalse(module.inspect_checkout(root,reference)['core_source_matches'])

    def test_wrong_commit_reported_even_if_files_match(self):
        with tempfile.TemporaryDirectory() as d:
            with patch.object(module.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='other\n')):
                result=module.inspect_checkout(Path(d),{'commit':'abc','files':{'missing.py':'000'}})
                self.assertFalse(result['matches_reference_commit'])
                self.assertFalse(result['core_source_matches'])


if __name__=='__main__':unittest.main()
