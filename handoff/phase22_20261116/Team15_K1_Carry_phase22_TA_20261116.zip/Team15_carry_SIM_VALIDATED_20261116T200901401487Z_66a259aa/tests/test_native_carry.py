"""Contract, filtering and native controller interface regression tests."""
from copy import deepcopy
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
UPSTREAM=Path(os.environ.get('TEAM15_UPSTREAM_ROOT',ROOT.parents[1]/'reference/booster_deploy_site_cecc00f'))
if not (UPSTREAM/'booster_deploy').is_dir():
    raise unittest.SkipTest('Set TEAM15_UPSTREAM_ROOT to the original booster_deploy checkout for native interface tests')
sys.path.insert(0,str(UPSTREAM))
import tasks
if not hasattr(tasks,'__path__'):
    raise ImportError('An unrelated tasks module hides the upstream tasks package')
tasks.__path__=[str(ROOT/'tasks'),str(UPSTREAM/'tasks'),
               *[p for p in tasks.__path__ if p not in (str(ROOT/'tasks'),str(UPSTREAM/'tasks'))]]
from tasks.team15_carry.contract import JOINT_NAMES, OBSERVATION_ORDER, validate_contract, project_action, load_contract
from tasks.team15_carry.policy import Team15CarryPolicy


def fixture_contract():
    # Deliberately synthetic; never written into a task's models directory.
    return dict(schema='team15-carry-deployment-v1', observation_dim=75, action_dim=22,
        observation_order=OBSERVATION_ORDER, joint_names=list(JOINT_NAMES),
        normalization_included=True, action_scale_included=False, default_joint_offset_included=False,
        no_vision=True, actor_uses_payload_state=False, history_frames=1, control_dt_s=.02,
        nominal_joint_pos_rad=[0.]*22, action_scale_rad=[.5]*22,
        joint_stiffness=[10.]*22, joint_damping=[1.]*22, effort_limit=[14.]*22,
        target_ranges_rad=[[-2., 2.]]*22, command_limits=dict(vx_forward=.15, vx_backward=.1, vy=.1, vyaw=.2),
        action_filter=dict(type='first_order_and_slew', alpha=.35, max_target_speed_rad_s=[3.]*22),
        action_clip=3., previous_action='effective', project_joint_targets=True,
        onnx_sha256='0'*64, source_checkpoint_sha256='1'*64)


class CarryTests(unittest.TestCase):
    def test_official_geometry_profile_has_no_auxiliary_hand_ball(self):
        data=fixture_contract()
        groups={side:[side+'_hand_collision'] for side in ('left','right')}
        braces=['trunk_collision','trunk_lower_collision']
        data['contact_schema']=dict(profile='braced_contact_native_v1',schema_version=2,
            geometry_source='official_k1_mesh',support_groups=groups,brace_geoms=braces,
            support_force_threshold_n=1e-6,max_support_gap_steps=6,
            min_total_support_fraction=.5,min_per_arm_support_fraction=.1,
            payload_attachment='free_body_no_weld_no_assistive_force')
        data['payload_configuration']={'half_size_m':[.1,.2,.06]}
        pair=dict(friction=[.7,.7,.005,.0001,.0001],source='explicit MuJoCo pair',condim=3,
            friction_components=['tangent_1','tangent_2','torsional','rolling_1','rolling_2'],
            solref=[.0105,1.],solimp=[.9,.95,.001,.5,2.])
        data['training_physical_contract']=dict(physics_profile='native_deploy',
            native_physics_audit=dict(source_xml_sha256='2'*64,meshes=[dict(relative_path='mesh.obj',sha256='3'*64)]),
            effective_payload_contact_materials={'robot/'+name:deepcopy(pair) for name in [*groups['left'],*groups['right'],*braces]})
        self.assertIs(validate_contract(data),data)
        wrong=deepcopy(data);wrong['contact_schema']['support_groups']['left'].append('left_hand_end_collision')
        with self.assertRaises(ValueError):validate_contract(wrong)
        wrong=deepcopy(data);wrong['training_physical_contract']['effective_payload_contact_materials']['robot/trunk_lower_collision']['friction']=[.7,.005,.0001]
        with self.assertRaises(ValueError):validate_contract(wrong)
        wrong=deepcopy(data);wrong['training_physical_contract'].pop('native_physics_audit')
        with self.assertRaises(ValueError):validate_contract(wrong)

    def test_final_braced_metadata_contract(self):
        data=fixture_contract()
        groups={side:[side+'_hand_collision',side+'_hand_end_collision'] for side in ('left','right')}
        data['contact_schema']=dict(profile='braced_contact_v1',schema_version=1,support_groups=groups,
            brace_geoms=['trunk_collision'],support_force_threshold_n=1e-6,max_support_gap_steps=6,
            min_total_support_fraction=.5,min_per_arm_support_fraction=.1,
            payload_attachment='free_body_no_weld_no_assistive_force')
        data['payload_configuration']={'half_size_m':[.1,.2,.06]}
        data['training_physical_contract']={'effective_payload_contact_materials':
            {'robot/'+name:{'friction':[.7,.005,.0001]} for name in [*groups['left'],*groups['right'],'trunk_collision']}}
        self.assertIs(validate_contract(data),data)
        data['contact_schema']['payload_attachment']='weld'
        with self.assertRaises(ValueError):validate_contract(data)

    def test_contract_rejects_wrong_schema_and_filter(self):
        for key, value in [('observation_dim',72), ('joint_names',list(reversed(JOINT_NAMES))),
                           ('previous_action','raw'), ('actor_uses_payload_state',True)]:
            data=fixture_contract(); data[key]=value
            with self.subTest(key=key), self.assertRaises(ValueError): validate_contract(data)
        data=fixture_contract(); data['action_filter']['alpha']=0.
        with self.assertRaises(ValueError): validate_contract(data)

    def test_filter_matches_training_formula_and_slew(self):
        data=fixture_contract(); rng=np.random.default_rng(19)
        previous=np.zeros(22, dtype=np.float32)
        for _ in range(100):
            raw=rng.normal(0, 4, 22).astype(np.float32)
            target, effective=project_action(raw, previous, data)
            scale=np.asarray(data['action_scale_rad']); speed=np.asarray(data['action_filter']['max_target_speed_rad_s'])
            expected=previous+np.clip(.35*(np.clip(raw,-3,3)-previous),-speed*.02/scale,speed*.02/scale)
            expected_target=np.clip(expected*scale,-2,2)
            np.testing.assert_allclose(target,expected_target,atol=1e-7)
            np.testing.assert_allclose(effective,target/scale,atol=1e-7)
            self.assertTrue(np.all(np.abs((effective-previous)*scale)<=.06+1e-6))
            previous=effective

    def test_xml_bounds_and_finite_checks(self):
        data=fixture_contract(); data['target_ranges_rad']=[[-.02,.02]]*22
        target,effective=project_action(np.ones(22),np.zeros(22),data)
        np.testing.assert_allclose(target,.02,atol=1e-8)
        np.testing.assert_allclose(effective,.04,atol=1e-8)
        with self.assertRaises(ValueError): project_action(np.full(22,np.nan),np.zeros(22),data)

    def test_missing_model_is_explicit(self):
        with self.assertRaisesRegex(FileNotFoundError,'not exported yet'):
            load_contract(ROOT/'missing_test_only.contract.json')

    def test_missing_model_disables_preparation_but_registers(self):
        from tasks.team15_carry.task import Team15CarryControllerCfg
        with patch('tasks.team15_carry.task.CONTRACT_PATH', ROOT/'missing_test_only.contract.json'):
            cfg=Team15CarryControllerCfg()
        self.assertEqual(cfg.robot.prepare_mode,'unavailable_missing_carry_model')
        self.assertEqual(cfg.vel_command.vx_max,0.)

    def test_native_policy_measured_reset_command_logs_and_fault(self):
        temp_root=ROOT/'.test_tmp'/'native_carry_tests'
        temp_root.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=temp_root) as directory:
            directory=Path(directory); model=directory/'policy.onnx'; model.write_bytes(b'synthetic-test-only')
            data=fixture_contract(); data['onnx_sha256']=hashlib.sha256(model.read_bytes()).hexdigest()
            model.with_suffix('.contract.json').write_text(json.dumps(data),encoding='utf-8')
            from booster_deploy.controllers.base_controller import BoosterRobot
            from booster_deploy.robots.k1 import K1_CFG
            cfg=K1_CFG.replace(joint_names=list(JOINT_NAMES), default_joint_pos=[0.]*22,
                joint_stiffness=[10.]*22,joint_damping=[1.]*22,effort_limit=[14.]*22)
            robot=BoosterRobot(cfg)
            robot.data.joint_pos=torch.ones(22)*.02
            robot.data.root_quat_w=torch.tensor([1.,0.,0.,0.])
            stopped=[]
            controller=SimpleNamespace(robot=robot,cfg=SimpleNamespace(policy_dt=.02,booster=SimpleNamespace(exit_mode='damping')),
                vel_command=SimpleNamespace(lin_vel_x=5.,lin_vel_y=-5.,ang_vel_yaw=5.),stop=lambda:stopped.append(True))
            policy_cfg=SimpleNamespace(checkpoint_path=str(model),device='cpu',start_pose_tolerance_rad=.25,max_trunk_tilt_deg=45.)
            with patch('tasks.team15_carry.policy.create_policy_runner', return_value=lambda obs:torch.ones((1,22))), \
                 patch.dict(os.environ,{'TEAM15_LOG_DIR':str(directory/'logs')}):
                policy=Team15CarryPolicy(policy_cfg,controller); policy.reset()
                np.testing.assert_allclose(policy.last_action,.04)
                obs=policy.compute_observation().numpy()
                np.testing.assert_allclose(obs[50:72],.04)
                np.testing.assert_allclose(obs[72:],[.15,-.1,.2])
                target=policy.inference().numpy()
                self.assertTrue(np.all(np.abs(target-.02)<=.06+1e-6))
                np.testing.assert_allclose(policy.last_action,target/.5)
                policy.close()
                rows=[json.loads(line) for line in policy.log_path.read_text().splitlines()]
                self.assertEqual(rows[0]['initial_effective_action'],obs[50:72].tolist())
                np.testing.assert_allclose(rows[1]['command'],[.15,-.1,.2])
                self.assertIn('actual_upstream_commit',rows[0])
                robot.data.joint_vel[0]=float('nan')
                with self.assertRaises(ValueError): policy.inference()
                self.assertTrue(stopped)


if __name__=='__main__': unittest.main()
