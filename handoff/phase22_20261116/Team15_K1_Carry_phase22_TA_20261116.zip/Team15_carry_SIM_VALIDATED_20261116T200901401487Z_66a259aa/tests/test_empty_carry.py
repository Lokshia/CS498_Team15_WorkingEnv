"""No-box tests remain separate from box-hold qualification."""
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from simulation.empty_qualification import qualify_empty


class EmptyCarryTests(unittest.TestCase):
    @staticmethod
    def trace():
        t=np.arange(1,1001)*.02
        trace={'time_s':t,'robot_tilt_deg':np.zeros(1000),'command':np.zeros((1000,3)),
            'base_velocity':np.zeros((1000,3)),'base_position':np.tile([0.,0.,.52],(1000,1)),
            'obs_actor':np.zeros((1000,75)),'target':np.zeros((1000,22)),'target_speed_rad_s':np.zeros((1000,22)),
            'q':np.zeros((1000,22)),'qd':np.zeros((1000,22)),'foot_contact':np.ones((1000,2),bool),
            'foot_force':np.tile([[0.,0.,100.],[0.,0.,100.]],(1000,1,1)),
            'foot_position_w':np.tile([[0.,.1,0.],[0.,-.1,0.]],(1000,1,1)),'foot_velocity_w':np.zeros((1000,2,3))}
        meta={'seconds':20,'control_dt_s':.02,'scenario':'stand','action_filter':{'max_target_speed_rad_s':[3.]*22}}
        return trace,meta

    def test_standing_empty_success_has_no_box_metrics(self):
        trace,meta=self.trace();result=qualify_empty(trace,meta)
        self.assertTrue(result['empty_hand_passed']);self.assertTrue(result['no_payload_present'])
        self.assertNotIn('box_hold_passed',result);self.assertNotIn('hold_success',result)

    def test_nonmoving_policy_fails_walking_request(self):
        trace,meta=self.trace();trace['command'][150:750,0]=.1;meta['scenario']='walk'
        result=qualify_empty(trace,meta)
        self.assertFalse(result['empty_hand_passed']);self.assertEqual(result['motion']['moving_fraction'],0.)

    def test_missing_command_and_failed_final_stop_are_not_success(self):
        trace,meta=self.trace();meta['scenario']='walk'
        self.assertFalse(qualify_empty(trace,meta)['empty_hand_passed'])
        meta['scenario']='stand';trace['base_velocity'][-100:,0]=.06
        result=qualify_empty(trace,meta)
        self.assertTrue(result['motion']['motion_passed']);self.assertFalse(result['final_stop_settled'])
        self.assertFalse(result['empty_hand_passed'])

    def test_first_target_slew_violation_fails(self):
        trace,meta=self.trace();trace['target_speed_rad_s'][0,0]=4
        self.assertFalse(qualify_empty(trace,meta)['command_slew_passed'])

    def test_crouched_or_fallen_robot_does_not_pass_stillness(self):
        trace,meta=self.trace();trace['base_position'][:,2]=.2
        result=qualify_empty(trace,meta)
        self.assertFalse(result['empty_hand_passed']);self.assertFalse(result['upright_height_passed'])


if __name__=='__main__':unittest.main()
