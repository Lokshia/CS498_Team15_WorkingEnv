"""CPU sim2sim for native carrying policy, with a free box and known force pulses.

Every requested seed is one uninterrupted episode. This does not contact ROS.
The frozen official-asset scene is reused without editing its physical model.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
import math
import os
from pathlib import Path
import sys

import numpy as np

# This package owns its physical overlay and scorer. Importing it does not
# register any historical task or load another policy.
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from simulation import measurements
from simulation.qualification import CRITERIA, QUALIFICATION_METHODS
from simulation.trace import qualify_native


def pulse(time_s, start, duration, peak):
    phase=(time_s-start)/duration
    return peak*math.sin(math.pi*phase)**2 if 0 < phase < 1 else 0.


def command_at(t, seconds, scenario, velocity, profile="ramp"):
    if profile not in ('ramp','step'):raise ValueError('Unknown command profile')
    if scenario not in ('walk','combined'):
        return np.zeros(3)
    if profile=='step':
        return np.asarray(velocity)*float(2. <= t < seconds-5.)
    # Start, carry, stop. Linear command ramps avoid a step at start/end.
    moving_end=seconds-4.
    scale=min(max((t-2.)/1.,0.),1.) * min(max((moving_end-t)/1.,0.),1.)
    return np.asarray(velocity)*scale


def summarize(rows, failure, expected_steps, dt, qualification):
    if not rows:
        return {'passed':False,'failure':failure or 'no_frames','steps_completed':0}
    a=lambda key:np.asarray([row[key] for row in rows])
    scored=qualification['episodes'][0]
    motion=scored['walking'] if scored['walking']['requested'] else scored['standing']
    last=np.arange(len(rows))>=max(0,len(rows)-int(2/dt))
    settled=bool(a('trunk_tilt_deg')[last].max()<10 and a('payload_tilt_deg')[last].max()<15
        and np.linalg.norm(a('body_angular_velocity')[last],axis=1).mean()<.6
        and np.linalg.norm(a('base_linear_velocity_b')[last,:2],axis=1).mean()<.1)
    return dict(passed=scored['combined_qualified'],failure=failure,
        hold_success=scored['box_hold_passed'],
        push_recovered=scored['push'].get('passed'),pressure_recovered=scored['pressure'].get('passed'),
        steps_completed=len(rows),steps_expected=expected_steps,episode_complete=scored['original_episode_complete'],
        locomotion_pass=motion['passed'],settled_final_two_seconds=settled,
        velocity_tracking_rmse_m_s=motion.get('vector_velocity_rmse_m_s'),
        command_direction_velocity_ratio=scored['walking'].get('progress_fraction'),
        moving_fraction=scored['walking'].get('moving_fraction'),
        yaw_tracking_rmse_rad_s=motion.get('yaw_rate_rmse_rad_s'),
        max_trunk_tilt_deg=float(a('trunk_tilt_deg').max()),
        max_payload_tilt_deg=float(a('payload_tilt_deg').max()),
        max_payload_relative_displacement_m=float(a('payload_relative_displacement_m').max()),
        max_no_support_duration_s=float(a('no_support_s').max()),
        horizontal_distance_m=float(np.linalg.norm(a('base_position_w')[-1,:2]-a('base_position_w')[0,:2])),
        joint_velocity_rms_rad_s=float(np.sqrt(np.mean(a('joint_velocity')**2))),
        target_speed_p95_rad_s=np.percentile(np.abs(a('target_speed_rad_s')),95,axis=0).tolist(),
        peak_applied_push_n=float(np.linalg.norm(a('external_trunk_force_n'),axis=1).max()),
        peak_applied_press_n=float(np.abs(a('external_box_force_n')[:,2]).max()),
        formal_qualification=scored)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--deploy-root',type=Path,required=True)
    parser.add_argument('--assets-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--mass',type=float,default=.5)
    parser.add_argument('--seconds',type=float,default=20.)
    parser.add_argument('--seeds',type=int,nargs='+',default=[19013,19014,19015])
    parser.add_argument('--scenario',choices=['stand','walk','push','press','combined','all'],default='all')
    parser.add_argument('--velocity',type=float,nargs=3,default=[.1,0.,0.],metavar=('VX','VY','YAW'))
    parser.add_argument('--command-profile',choices=['ramp','step'],default='ramp')
    parser.add_argument('--push-n',type=float,default=8.)
    parser.add_argument('--press-n',type=float,default=5.)
    parser.add_argument('--push-start',type=float,default=6.)
    parser.add_argument('--press-start',type=float,default=10.)
    parser.add_argument('--push-duration',type=float,default=.3)
    parser.add_argument('--press-duration',type=float,default=1.)
    parser.add_argument('--video',action='store_true',help='Render the first seed of every selected scenario, including failures')
    parser.add_argument('--qualification-method',choices=QUALIFICATION_METHODS,default='instantaneous_v1')
    args=parser.parse_args()
    if args.seconds<8 or args.mass<=0 or min(args.push_n,args.press_n)<0 or min(args.push_duration,args.press_duration)<=0:
        parser.error('Expected >=8 seconds, positive mass/durations and nonnegative force magnitudes')
    args.output.mkdir(parents=True,exist_ok=False)
    sys.path.insert(0,str(args.assets_root/'src'));sys.path.insert(0,str(args.deploy_root))
    import torch
    import mujoco
    torch.set_num_threads(1)
    import tasks.team15_carry
    from tasks.team15_carry.contract import TASK_NAME, load_contract, MODEL_PATH, CONTRACT_PATH, sha256
    from tasks.team15_carry.policy import upstream_revision
    from simulation.simulator import CarryMujocoController
    from booster_deploy.utils.registry import get_task
    contract=load_contract(CONTRACT_PATH,model_path=MODEL_PATH)
    contact_schema=contract.get('contact_schema',{'profile':'strict_forearm_v1'})
    if contact_schema['profile'] in ('braced_contact_v1','braced_contact_native_v1'):
        from simulation import profiles as contact_measurements
    elif contact_schema['profile']=='strict_forearm_v1':
        contact_measurements=measurements
    else:
        raise ValueError('Unknown model contact schema; do not silently use strict or braced scoring')
    caps=contract['command_limits']
    if not (-caps['vx_backward']<=args.velocity[0]<=caps['vx_forward'] and abs(args.velocity[1])<=caps['vy'] and abs(args.velocity[2])<=caps['vyaw']):
        raise ValueError('Requested evaluation velocity exceeds model contract; do not silently clip the test')
    scenarios=['stand','walk','push','press','combined'] if args.scenario=='all' else [args.scenario]
    for scenario in scenarios:
        for which in (['push'] if scenario=='push' else ['press'] if scenario=='press' else ['push','press'] if scenario=='combined' else []):
            if getattr(args,f'{which}_start')+getattr(args,f'{which}_duration')>args.seconds-2:
                raise ValueError('Disturbance must finish at least two seconds before episode end')
    report=dict(schema='team15-native-carry-sim2sim-v1',**upstream_revision(),
        onnx_sha256=sha256(MODEL_PATH),contract_sha256=sha256(CONTRACT_PATH),
        native_task_source_sha256={p.name:sha256(p) for p in sorted(MODEL_PATH.parent.parent.glob('*.py'))},
        harness_sha256=sha256(Path(__file__)),
        scorer_sha256=sha256(Path(__file__).resolve().parents[1]/'simulation/qualification.py'),
        simulation_provenance=json.loads((Path(__file__).resolve().parents[1]/'simulation/PROVENANCE.json').read_text()),
        qualification_criteria=CRITERIA,qualification_method=args.qualification_method,mass_kg=args.mass,seconds=args.seconds,
        requested_scenarios=scenarios,requested_seeds=args.seeds,expected_episode_count=len(scenarios)*len(args.seeds),
        control_dt_s=contract['control_dt_s'],command_filter=contract.get('command_filter'),command_profile=args.command_profile,
        protocol={'velocity':args.velocity,'push_peak_n':args.push_n,'push_duration_s':args.push_duration,
                  'push_start_s':args.push_start,'press_peak_n':args.press_n,'press_duration_s':args.press_duration,
                  'press_start_s':args.press_start,'force_shape':'sin(pi*t/duration)^2 in world frame, applied at body COM',
                  'failure':'base z<0.28m; trunk>35deg; box z<0.2m or initial height-0.15m; box tilt>25deg; box-relative translation>0.15m; loss of bilateral upward forearm support>6 control steps (0.12s); forbidden box contact',
                  'motion':('2s stationary, 1s requested velocity ramp, commanded carry, 1s ramp down, final4s zero request' if args.command_profile=='ramp' else 'Zero request until 2s, requested velocity step until seconds-5, then zero step; policy command filter recorded separately'),
                  'pass':'Same formal qualification core as training scripts/score_carry.py: uninterrupted hold AND directed locomotion/standing AND target slew AND every requested disturbance and recovery.',
                  'recovery':'Entire 0.5-2s recovery window; p95 planar velocity error<=max(0.05m/s,0.5*mean command speed), trunk p95<=10deg, box held, verified pulse direction/peak/impulse. See qualification_criteria.'},
        hardware_validated=False,ros_commands_sent=0,episodes=[],
        limitations=['Uses frozen official-asset box scene; robot geometry/contact/actuator differences from training are reported.',
                     'Starts with arms raised and box supported, not preparation or loading/unloading.',
                     'Stepping and temporary single-foot support are allowed; no static bilateral-foot requirement.',
                     'Applied downward force is pressure disturbance, not an instantaneous change to box mass.',
                     'Policy output logs precede publication; real robot timing and torque saturation are not certified.'])
    for scenario in scenarios:
        for seed_index,seed in enumerate(args.seeds):
            episode_dir=args.output/f'{scenario}_seed{seed}';episode_dir.mkdir()
            os.environ['TEAM15_LOG_DIR']=str(episode_dir/'policy_logs')
            cfg=deepcopy(get_task(TASK_NAME));controller=CarryMujocoController(cfg,args.mass,deployment_contract=contract)
            model,data=controller.mj_model,controller.mj_data
            model_info,layout=contact_measurements.model_audit(controller)
            if not np.allclose(data.qpos[controller.joint_qpos_addresses],contract['nominal_joint_pos_rad'],atol=1e-7):
                raise ValueError('Frozen scene nominal pose differs from this model; explicit scene migration required')
            rng=np.random.default_rng(seed)
            # Small initial velocity variation; every seed is reported.
            data.qvel[controller.root_dof_address:controller.root_dof_address+2]=rng.uniform(-.01,.01,2)
            mujoco.mj_forward(model,data)
            controller.update_state();controller.start()
            box=layout['payload_body'];trunk=layout['trunk'];box_height=float(data.xpos[box,2])
            origin=data.qpos[controller.root_qpos_address:controller.root_qpos_address+2].copy()
            initial_relative=data.xmat[trunk].reshape(3,3).T@(data.xpos[box]-data.xpos[trunk])
            dt=cfg.policy_dt;steps=round(args.seconds/dt);rows=[];failure=None;missing=0.;support_gap=0;previous_target=data.qpos[controller.joint_qpos_addresses].copy()
            renderer=writer=None
            if args.video and seed_index==0:
                import imageio.v2 as imageio
                from PIL import Image,ImageDraw
                model.vis.global_.offwidth=960;model.vis.global_.offheight=720
                renderer=mujoco.Renderer(model,height=720,width=960)
                writer=imageio.get_writer(str(episode_dir/'demo.mp4'),fps=25,codec='libx264',quality=7)
                camera=mujoco.MjvCamera();camera.distance=2.1;camera.azimuth=130;camera.elevation=-15
            forbidden=[False]
            def substep():
                forbidden[0]|=bool(contact_measurements.contact_sample(model,data,layout)['loaded_forbidden_contact'])
            controller.validation_substep_callback=substep
            try:
                for step in range(steps):
                    t=float(data.time);cmd=command_at(t,args.seconds,scenario,args.velocity,args.command_profile)
                    controller.vel_command.lin_vel_x=float(cmd[0]);controller.vel_command.lin_vel_y=float(cmd[1]);controller.vel_command.ang_vel_yaw=float(cmd[2])
                    push=pulse(t,args.push_start,args.push_duration,args.push_n) if scenario in ('push','combined') else 0.
                    press=pulse(t,args.press_start,args.press_duration,args.press_n) if scenario in ('press','combined') else 0.
                    direction=1. if seed_index%2==0 else -1.
                    trunk_force=np.array([0.,direction*push,0.]);box_force=np.array([0.,0.,-press])
                    data.xfrc_applied[:]=0.;data.xfrc_applied[trunk,:3]=trunk_force;data.xfrc_applied[box,:3]=box_force
                    controller.update_state()
                    obs_actor=controller.policy.compute_observation().detach().cpu().numpy().copy()
                    target=controller.policy_step();forbidden[0]=False
                    controller.ctrl_step(target);controller.update_state()
                    row,support_gap=contact_measurements.sample(controller,layout,origin,box_height,support_gap,forbidden[0])
                    missing=support_gap*dt
                    relative=data.xmat[trunk].reshape(3,3).T@(data.xpos[box]-data.xpos[trunk])
                    target_np=target.cpu().numpy()
                    row.update(requested_command=cmd.copy(),command=controller.policy.command.copy(),obs_actor=obs_actor,base_linear_velocity_b=controller.robot.data.root_lin_vel_b.numpy(),
                        body_angular_velocity=controller.robot.data.root_ang_vel_b.numpy(),
                        base_position_w=controller.robot.data.root_pos_w.numpy(),
                        payload_relative_displacement_m=float(np.linalg.norm(relative-initial_relative)),
                        no_support_s=missing,external_trunk_force_n=trunk_force,external_box_force_n=box_force,
                        joint_target=target_np,target_speed_rad_s=(target_np-previous_target)/dt,
                        qpos_full=data.qpos.copy(),qvel_full=data.qvel.copy())
                    foot_bodies=[int(model.geom_bodyid[g]) for g in layout['feet']]
                    foot_velocity=[]
                    for body in foot_bodies:
                        v=np.zeros(6)
                        mujoco.mj_objectVelocity(model,data,mujoco.mjtObj.mjOBJ_XBODY,body,v,0)
                        foot_velocity.append(v[3:].copy())
                    row.update(foot_position_w=data.xpos[foot_bodies].copy(),foot_velocity_w=np.asarray(foot_velocity))
                    rows.append(row);previous_target=target_np.copy()
                    if row['base_height_m']<.28 or row['trunk_tilt_deg']>35:failure='robot_fall_or_large_tilt'
                    elif row['payload_height_m']<max(.2,box_height-.15):failure='box_height_lost'
                    elif row['payload_tilt_deg']>25:failure='box_excessive_tilt'
                    elif row['payload_relative_displacement_m']>.15:failure='box_displaced'
                    elif missing>6*dt+1e-9:failure='forearm_support_lost'
                    elif row['payload_disallowed_contact']:failure='forbidden_box_contact'
                    if renderer is not None and step%2==0:
                        camera.lookat[:]=data.xpos[trunk]+np.array([0.,0.,.1])
                        renderer.update_scene(data,camera=camera)
                        frame=Image.fromarray(renderer.render().copy());draw=ImageDraw.Draw(frame)
                        draw.rectangle([0,0,960,55],fill=(20,20,20))
                        draw.text((12,10),f'{scenario} | t={data.time:.2f}s | box={args.mass:.2f}kg | cmd={cmd.round(2)}',fill='white')
                        draw.text((12,30),f'push={push:.1f}N  press={press:.1f}N  tilt={row["trunk_tilt_deg"]:.1f}deg  box tilt={row["payload_tilt_deg"]:.1f}deg  {failure or ""}',fill='white')
                        writer.append_data(np.asarray(frame))
                    if failure:break
            except (RuntimeError,ValueError) as exc:
                failure=f'{type(exc).__name__}: {exc}'
            finally:
                data.xfrc_applied[:]=0.;controller.stop();controller.policy.close()
                if writer is not None:writer.close()
                if renderer is not None:renderer.close()
            if rows:
                np.savez_compressed(episode_dir/'trajectory.npz',**{key:np.asarray([row[key] for row in rows]) for key in rows[0]})
            evaluation=dict(num_envs=1,seconds=args.seconds,control_dt_s=dt,
                qualification_method=args.qualification_method,
                contact_schema=contact_schema,payload_configuration=contract.get('payload_configuration',{}),
                actual_gravity_m_s2=float(-model.opt.gravity[2]),
                physical_contract=dict(joint_names=list(cfg.robot.joint_names),
                    foot_position_reference='official ankle-roll body origin; world frame'),
                onnx_sha256=sha256(MODEL_PATH),contract_sha256=sha256(CONTRACT_PATH),
                conditions=dict(push_n=args.push_n if scenario in ('push','combined') else 0.,
                    push_duration=args.push_duration,pressure_n=args.press_n if scenario in ('press','combined') else 0.,
                    pressure_duration=args.press_duration),action_filter=contract['action_filter'],
                command_filter=contract.get('command_filter'),command_profile=args.command_profile,
                episodes=[dict(slot=0,completed_without_termination=failure is None and len(rows)==steps)])
            (episode_dir/'evaluation.json').write_text(json.dumps(evaluation,indent=2)+'\n',encoding='utf-8')
            if len(rows)>=2:
                trace,qualification=qualify_native(rows,evaluation)
                np.savez_compressed(episode_dir/'trace.npz',**trace)
                qualified_name=({'braced_contact_native_v1':'qualified_native_braced_evaluation.json',
                    'braced_contact_v1':'qualified_braced_evaluation.json'}.get(contact_schema['profile'],'qualified_evaluation.json'))
                if args.qualification_method!='instantaneous_v1':
                    suffix={'walking_window_v2':'_v2','walking_recovery_window_v3':'_v3'}[args.qualification_method]
                    qualified_name=qualified_name.removesuffix('.json')+suffix+'.json'
                (episode_dir/qualified_name).write_text(json.dumps(qualification,indent=2)+'\n',encoding='utf-8')
                summary=summarize(rows,failure,steps,dt,qualification)
            else:
                summary=dict(passed=False,failure=failure or 'insufficient_trace_frames',steps_completed=len(rows))
            result=dict(scenario=scenario,seed=seed,**summary,model_audit=model_info)
            (episode_dir/'report.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
            report['episodes'].append({key:value for key,value in result.items() if key!='model_audit'})
            report['all_passed']=all(row['passed'] for row in report['episodes'])
            (args.output/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
            print(json.dumps(report['episodes'][-1]),flush=True)
    return 0 if report['all_passed'] else 1


if __name__=='__main__':raise SystemExit(main())
