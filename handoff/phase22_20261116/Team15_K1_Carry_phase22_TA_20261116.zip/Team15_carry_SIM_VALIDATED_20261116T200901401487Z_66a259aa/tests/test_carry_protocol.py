import importlib.util
from pathlib import Path
import unittest
import numpy as np

spec=importlib.util.spec_from_file_location('carry_protocol',Path(__file__).with_name('run_carry_sim.py'))
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
from simulation.trace import qualify_native


class ProtocolTests(unittest.TestCase):
    def test_force_pulse_is_bounded_and_has_known_impulse(self):
        t=np.linspace(0,2,20001)
        values=np.array([protocol.pulse(x,.5,.3,8.) for x in t])
        self.assertAlmostEqual(float(values.max()),8.)
        self.assertAlmostEqual(float(np.trapezoid(values,t)),8*.3/2,places=5)
        self.assertTrue((values[t<.5]==0).all())
        self.assertTrue((values[t>.8]==0).all())

    def test_motion_schedule_has_start_and_stop(self):
        self.assertTrue(np.array_equal(protocol.command_at(0,20,'combined',[.1,0,0]),[0,0,0]))
        np.testing.assert_allclose(protocol.command_at(4,20,'combined',[.1,0,0]),[.1,0,0])
        self.assertTrue(np.array_equal(protocol.command_at(19,20,'combined',[.1,0,0]),[0,0,0]))

    def test_step_input_schedule_and_legacy_ramp_are_distinct(self):
        for time,expected in ((0,0),(1.98,0),(2,.1),(14.98,.1),(15,0),(19,0)):
            self.assertAlmostEqual(protocol.command_at(time,20,'walk',[.1,0,0],'step')[0],expected)
        self.assertAlmostEqual(protocol.command_at(2.5,20,'walk',[.1,0,0])[0],.05)
        self.assertAlmostEqual(protocol.command_at(15.5,20,'walk',[.1,0,0])[0],.05)
        self.assertEqual(protocol.command_at(4,20,'stand',[.1,0,0],'step')[0],0)
        with self.assertRaises(ValueError):protocol.command_at(0,20,'stand',[.1,0,0],'unknown')

    def test_stationary_robot_does_not_pass_walking(self):
        rows=[]
        for i in range(1000):
            rows.append(dict(command=protocol.command_at(i*.02,20,'walk',[.1,0,0]),
                time_s=(i+1)*.02,valid_hold=True,
                base_linear_velocity_b=np.zeros(3),trunk_tilt_deg=0.,payload_tilt_deg=0.,
                body_angular_velocity=np.zeros(3),payload_relative_displacement_m=0.,no_support_s=0.,
                base_position_w=np.array([0.,0.,.5]),joint_velocity=np.zeros(22),target_speed_rad_s=np.zeros(22),
                external_trunk_force_n=np.zeros(3),external_box_force_n=np.zeros(3),
                joint_target=np.zeros(22),foot_contact=np.ones(2,dtype=bool),foot_force_n=np.zeros((2,3)),obs_actor=np.zeros(75)))
        evaluation=dict(num_envs=1,seconds=20,control_dt_s=.02,conditions={},
            action_filter={'max_target_speed_rad_s':[3.]*22},episodes=[{'slot':0,'completed_without_termination':True}])
        _,qualification=qualify_native(rows,evaluation)
        result=protocol.summarize(rows,None,1000,.02,qualification)
        self.assertTrue(result['episode_complete'])
        self.assertFalse(result['passed'])
        self.assertFalse(result['locomotion_pass'])
        self.assertEqual(result['command_direction_velocity_ratio'],0.)

    def test_missing_push_cannot_pass_stable_standing(self):
        trace,meta=self._standing_trace()
        from simulation.qualification import qualify
        result=qualify(trace,meta)['episodes'][0]
        self.assertTrue(result['standing']['passed'])
        self.assertTrue(result['box_hold_passed'])
        self.assertFalse(result['push']['passed'])
        self.assertFalse(result['combined_qualified'])

    def test_recovery_failure_is_in_overall_result(self):
        trace,meta=self._standing_trace()
        from simulation.qualification import qualify
        t=trace['time_s']
        trace['robot_force_n'][:,0,1]=[protocol.pulse(x-.02,6,.3,8) for x in t]
        # Low overall RMS can hide one bad recovery interval. The formal AND
        # must catch it even though holding and standing both pass.
        trace['base_velocity'][(t>=6.8)&(t<=8.3),0,0]=.08
        result=qualify(trace,meta)['episodes'][0]
        self.assertTrue(result['standing']['passed'])
        self.assertTrue(result['push']['force_exercised'])
        self.assertFalse(result['push']['recovered'])
        self.assertFalse(result['combined_qualified'])

    @staticmethod
    def _standing_trace():
        trace={'time_s':np.arange(1,1001)*.02,'active_original_episode':np.ones((1000,1),bool),
            'valid_hold':np.ones((1000,1),bool),'robot_tilt_deg':np.zeros((1000,1)),
            'foot_contact':np.ones((1000,1,2),bool),'foot_force':np.zeros((1000,1,2,3)),
            'target':np.zeros((1000,1,22)),'qd':np.zeros((1000,1,22)),'obs_actor':np.zeros((1000,1,75))}
        for key in ('command','base_velocity','base_position','robot_force_n','box_force_n'):
            trace[key]=np.zeros((1000,1,3))
        meta=dict(num_envs=1,seconds=20,control_dt_s=.02,conditions={'push_n':8,'push_duration':.3},
            action_filter={'max_target_speed_rad_s':[3.]*22},episodes=[{'slot':0,'completed_without_termination':True}])
        return trace,meta


if __name__=='__main__':unittest.main()
