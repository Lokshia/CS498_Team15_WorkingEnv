"""Contact accounting tests: chest support cannot substitute for the arms."""
from pathlib import Path
from copy import deepcopy
import sys
import hashlib
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from simulation.profiles import contact_sample,validate_training_materials,physical_mapping,verify_source_xml


class BracedContactTests(unittest.TestCase):
    def test_canonical_xml_accepts_only_declared_line_ending_change(self):
        crlf=b'<mujoco>\r\n<geom size=".1 .2 .3"/>\r\n</mujoco>\r\n'
        lf=crlf.replace(b'\r\n',b'\n')
        raw_hash=hashlib.sha256(crlf).hexdigest()
        physical={'native_physics_audit':{'source_xml_sha256':raw_hash}}
        mapping=dict(source_xml_sha256=raw_hash,source_xml_canonical_sha256=hashlib.sha256(lf).hexdigest(),
                     source_xml_canonicalization='CRLF_to_LF_only')
        self.assertTrue(verify_source_xml(crlf,physical)['raw_bytes_identical'])
        with self.assertRaises(ValueError):verify_source_xml(lf,physical)
        report=verify_source_xml(lf,physical,mapping)
        self.assertTrue(report['canonical_validation_used']);self.assertFalse(report['raw_bytes_identical'])
        for wrong in (lf.replace(b'.1 .2 .3',b'.1 .2 .4'),lf.rstrip(),lf.replace(b'\n',b'\r')):
            with self.assertRaises(ValueError):verify_source_xml(wrong,physical,mapping)

    def test_native_metadata_uses_actual_five_component_pair_friction(self):
        pair=dict(friction=[.7,.7,.005,.0001,.0001],condim=3,source='explicit MuJoCo pair',
            friction_components=['tangent_1','tangent_2','torsional','rolling_1','rolling_2'],
            solref=[.0105,1.],solimp=[.9,.95,.001,.5,2.])
        names=['left_hand_collision','right_hand_collision','trunk_collision','trunk_lower_collision']
        physical=dict(physics_profile='native_deploy',effective_payload_contact_materials={
            'robot/'+n:deepcopy(pair) for n in names},native_physics_audit=dict(source_xml_sha256='2'*64,
                meshes=[dict(relative_path='mesh.obj',sha256='3'*64)]))
        self.assertEqual(validate_training_materials(physical,'braced_contact_native_v1'),pair['friction'])
        mapping=physical_mapping(['chest1','chest2'],'braced_contact_native_v1',physical)
        self.assertEqual(mapping['support_groups']['left']['training_geoms'],['left_hand_collision'])
        self.assertEqual(mapping['chest']['training_geoms'],['trunk_collision','trunk_lower_collision'])
        self.assertEqual(mapping['effective_pair_friction'],pair['friction'])
        wrong=deepcopy(physical);wrong['effective_payload_contact_materials']['robot/trunk_lower_collision']['friction']=[.7,.005,.0001]
        with self.assertRaises(ValueError):validate_training_materials(wrong,'braced_contact_native_v1')
        wrong=deepcopy(physical);wrong['effective_payload_contact_materials']['robot/trunk_lower_collision']['source']='geom'
        with self.assertRaises(ValueError):validate_training_materials(wrong,'braced_contact_native_v1')
        with self.assertRaises(ValueError):physical_mapping(['chest1','chest2'],'braced_contact_native_v1',{})

    def measure(self,left,right,chest,pressure=0):
        contacts=[SimpleNamespace(geom1=g,geom2=3,frame=np.eye(3)) for g in (1,2,4)]
        forces=[np.array(left),np.array(right),np.array(chest)]
        model=SimpleNamespace(body_mass=np.array([.5]),opt=SimpleNamespace(gravity=np.array([0.,0.,-9.81])))
        data=SimpleNamespace(ncon=3,contact=contacts,xfrc_applied=np.array([[0.,0.,-pressure,0,0,0]]))
        layout=dict(feet=[6,7],support=[1,2],payload_geom=3,ground=8,brace=[4,5],payload_body=0,
            schema=dict(support_force_threshold_n=1e-6,min_total_support_fraction=.5,min_per_arm_support_fraction=.1))
        def force(m,d,index,out):out[:3]=forces[index]
        with patch('mujoco.mj_contactForce',side_effect=force):
            return contact_sample(model,data,layout)

    def test_chest_is_measured_but_cannot_replace_bilateral_support(self):
        result=self.measure([0,0,0],[0,0,0],[1,0,4.905])
        self.assertFalse(result['forbidden_contact'])
        self.assertFalse(result['payload_forearm_supported'])
        self.assertEqual(result['trunk_load_share'],1.)
        self.assertEqual(result['total_arm_load_share'],0.)

    def test_partial_chest_support_requires_both_arm_thresholds(self):
        result=self.measure([0,0,1.5],[0,0,1.5],[1,0,1.905])
        self.assertTrue(result['payload_forearm_supported'])
        self.assertFalse(self.measure([0,0,.2],[0,0,3],[1,0,1.705])['payload_forearm_supported'])

    def test_pressure_changes_reference_and_net_z_is_clamped_after_sum(self):
        baseline=self.measure([0,0,1.5],[0,0,1.5],[1,0,1.905])
        pressure=self.measure([0,0,1.5],[0,0,1.5],[1,0,1.905],5)
        self.assertTrue(baseline['payload_forearm_supported'])
        self.assertFalse(pressure['payload_forearm_supported'])
        self.assertAlmostEqual(pressure['reference_load_n'],9.905)
        negative=self.measure([0,0,-1],[0,0,3],[1,0,1.905])
        self.assertEqual(negative['arm_load_share'][0],0.)

    def test_native_friction_cannot_silently_use_official_chest_default(self):
        names=['left_hand_collision','left_hand_end_collision','right_hand_collision','right_hand_end_collision','trunk_collision']
        material={'effective_payload_contact_materials':{'robot/'+n:{'friction':[.7,.005,.0001]} for n in names}}
        self.assertEqual(validate_training_materials(material),[.7,.005,.0001])
        material['effective_payload_contact_materials']['robot/trunk_collision']['friction'][0]=1.
        with self.assertRaises(ValueError):validate_training_materials(material)
        self.assertIn('mesh',physical_mapping(['chest'])['support_groups']['left']['difference'])


if __name__=='__main__':unittest.main()
