"""Command slew is a policy-step operation, independent of observation reads."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch

from test_native_carry import ROOT, fixture_contract, JOINT_NAMES
from tasks.team15_carry.command_filter import CommandRateLimiter
from tasks.team15_carry.contract import command_filter_for_training, validate_contract
from tasks.team15_carry.policy import Team15CarryPolicy


def filter_contract():
    data=fixture_contract()
    data['command_limits']=dict(vx_forward=.12,vx_backward=0.,vy=0.,vyaw=0.)
    meta=dict(task_schema='k1-proprio-command-carry-v1',control_dt_s=.02,
              conditions=dict(command_stop_time_s=15.,command_stop_ramp_s=1.))
    data['command_filter']=command_filter_for_training(meta,data['command_limits'])
    return data


class NativeCommandFilterTests(unittest.TestCase):
    def test_filter_provenance_and_legacy_contract(self):
        validate_contract(fixture_contract())
        data=filter_contract();validate_contract(data)
        self.assertEqual(data['command_filter']['max_rate_per_s'],[.12,0.,0.])
        for key,value in [('max_rate_per_s',[.2,0,0]),('max_rate_per_s',[.12,.1,0]),
                          ('initial_command',[.12,0,0]),('update_period_s',.01),
                          ('duplicate_step_policy','always_update')]:
            wrong=deepcopy(data);wrong['command_filter'][key]=value
            with self.subTest(key=key), self.assertRaises(ValueError):validate_contract(wrong)

    def test_fifty_step_slew_and_reset_zero(self):
        c=CommandRateLimiter([0,0,0],[.12,0,0],[.12,0,0],.02)
        values=[c.read([1,10,-10],i).applied for i in range(51)]
        np.testing.assert_array_equal(values[0],[0,0,0])
        np.testing.assert_allclose(values[-1],[.12,0,0],atol=1e-14)
        self.assertLessEqual(np.max(np.abs(np.diff(values,axis=0))),.0024+1e-14)
        for tick in range(51,101): last=c.read([0,0,0],tick)
        np.testing.assert_allclose(last.applied,[0,0,0],atol=1e-14)
        c.reset();np.testing.assert_array_equal(c.read([.12,0,0],0).applied,[0,0,0])

    def test_external_ramp_passes_without_second_smoothing(self):
        c=CommandRateLimiter([0,0,0],[.12,0,0],[.12,0,0],.02)
        for tick in range(1000):
            t=tick*.02;request=.1*np.clip(t-2.,0,1)*np.clip(16.-t,0,1)
            np.testing.assert_allclose(c.read([request,0,0],tick).applied,[request,0,0],atol=1e-14)

    def test_policy_repeated_observation_does_not_advance_and_logs_actual(self):
        temp_root=ROOT/'.test_tmp'/'command_filter_tests';temp_root.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=temp_root) as directory:
            directory=Path(directory);model=directory/'policy.onnx';model.write_bytes(b'fake-test-only')
            data=filter_contract();data['onnx_sha256']=hashlib.sha256(model.read_bytes()).hexdigest()
            model.with_suffix('.contract.json').write_text(json.dumps(data),encoding='utf-8')
            from booster_deploy.controllers.base_controller import BoosterRobot
            from booster_deploy.robots.k1 import K1_CFG
            robot=BoosterRobot(K1_CFG.replace(joint_names=list(JOINT_NAMES),default_joint_pos=[0.]*22,
                joint_stiffness=[10.]*22,joint_damping=[1.]*22,effort_limit=[14.]*22))
            robot.data.root_quat_w=torch.tensor([1.,0.,0.,0.])
            controller=SimpleNamespace(robot=robot,cfg=SimpleNamespace(policy_dt=.02,booster=SimpleNamespace(exit_mode='damping')),
                vel_command=SimpleNamespace(lin_vel_x=1.,lin_vel_y=0.,ang_vel_yaw=0.),stop=lambda:None)
            cfg=SimpleNamespace(checkpoint_path=str(model),device='cpu',start_pose_tolerance_rad=.25,max_trunk_tilt_deg=45.)
            observed=[]
            def actor(obs):observed.append(obs.clone());return torch.zeros((1,22))
            with patch('tasks.team15_carry.policy.create_policy_runner',return_value=actor), \
                 patch.dict(os.environ,{'TEAM15_LOG_DIR':str(directory/'logs')}):
                policy=Team15CarryPolicy(cfg,controller);policy.reset()
                for _ in range(4):np.testing.assert_array_equal(policy.compute_observation().numpy()[72:],[0,0,0])
                policy.inference()
                first=policy.compute_observation().numpy()[72:]
                np.testing.assert_allclose(first,[.0024,0,0],atol=1e-9)
                controller.vel_command.lin_vel_x=0.
                for _ in range(4):np.testing.assert_array_equal(policy.compute_observation().numpy()[72:],first)
                policy.inference()
                np.testing.assert_array_equal(observed[-1].numpy()[0,72:],first)
                policy.inference();np.testing.assert_allclose(policy.command,[0,0,0],atol=1e-9)
                policy.close()
                rows=[json.loads(x) for x in policy.log_path.read_text().splitlines()]
                self.assertEqual([r['command_tick'] for r in rows[1:]],[0,1,2])
                np.testing.assert_allclose(rows[2]['requested_command'],[1,0,0])
                np.testing.assert_allclose(rows[2]['clipped_command'],[.12,0,0])
                np.testing.assert_allclose(rows[2]['command'],[.0024,0,0])
                policy.reset();np.testing.assert_array_equal(policy.compute_observation().numpy()[72:],[0,0,0]);policy.close()


if __name__=='__main__':unittest.main()
