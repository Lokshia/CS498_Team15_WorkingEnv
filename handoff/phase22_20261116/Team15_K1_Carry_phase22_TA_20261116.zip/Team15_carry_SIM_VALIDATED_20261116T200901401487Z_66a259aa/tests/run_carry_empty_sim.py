"""Same native carry actor on the unmodified official robot-only MuJoCo scene."""
from __future__ import annotations
import argparse
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from simulation.empty_qualification import qualify_empty
from run_carry_sim import command_at


def feet_sample(model,data,feet,ground):
    import mujoco
    force=np.zeros((2,3));contact=np.zeros(2,bool)
    for i in range(data.ncon):
        c=data.contact[i];pair=(int(c.geom1),int(c.geom2))
        if ground not in pair:continue
        for side,foot in enumerate(feet):
            if foot in pair:
                local=np.zeros(6);mujoco.mj_contactForce(model,data,i,local)
                world=c.frame.reshape(3,3).T@local[:3]
                force[side]+=world if c.geom2==foot else -world;contact[side]=True
    return force,contact


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--deploy-root',type=Path,required=True);p.add_argument('--assets-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=float,default=20)
    p.add_argument('--scenario',choices=['stand','walk','all'],default='all')
    p.add_argument('--seeds',type=int,nargs='+',default=[19013,19014,19015])
    p.add_argument('--velocity',type=float,nargs=3,default=[.1,0,0]);p.add_argument('--video',action='store_true')
    p.add_argument('--command-profile',choices=['ramp','step'],default='ramp')
    a=p.parse_args()
    if a.seconds<8:p.error('Use at least 8 seconds to include start and stop')
    a.output.mkdir(parents=True,exist_ok=False)
    sys.path.insert(0,str(a.assets_root/'src'));sys.path.insert(0,str(a.deploy_root))
    import torch,mujoco
    torch.set_num_threads(1)
    import tasks.team15_carry
    from tasks.team15_carry.contract import TASK_NAME,load_contract,MODEL_PATH,CONTRACT_PATH,sha256
    from tasks.team15_carry.policy import upstream_revision
    from booster_deploy.utils.registry import get_task
    from booster_deploy.controllers.mujoco_controller import MujocoController
    contract=load_contract(CONTRACT_PATH,model_path=MODEL_PATH);caps=contract['command_limits']
    if not (-caps['vx_backward']<=a.velocity[0]<=caps['vx_forward'] and abs(a.velocity[1])<=caps['vy'] and abs(a.velocity[2])<=caps['vyaw']):
        raise ValueError('Requested velocity exceeds model contract')
    scenarios=['stand','walk'] if a.scenario=='all' else [a.scenario]
    report=dict(schema='team15-native-empty-carry-suite-v1',task=TASK_NAME,**upstream_revision(),
        no_payload_present=True,hardware_validated=False,ros_commands_sent=0,
        command_filter=contract.get('command_filter'),command_profile=a.command_profile,
        onnx_sha256=sha256(MODEL_PATH),contract_sha256=sha256(CONTRACT_PATH),harness_sha256=sha256(Path(__file__)),
        scorer_sha256=sha256(Path(__file__).resolve().parents[1]/'simulation/empty_qualification.py'),
        native_task_source_sha256={p.name:sha256(p) for p in sorted(MODEL_PATH.parent.parent.glob('*.py'))},
        requested_scenarios=scenarios,requested_seeds=list(a.seeds),
        expected_episodes=len(scenarios)*len(a.seeds),episodes=[])
    for scenario in scenarios:
        for index,seed in enumerate(a.seeds):
            folder=a.output/f'{scenario}_seed{seed}';folder.mkdir();os.environ['TEAM15_LOG_DIR']=str(folder/'policy_logs')
            cfg=deepcopy(get_task(TASK_NAME));controller=MujocoController(cfg)
            # The scripted sequence replaces stdin polling only; native PD and
            # model integration are otherwise the original controller methods.
            controller.update_vel_command=lambda:None
            model,data=controller.mj_model,controller.mj_data
            asset=Path(controller._expand_assets_placeholder(cfg.robot.mjcf_path));asset_hash=sha256(asset)
            if (model.nq,model.nv,model.nu,model.njnt)!=(29,28,22,23) or model.neq!=0:
                raise ValueError('Expected only a free robot with 22 hinges, no box or constraints')
            joint_ids=np.array([model.joint(n).id for n in cfg.robot.joint_names])
            if not np.array_equal(model.jnt_qposadr[joint_ids],np.arange(7,29)) or not np.array_equal(model.jnt_dofadr[joint_ids],np.arange(6,28)):
                raise ValueError('Original controller slices do not match configured joint order')
            if not np.array_equal(model.actuator_trnid[:,0],joint_ids):raise ValueError('Actuator mapping mismatch')
            if int((model.jnt_type==mujoco.mjtJoint.mjJNT_FREE).sum())!=1:raise ValueError('Unexpected extra free body')
            feet=[];foot_bodies=[]
            for side in ('left','right'):
                body=model.body(side+'_ankle_roll_link').id
                candidates=[g for g in range(model.ngeom) if model.geom_bodyid[g]==body
                    and model.geom_type[g]==mujoco.mjtGeom.mjGEOM_BOX and (model.geom_contype[g] or model.geom_conaffinity[g])]
                if len(candidates)!=1:raise ValueError('Expected one original sole box per foot')
                feet+=candidates;foot_bodies.append(body)
            trunk=model.body('trunk').id;ground=model.geom('ground').id
            data.qvel[:2]=np.random.default_rng(seed).uniform(-.01,.01,2)
            mujoco.mj_forward(model,data);controller.update_state();controller.start()
            rows=[];failure=None;dt=cfg.policy_dt;steps=round(a.seconds/dt);previous=data.qpos[7:].copy()
            initial_joint_position=previous.copy()
            renderer=writer=None
            if a.video and index==0:
                import imageio.v2 as imageio
                from PIL import Image,ImageDraw
                model.vis.global_.offwidth=960;model.vis.global_.offheight=720
                renderer=mujoco.Renderer(model,height=720,width=960);writer=imageio.get_writer(str(folder/'empty_hand_demo.mp4'),fps=25,codec='libx264',quality=7)
                camera=mujoco.MjvCamera();camera.distance=2.1;camera.azimuth=130;camera.elevation=-15
            try:
                for step in range(steps):
                    cmd=command_at(float(data.time),a.seconds,scenario,a.velocity,a.command_profile)
                    controller.vel_command.lin_vel_x=float(cmd[0]);controller.vel_command.lin_vel_y=float(cmd[1]);controller.vel_command.ang_vel_yaw=float(cmd[2])
                    controller.update_state();obs=controller.policy.compute_observation().detach().cpu().numpy().copy()
                    target=controller.policy_step();controller.ctrl_step(target);controller.update_state()
                    force,contact=feet_sample(model,data,feet,ground);rotation=data.xmat[trunk].reshape(3,3)
                    velocity_b=rotation.T@data.qvel[:3]
                    tilt=float(np.degrees(np.arccos(np.clip(rotation[2,2],-1,1))))
                    foot_velocity=[]
                    for body in foot_bodies:
                        velocity=np.zeros(6);mujoco.mj_objectVelocity(model,data,mujoco.mjtObj.mjOBJ_XBODY,body,velocity,0)
                        foot_velocity.append(velocity[3:])
                    target_np=target.cpu().numpy().copy()
                    rows.append(dict(time_s=float(data.time),requested_command=cmd.copy(),command=controller.policy.command.copy(),obs_actor=obs,
                        q=data.qpos[7:].copy(),qd=data.qvel[6:].copy(),target=target_np,
                        target_speed_rad_s=(target_np-previous)/dt,base_velocity=velocity_b,
                        base_position=data.qpos[:3].copy(),robot_tilt_deg=tilt,
                        foot_contact=contact,foot_force=force,foot_position_w=data.xpos[foot_bodies].copy(),
                        foot_velocity_w=np.asarray(foot_velocity),actuator_torque=data.qfrc_actuator[6:].copy(),
                        qpos_full=data.qpos.copy(),qvel_full=data.qvel.copy()))
                    previous=target_np
                    if data.qpos[2]<.28 or tilt>35:failure='robot_fall_or_large_tilt'
                    if renderer is not None and step%2==0:
                        camera.lookat[:]=data.xpos[trunk]+[0,0,.1];renderer.update_scene(data,camera=camera)
                        frame=Image.fromarray(renderer.render().copy());draw=ImageDraw.Draw(frame)
                        draw.rectangle([0,0,960,48],fill=(20,20,20));draw.text((12,10),f'NO BOX | {scenario} | t={data.time:.2f}s | cmd={cmd.round(2)} | tilt={tilt:.1f} deg',fill='white')
                        writer.append_data(np.asarray(frame))
                    if failure:break
            except (RuntimeError,ValueError) as exc:failure=f'{type(exc).__name__}: {exc}'
            finally:
                controller.stop();controller.policy.close()
                if writer is not None:writer.close()
                if renderer is not None:renderer.close()
            if sha256(asset)!=asset_hash:raise RuntimeError('Official source asset changed')
            metadata=dict(seconds=a.seconds,scenario=scenario,control_dt_s=dt,no_payload_present=True,action_filter=contract['action_filter'],
                initial_joint_position=initial_joint_position.tolist(),command_filter=contract.get('command_filter'),command_profile=a.command_profile,
                physical_contract=dict(joint_names=list(cfg.robot.joint_names)),onnx_sha256=report['onnx_sha256'],
                contract_sha256=report['contract_sha256'],asset_sha256=asset_hash,nq=model.nq,nv=model.nv,nu=model.nu,
                free_joints=1,equality_constraints=0,robot_mass_kg=float(model.body_mass.sum()),
                controller='Original upstream MujocoController; only stdin command polling replaced by declared sequence',
                body_velocity_note='Diagnostic world linear velocity rotated into trunk frame; actor has no linear-velocity input')
            trace={k:np.asarray([r[k] for r in rows]) for k in rows[0]} if rows else {}
            if trace:np.savez_compressed(folder/'empty_trace.npz',**trace)
            result=qualify_empty(trace,metadata,failure) if trace else dict(empty_hand_passed=False,failure=failure or 'no_frames')
            result.update(scenario=scenario,seed=seed)
            (folder/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
            (folder/'empty_qualification.json').write_text(json.dumps(result,indent=2)+'\n')
            report['episodes'].append(result);report['all_empty_hand_passed']=all(r['empty_hand_passed'] for r in report['episodes'])
            (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
            print(json.dumps(dict(scenario=scenario,seed=seed,passed=result['empty_hand_passed'],failure=failure,motion=result.get('motion'))),flush=True)
    return 0 if report['all_empty_hand_passed'] else 1


if __name__=='__main__':raise SystemExit(main())
