import importlib.util
from pathlib import Path
import tempfile
import unittest
import json
import hashlib

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('team15_task_installer', ROOT / 'install.py')
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


class InstallTests(unittest.TestCase):
    def temporary(self):
        root=ROOT/'.test_tmp'/'installer_tests'
        root.mkdir(parents=True,exist_ok=True)
        return tempfile.TemporaryDirectory(dir=root)

    def test_copy_preserves_upstream_and_refuses_overwrite(self):
        with self.temporary() as temporary:
            root = Path(temporary)/'deploy'; source = Path(temporary)/'task'
            for name in ('scripts/deploy.py', 'booster_deploy/robots/k1.py',
                         'booster_deploy/controllers/base_controller.py',
                         'booster_deploy/controllers/booster_robot_controller.py',
                         'booster_deploy/controllers/controller_cfg.py', 'booster_deploy/utils/registry.py'):
                path = root/name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b'# original\n')
            (root/'tasks').mkdir()
            (source/'models').mkdir(parents=True)
            (source/'__init__.py').write_bytes(b'# task\n')
            (source/'models/proprio_hold.onnx').write_bytes(b'fake model for copy test')
            (source/'__pycache__').mkdir()
            (source/'__pycache__/cached.pyc').write_bytes(b'no')
            receipt, dest = installer.install(root, source, task='hold')
            self.assertTrue(receipt['upstream_source_unchanged'])
            self.assertFalse((dest/'__pycache__').exists())
            self.assertEqual((dest/'__init__.py').read_bytes(), b'# task\n')
            repeated, _ = installer.install(root, source, task='hold')
            self.assertTrue(repeated['already_installed_identically'])
            (dest/'__init__.py').write_bytes(b'# local modification\n')
            with self.assertRaises(FileExistsError):
                installer.install(root, source, task='hold')

    def test_wrong_root_fails_without_creating_task(self):
        with self.temporary() as temporary:
            root = Path(temporary)
            with self.assertRaises(ValueError):
                installer.install(root, root)
            self.assertFalse((root/'tasks/team15_hold').exists())

    def test_carry_requires_complete_matching_model(self):
        with self.temporary() as temporary:
            root=Path(temporary)/'deploy'; source=Path(temporary)/'task'
            for name in ('scripts/deploy.py','booster_deploy/robots/k1.py',
                         'booster_deploy/controllers/base_controller.py',
                         'booster_deploy/controllers/booster_robot_controller.py',
                         'booster_deploy/controllers/controller_cfg.py','booster_deploy/utils/registry.py'):
                path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b'# original')
            (root/'tasks').mkdir();(source/'models').mkdir(parents=True)
            (source/'__init__.py').write_bytes(b'# task')
            for name in ('contract.py','policy.py','task.py','check.py'):
                (source/name).write_bytes((ROOT/'tasks/team15_carry'/name).read_bytes())
            model=source/'models/policy.onnx';model.write_bytes(b'copy test only')
            with self.assertRaisesRegex(ValueError,'requires ONNX'):
                installer.install(root,source)
            self.assertFalse((root/'tasks/team15_carry').exists())
            (source/'models/policy.test_vectors.npz').write_bytes(b'copy test only')
            contract=source/'models/policy.contract.json'
            contract.write_text(json.dumps({'schema':'team15-carry-deployment-v1','onnx_sha256':'0'*64}))
            with self.assertRaisesRegex(ValueError,'mismatch'):installer.install(root,source)
            contract_spec=importlib.util.spec_from_file_location('fixture_contract_module',source/'contract.py')
            contract_module=importlib.util.module_from_spec(contract_spec);contract_spec.loader.exec_module(contract_module)
            metadata=dict(schema='team15-carry-deployment-v1',observation_dim=75,action_dim=22,
                observation_order=contract_module.OBSERVATION_ORDER,joint_names=list(contract_module.JOINT_NAMES),
                normalization_included=True,action_scale_included=False,default_joint_offset_included=False,
                no_vision=True,actor_uses_payload_state=False,history_frames=1,control_dt_s=.02,
                nominal_joint_pos_rad=[0.]*22,action_scale_rad=[.5]*22,joint_stiffness=[10.]*22,
                joint_damping=[1.]*22,effort_limit=[14.]*22,target_ranges_rad=[[-2.,2.]]*22,
                command_limits=dict(vx_forward=.1,vx_backward=.1,vy=.1,vyaw=.1),
                action_filter=dict(type='first_order_and_slew',alpha=.35,max_target_speed_rad_s=[3.]*22),
                action_clip=3.,previous_action='effective',project_joint_targets=True,
                source_checkpoint_sha256='0'*64,onnx_sha256=hashlib.sha256(model.read_bytes()).hexdigest())
            contract.write_text(json.dumps(metadata))
            receipt,dest=installer.install(root,source)
            self.assertEqual(receipt['task'],'k1_team15_carry')
            self.assertEqual(dest.name,'team15_carry')


if __name__ == '__main__':
    unittest.main()
