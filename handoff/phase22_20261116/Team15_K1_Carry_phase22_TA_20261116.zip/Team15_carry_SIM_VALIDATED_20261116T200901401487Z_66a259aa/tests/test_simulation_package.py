"""Integrity of self-contained simulation; no MuJoCo/ROS/old model import."""
import ast
import hashlib
import json
from pathlib import Path
import unittest

PACKAGE=Path(__file__).resolve().parents[1]
PROJECT=PACKAGE.parents[1]
SIMULATION=PACKAGE/'simulation'


def definitions(path):
    tree=ast.parse(path.read_text(encoding='utf-8-sig'))
    return {node.name:ast.dump(node,include_attributes=False) for node in tree.body
            if isinstance(node,(ast.FunctionDef,ast.ClassDef))}


class SimulationPackageTests(unittest.TestCase):
    def test_extracted_files_match_recorded_hashes(self):
        manifest=json.loads((SIMULATION/'PROVENANCE.json').read_text())
        for name,expected in manifest['outputs'].items():
            self.assertEqual(hashlib.sha256((SIMULATION/name).read_bytes()).hexdigest(),expected,name)

    def test_formal_scorer_functions_and_constants_are_identical(self):
        source=PROJECT/'scripts/score_carry.py'
        if not source.exists():
            self.skipTest('Training source not included in a standalone deployment package')
        original=definitions(source)
        for name,value in definitions(SIMULATION/'qualification.py').items():
            self.assertEqual(value,original[name],name)
        def constants(path):
            tree=ast.parse(path.read_text(encoding='utf-8-sig'))
            return {n.targets[0].id:ast.dump(n.value,include_attributes=False) for n in tree.body
                if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)
                and n.targets[0].id in ('SCHEMA','CRITERIA','BRACED_SCHEMA','BRACED_CRITERIA','NATIVE_BRACED_SCHEMA',
                    'NATIVE_BRACED_CRITERIA','BRACED_PROFILES','MOTION_DIAGNOSTICS',
                    'QUALIFICATION_METHODS','WALKING_WINDOW_S','STOPPING_CRITERIA','RECOVERY_WINDOW_CRITERIA')}
        self.assertEqual(constants(source),constants(SIMULATION/'qualification.py'))

    def test_no_legacy_task_imports_or_models(self):
        for path in SIMULATION.glob('*.py'):
            tree=ast.parse(path.read_text(encoding='utf-8-sig'))
            for node in ast.walk(tree):
                if isinstance(node,ast.ImportFrom):
                    self.assertNotIn('team15_proprio',node.module or '',str(path))
                if isinstance(node,ast.Import):
                    self.assertFalse(any('team15_proprio' in alias.name for alias in node.names),str(path))
        self.assertFalse(list(SIMULATION.rglob('*.onnx')))
        self.assertFalse(list(SIMULATION.rglob('*.pt')))

    def test_archived_physics_sources_remain_unchanged(self):
        old=PROJECT/'deployment/team15_proprio_package/tasks/team15_proprio'
        if not old.exists():
            self.skipTest('Archived source not included in standalone deployment package')
        manifest=json.loads((SIMULATION/'PROVENANCE.json').read_text())
        for name in ('scene','simulator'):
            self.assertEqual(hashlib.sha256((old/(name+'.py')).read_bytes()).hexdigest(),
                             manifest['sources'][name]['sha256'])


if __name__=='__main__':unittest.main()
