"""Release evidence gates, especially false-ready rejection."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import json
import tempfile
import unittest
import numpy as np

spec=importlib.util.spec_from_file_location('carry_packager',Path(__file__).resolve().parents[1]/'package_release.py')
package=importlib.util.module_from_spec(spec);spec.loader.exec_module(package)


def coverage():
    rows=[]
    for scenario in package.SCENARIOS:
        for seed in (101,102,103):
            rows.append(dict(scenario=scenario,seed=seed,mass_kg=.5,seconds=20.,passed=True,
                relative_directory=f'{scenario}_seed{seed}',issues=[],conditions=dict(push_n=8,push_duration=.3,pressure_n=3,pressure_duration=1)))
    return [dict(directory='acceptance',stress_only=False,issues=[],episodes=rows)]


def empty_coverage():
    rows=[dict(scenario='stand',seed=seed,seconds=20.,passed=True,issues=[],
        relative_directory=f'stand_seed{seed}') for seed in (101,102,103)]
    return [dict(directory='empty',issues=[],episodes=rows)]


def gate(data,masses):
    return package.qualification_gate(data,masses,empty_evidence=empty_coverage())


class PackageGateTests(unittest.TestCase):
    def test_validated_requires_all_scenarios_and_distinct_seeds(self):
        data=coverage();self.assertTrue(gate(data,[.5])['passed'])
        for row in data[0]['episodes']:row['seed']=101
        self.assertFalse(gate(data,[.5])['passed'])

    def test_standing_or_hold_success_cannot_mask_one_failed_walk(self):
        data=coverage();next(x for x in data[0]['episodes'] if x['scenario']=='walk')['passed']=False
        self.assertFalse(gate(data,[.5])['passed'])

    def test_missing_mass_duration_or_force_envelope_refuses(self):
        self.assertFalse(gate(coverage(),[.5,1.])['passed'])
        data=coverage();data[0]['episodes'][0]['seconds']=19.9
        self.assertFalse(gate(data,[.5])['passed'])
        data=coverage()
        for row in data[0]['episodes']:row['conditions']['pressure_n']=.1
        self.assertFalse(gate(data,[.5])['passed'])

    def test_stress_failures_are_retained_but_do_not_expand_acceptance(self):
        data=coverage();stress=deepcopy(data[0]);stress['directory']='stress';stress['stress_only']=True
        for row in stress['episodes']:row['passed']=False;row['mass_kg']=5.
        data.append(stress)
        self.assertTrue(gate(data,[.5])['passed'])
        self.assertFalse(gate(data,[.5,5.])['passed'])
        stress['issues'].append('onnx_sha256 mismatch')
        self.assertFalse(gate(data,[.5])['passed'])

    def test_empty_standing_requires_three_twenty_second_original_seeds(self):
        self.assertFalse(package.qualification_gate(coverage(),[.5])['passed'])
        data=empty_coverage();data[0]['episodes'][0]['seconds']=19.9
        self.assertFalse(package.qualification_gate(coverage(),[.5],empty_evidence=data)['passed'])
        data=empty_coverage();data[0]['episodes'][0]['passed']=False
        self.assertFalse(package.qualification_gate(coverage(),[.5],empty_evidence=data)['passed'])

    def test_empty_walk_failure_is_retained_but_does_not_expand_scope(self):
        data=empty_coverage();data[0]['episodes'].append(dict(scenario='walk',seed=101,seconds=20.,passed=False,
            issues=[],relative_directory='walk_seed101'))
        result=package.qualification_gate(coverage(),[.5],empty_evidence=data)
        self.assertTrue(result['passed']);self.assertFalse(result['empty_walking_results'][0]['passed'])
        self.assertFalse(result['empty_walking_required_for_box_carry_release'])

    def test_empty_model_integrity_issue_blocks_even_with_passed_standings(self):
        data=empty_coverage();data[0]['issues'].append('onnx_sha256 mismatch')
        self.assertFalse(package.qualification_gate(coverage(),[.5],empty_evidence=data)['passed'])

    def test_v2_requires_explicit_single_method_in_all_evidence(self):
        data=coverage();data[0]['qualification_method']='walking_window_v2'
        self.assertFalse(gate(data,[.5])['passed'])
        kwargs=dict(empty_evidence=empty_coverage(),qualification_method='walking_window_v2')
        self.assertTrue(package.qualification_gate(data,[.5],**kwargs)['passed'])
        stress=deepcopy(data[0]);stress['stress_only']=True;stress['qualification_method']='instantaneous_v1'
        data.append(stress)
        self.assertFalse(package.qualification_gate(data,[.5],**kwargs)['passed'])

    def test_v3_cannot_mix_v2_acceptance_or_stress(self):
        data=coverage();data[0]['qualification_method']='walking_recovery_window_v3'
        kwargs=dict(empty_evidence=empty_coverage(),qualification_method='walking_recovery_window_v3')
        self.assertTrue(package.qualification_gate(data,[.5],**kwargs)['passed'])
        self.assertFalse(gate(data,[.5])['passed'])
        stress=deepcopy(data[0]);stress['stress_only']=True;stress['qualification_method']='walking_window_v2'
        data.append(stress)
        self.assertFalse(package.qualification_gate(data,[.5],**kwargs)['passed'])

    def test_command_trace_requires_exact_request_replay_and_actor_input(self):
        contract=dict(control_dt_s=.02,command_limits=dict(vx_backward=0.,vx_forward=.12,vy=0.,vyaw=0.),
            command_filter=dict(max_rate_per_s=[.12,0.,0.]))
        meta=dict(command_filter=contract['command_filter'])
        requested=np.zeros((100,3));requested[10:60,0]=.1
        applied=np.zeros_like(requested)
        for i in range(1,100):applied[i]=applied[i-1]+np.clip(requested[i]-applied[i-1],-.0024,.0024)
        obs=np.zeros((100,75));obs[:,-3:]=applied
        trace=dict(requested_command=requested,command=applied,obs_actor=obs)
        self.assertEqual(package.command_trace_issues(trace,meta,contract,batched=False),[])
        trace['command']=requested
        self.assertTrue(package.command_trace_issues(trace,meta,contract,batched=False))
        trace['command']=applied;trace['obs_actor'][:,-3:]=requested
        self.assertTrue(package.command_trace_issues(trace,meta,contract,batched=False))
        del trace['requested_command']
        self.assertTrue(package.command_trace_issues(trace,meta,contract,batched=False))

    def test_allowlist_excludes_old_weights_and_environments(self):
        paths=[p.relative_to(package.HERE).as_posix() for p in package.allowed_sources()]
        self.assertTrue(any(p.startswith('tasks/team15_carry/') for p in paths))
        self.assertFalse(any(any(term in p for term in ('team15_hold','hardware_bridge','.venv','__pycache__','policy.onnx')) for p in paths))
        self.assertIn('scripts/ta_readonly_preflight.py',paths)
        self.assertIn('scripts/cecc_core_reference.json',paths)
        self.assertIn('docs/QUALIFICATION_METHODS_ZH.md',paths)

    def test_supplements_bind_identity_and_retain_failures(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);report=root/'failed_report.json';report.write_text(json.dumps(dict(checkpoint_sha256='ckpt',passed=False)))
            item=dict(source=str(report),relative_path='gpu/report.json',sha256=package.sha(report))
            manifest=dict(schema='team15-carry-supplement-v1',source_checkpoint_sha256='ckpt',onnx_sha256='onnx',hardware_validated=False,
                groups=[dict(name='GPU failures',interpretation='not acceptance',files=[item],identities=[dict(source=str(report),kind='checkpoint',key_path=['checkpoint_sha256'])])])
            path=root/'manifest.json';path.write_text(json.dumps(manifest))
            result=package.inspect_supplements(path,dict(source_checkpoint_sha256='ckpt'),{'policy.onnx':'onnx'})
            self.assertFalse(result[0]['included_in_acceptance_counts'])
            self.assertEqual(json.loads(report.read_text())['passed'],False)
            manifest['source_checkpoint_sha256']='another';path.write_text(json.dumps(manifest))
            with self.assertRaises(ValueError):package.inspect_supplements(path,dict(source_checkpoint_sha256='ckpt'),{'policy.onnx':'onnx'})

    def test_supplements_reject_traversal_duplicate_and_wrong_identity(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);report=root/'report.json';report.write_text(json.dumps(dict(checkpoint_sha256='wrong')))
            item=dict(source=str(report),relative_path='gpu/report.json',sha256=package.sha(report))
            group=dict(name='GPU',interpretation='not acceptance',files=[item],identities=[dict(source=str(report),kind='checkpoint',key_path=['checkpoint_sha256'])])
            manifest=dict(schema='team15-carry-supplement-v1',source_checkpoint_sha256='ckpt',onnx_sha256='onnx',hardware_validated=False,groups=[group])
            path=root/'manifest.json'
            for relative in ('../escape.json','C:/escape.json','bad.onnx'):
                item['relative_path']=relative;path.write_text(json.dumps(manifest))
                with self.assertRaises(ValueError):package.inspect_supplements(path,dict(source_checkpoint_sha256='ckpt'),{'policy.onnx':'onnx'})
            item['relative_path']='gpu/report.json';path.write_text(json.dumps(manifest))
            with self.assertRaises(ValueError):package.inspect_supplements(path,dict(source_checkpoint_sha256='ckpt'),{'policy.onnx':'onnx'})
            report.write_text(json.dumps(dict(checkpoint_sha256='ckpt')));item['sha256']=package.sha(report)
            group['files']=[item,item];path.write_text(json.dumps(manifest))
            with self.assertRaises(ValueError):package.inspect_supplements(path,dict(source_checkpoint_sha256='ckpt'),{'policy.onnx':'onnx'})


if __name__=='__main__':unittest.main()
