"""Install only the Team15 task into an existing, working booster_deploy checkout.

Does not install dependencies, edit upstream source, contact ROS, or start motors.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import importlib.util

REFERENCE_COMMIT = 'cecc00fc019de3c640af2d0421059b59a2e080c1'
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def install(deploy_root: Path, source: Path | None = None, *, task: str = 'carry'):
    if task not in ('carry', 'hold'):
        raise ValueError('Expected task carry, or explicit historical hold')
    folder = f'team15_{task}'
    task_name = f'k1_team15_{task}'
    root = deploy_root.resolve(strict=True)
    source = source or HERE / 'tasks' / folder
    source = source.resolve(strict=True)
    required = ('scripts/deploy.py', 'booster_deploy/robots/k1.py',
                'booster_deploy/controllers/base_controller.py',
                'booster_deploy/controllers/booster_robot_controller.py',
                'booster_deploy/controllers/controller_cfg.py',
                'booster_deploy/utils/registry.py')
    for relative in required:
        if not (root / relative).is_file():
            raise ValueError(f'Not the expected booster_deploy root: missing {relative}')
    tasks = root / 'tasks'
    if not tasks.is_dir() or tasks.is_symlink():
        raise ValueError('Expected an existing, non-symlink tasks directory')
    destination = tasks / folder
    files = sorted(p for p in source.rglob('*') if p.is_file()
                   and '__pycache__' not in p.parts and p.suffix in ('.py', '.json', '.onnx', '.npz'))
    prefix = 'policy' if task == 'carry' else 'proprio_hold'
    model = source / f'models/{prefix}.onnx'
    if not files or not (source / '__init__.py').is_file() or not model.is_file():
        raise ValueError('Incomplete Team15 source package')
    if task == 'carry':
        for code_name in ('contract.py', 'policy.py', 'task.py', 'check.py'):
            if not (source / code_name).is_file():
                raise ValueError(f'Incomplete carry source: missing {code_name}')
        contract_path = source / f'models/{prefix}.contract.json'
        vectors = source / f'models/{prefix}.test_vectors.npz'
        if not contract_path.is_file() or not vectors.is_file():
            raise ValueError('Carry installation requires ONNX, contract and export test vectors')
        contract = json.loads(contract_path.read_text(encoding='utf-8'))
        if contract.get('schema') != 'team15-carry-deployment-v1' or contract.get('onnx_sha256') != sha(model):
            raise ValueError('Carry model or contract mismatch')
        # Validate before copying: malformed task configuration would otherwise
        # break upstream recursive registration, including unrelated tasks.
        contract_spec = importlib.util.spec_from_file_location('carry_install_contract', source / 'contract.py')
        contract_module = importlib.util.module_from_spec(contract_spec)
        contract_spec.loader.exec_module(contract_module)
        contract_module.validate_contract(contract)
        expected_vectors = contract.get('test_vectors_sha256')
        if expected_vectors is not None and expected_vectors != sha(vectors):
            raise ValueError('Carry test-vector hash mismatch')
    before = {relative: sha(root / relative) for relative in required}
    try:
        revision = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'],
                                           text=True, stderr=subprocess.DEVNULL).strip()
    except (OSError, subprocess.CalledProcessError):
        revision = None
    already_installed = destination.exists()
    if already_installed:
        if destination.is_symlink() or not destination.is_dir():
            raise FileExistsError(f'Unsafe/non-directory destination: {destination}')
        expected = {p.relative_to(source).as_posix(): sha(p) for p in files}
        existing = {p.relative_to(destination).as_posix(): sha(p) for p in destination.rglob('*')
                    if p.is_file() and '__pycache__' not in p.parts and p.name != 'INSTALL_RECEIPT.json'}
        if expected != existing:
            raise FileExistsError(f'{destination} differs; nothing overwritten. Archive the existing task explicitly before installing another version.')
    else:
        # No recursive replacement/deletion. Failed copies remain visible.
        destination.mkdir()
        for path in files:
            target = destination / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            with path.open('rb') as src, target.open('xb') as dst:
                shutil.copyfileobj(src, dst)
            if sha(path) != sha(target):
                raise RuntimeError(f'Copied file hash mismatch: {target}')
    after = {relative: sha(root / relative) for relative in required}
    if before != after:
        raise RuntimeError('Upstream source changed during installation')
    receipt = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'task': task_name, 'upstream_commit': revision, 'actual_upstream_commit': revision,
        'reference_commit': REFERENCE_COMMIT,
        'matches_reference_commit': revision == REFERENCE_COMMIT,
        'upstream_source_sha256': before, 'upstream_source_unchanged': True,
        'installed_files': {p.relative_to(source).as_posix(): sha(p) for p in files},
        'robot_connected': False, 'hardware_validated': False,
        'already_installed_identically': already_installed,
    }
    if not already_installed:
        with (destination / 'INSTALL_RECEIPT.json').open('x', encoding='utf-8') as file:
            json.dump(receipt, file, indent=2); file.write('\n')
    return receipt, destination


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--deploy-root', type=Path, required=True)
    parser.add_argument('--task', choices=('carry', 'hold'), default='carry',
                        help='Default: new carrying task. hold is historical compatibility only.')
    args = parser.parse_args()
    receipt, destination = install(args.deploy_root, task=args.task)
    print(f'Installed: {destination}')
    print('Upstream controller / deploy.py: unchanged')
    if not receipt['matches_reference_commit']:
        print('Note: upstream revision differs or is unknown; run the offline check before using this task.')
    print('Next, from booster_deploy root:')
    print('  python3 scripts/deploy.py --list')
    print(f'  python3 -m tasks.team15_{args.task}.check')
    print('No robot control was started.')


if __name__ == '__main__':
    main()
