# 只交一个 native carry 包

包内只有 `k1_team15_carry`、当前三件模型文件、安装/录包脚本、自包含仿真、中文说明、测试和指定评测。不会收旧 hold、hardware_bridge、虚拟环境、cache、历史权重或整份训练 runs。

训练机需要 NumPy 和 ONNX Runtime。模型目录还必须有与实际 ONNX/contract hash 对应的 `export_report.json`。打包时会重跑 ONNX 测试向量，并保存 numeric parity 报告的 hash。

## 诊断包

```powershell
python deployment/booster_deploy_task/package_release.py --model-dir runs/export_candidate --evaluation-dir runs/native_candidate --empty-evaluation-dir runs/native_empty_candidate --mode diagnostic
```

名称固定包含 `DIAGNOSTIC_NOT_QUALIFIED`。包中写明尚未通过，不可以通过改输出名字生成“current”或“validated”。失败和未覆盖条件都会记录。

## 通过仿真资格的交接包

先完成同一候选的原生独立评测。最低每个指定质量、每种场景（stand、walk、push、press、combined）各3个不同 seed、各20秒。侧推至少8 N/0.3秒，压箱至少3 N/1秒。每个原始 episode 都要通过正式评分。

另需同一模型在纯机器人场景下通过 **3 个不同 seed、各20秒的空手零命令站立**，供放箱之前的起步阶段验证。使用 `tests/run_carry_empty_sim.py --scenario all` 同时记录空手启停/行走；这些行走结果单列，不混进托箱成功率，也不要求它们作为带箱资格的一部分。若空手行走未通过，空手阶段只能给零速度指令。此测试不包括实际抬臂、加载和控制模式切换。

```powershell
python deployment/booster_deploy_task/package_release.py --model-dir reports/prototypes/native_posture_runs/phase22_stop12_anchor1_final3450_native/export --evaluation-dir reports/prototypes/native_posture_runs/phase22_stop12_anchor1_final3450_extended_native/comparison_loaded --empty-evaluation-dir reports/prototypes/native_posture_runs/phase22_stop12_anchor1_final3450_extended_native/empty_stand --required-mass 0.5 --qualification-method walking_recovery_window_v3 --supplement-manifest reports/phase22_ta_supplements_20261116.json --mode validated
```

`--evaluation-dir` 是要全部通过的验收条件；`--stress-dir` 是超出该范围的压力测试，可失败但必须完整保留结果，不能混入通过率。所有记录必须属于同一模型、原生 task 源码和正式评分器版本。

`--empty-evaluation-dir` 可重复指定。打包器检查没有箱体的模型维度，核对同一 ONNX/contract/source hash，从 `empty_trace.npz` 重算站立、启停和目标限速，保留未通过的空手行走结果。缺少3个完整空手站立 seed 会拒绝 validated；不会把历史模型的空手结果贴到新模型上。

本轮采用上述0.5 kg、0.1 m/s、8 N/0.3 s侧推及3 N/1 s压箱的v3协议，不声明1 kg或3–5 kg通过。附包的只读preflight、cecc核心清单及评分方法说明都在明确白名单中。

`--supplement-manifest` 仅附加同一候选的GPU、下肢施力等扩展证据，不改变验收门槛或把它们混进15条原生通过率。清单必须是`team15-carry-supplement-v1`，绑定checkpoint/ONNX hash及`hardware_validated:false`；每组列出JSON身份报告的key_path、每个文件的实际路径、包内相对路径和SHA-256。打包器拒绝其他模型、未包含的身份报告、路径穿越、重复目标、额外权重或哈希变化。报告中的失败原样保留。

默认资格方法为 `instantaneous_v1`。若原生测试显式选择 `walking_window_v2`，打包命令也必须加 `--qualification-method walking_window_v2`；全部验收及压力测试必须使用同一方法，不能混用v1/v2来选择较好结果。v2的1秒窗口只衡量平均行走跟踪，不是无抖动保证；原始速度/yaw误差、关节频谱、全部失败仍随包保存。v2的移动后停稳使用原始速度、yaw和漂移，不平滑；1秒过渡后不足2秒观察也会失败。

打包器重新从每份 `trace.npz` 和 `evaluation.json` 计算正式资格。原地不动、漏施加扰动、恢复失败、手臂没有实际承重、模型 hash 不匹配或缺少独立 seed，都会拒绝 validated 包。不会只相信报告里的 `passed`。

生成 `releases/Team15_carry_SIM_VALIDATED_.../` 和同名 ZIP。stage、ZIP、receipt 都保留；`MANIFEST.json` 包含每个文件大小和 SHA-256，receipt 含 ZIP hash。`RELEASE_STATUS.json` 保存源文件 hash、模型 hash、导出一致性和全部验收/压力测试结果。不会发布到 GitHub。

**SIM_VALIDATED 只指列明条件的仿真最低资格。** `hardware_validated` 始终为 false，不代表全面鲁棒性或真机验证，也不外推到未测的3–5 kg。

现场安装和启动沿用本包 README：`python3 install.py --deploy-root ~/booster_deploy`，然后在原仓库运行 `scripts/deploy.py --list` 与 `python3 -m tasks.team15_carry.check`。安装器仅添加 task；无需 TA 再改官方 ROS 控制器和关节映射。


### 显式 v3 与遥控器命令

需要 v3 时，测试和打包都传 `--qualification-method walking_recovery_window_v3`。接受测试及附带失败压力测试必须同一方法；旧 v1/v2 报告不能混用。方法定义见 [QUALIFICATION_METHODS_ZH.md](QUALIFICATION_METHODS_ZH.md)。新模型的 command filter、全部 task Python 源码（包括 command_filter.py）、原始请求/实际 actor 命令和 ONNX 一并绑定。打包重放每一步命令限速并检查 actor 观测末三维，不能只用“曲线看起来平滑”作为证据。
