# 本地候选替换和独立复测

这是开发机流程，不是机器人启动入口。现场沿用包根目录 `README_ZH.md` 的原版 `scripts/deploy.py --task k1_team15_carry`。

## 固定目录

当前全部试验输出放在 `D:\Inventories\CS498\Team15-Robot\runs`。不再向旧 Booster-track、v040 工作目录写新结果。

```powershell
$teamProject = 'D:\Inventories\CS498\Team15-Robot'
$teamPython = "$teamProject\.venv\Scripts\python.exe"
$teamPackage = "$teamProject\deployment\booster_deploy_task"
$teamDeploy = "$teamProject\reference\booster_deploy_site_cecc00f"
$teamAssets = 'D:\Inventories\CS498\Team15-Robot\references\booster_assets'
```

`reference` 是与现场同 SHA 的本地原版仓库；`references/booster_assets` 是当前固定版本的官方资产。旧报告里的 `_archive` 或移动前路径是历史记录，不应改写。新导出会记录仅 CRLF→LF 的规范 XML hash，允许 Windows/Linux 行尾差异；mesh 仍严格逐字节校验。TA 不需要这些 Windows 路径或 `.venv`。

## 新候选模型先隔离暂存

新模型导出目录必须同时有 `policy.onnx`、`policy.contract.json`、`policy.test_vectors.npz` 和 `export_report.json`。不手动改模型 hash，不把不同候选文件混用。

先生成明确的诊断暂存包，不要求它已经通过运动资格：

```powershell
& $teamPython "$teamPackage\package_release.py" --model-dir "$teamProject\runs\export_candidate" --mode diagnostic --output-root "$teamProject\runs\candidate_stage"
```

把命令实际输出的 `stage` 路径记为 `$teamStage`。它是该候选完整源码与模型的冻结副本。此时只在 `runs` 暂存，不放进正式 `tasks/team15_carry/models`，不发布 Git，不称 validated。

安装器不会覆盖原版仓库已有的不同 task。替换前先停止本地仿真，把 **本地** `$teamDeploy\tasks\team15_carry` 移到 `runs` 内一个新的备份目录。备份必须在 `tasks` 外，因为原版会递归注册所有 task；不要删除旧证据，也不要改机器人上的任务。

```powershell
# teamStage 填上一步输出的真实 stage 路径；不要填旧版本。
& $teamPython "$teamStage\install.py" --deploy-root $teamDeploy
Push-Location $teamDeploy
& $teamPython scripts/deploy.py --list
& $teamPython -m tasks.team15_carry.check
Pop-Location
```

应看到 `k1_team15_carry`、`offline_check_passed: true`，以及 actual/reference 都是 `cecc00fc019de3c640af2d0421059b59a2e080c1`。这几条不启动机器人或仿真。`check` 不是行走成功证明。

## 独立原生 MuJoCo 验证

保持 task/模型不变，用同一冻结暂存包的测试脚本。每次用新的输出目录；失败的原始 episode 和日志不能用重置后的片段替换。

```powershell
& $teamPython "$teamStage\tests\run_carry_sim.py" --deploy-root $teamDeploy --assets-root $teamAssets --output "$teamProject\runs\native_candidate_0p5kg" --mass 0.5 --seconds 20 --scenario all --seeds 19013 19014 19015 --velocity 0.1 0 0 --push-n 8 --press-n 3 --video
& $teamPython "$teamStage\tests\run_carry_empty_sim.py" --deploy-root $teamDeploy --assets-root $teamAssets --output "$teamProject\runs\native_empty_candidate" --seconds 20 --scenario all --seeds 19013 19014 19015 --velocity 0.1 0 0 --video
```

带箱为 stand、walk、push、press、combined 共15个原始 episode；空手为 stand、walk 共6个。空手场景真的没有箱体。空手站立是正式交接门槛；空手行走单列，未通过就限制空手阶段零速度。仅测0.5 kg不能声明1 kg或3–5 kg通过。

上述命令默认 `instantaneous_v1`。若本批试验事先选用1秒平均行走跟踪方法，带箱命令加 `--qualification-method walking_window_v2`，最后打包也加同一参数。v2不是消除抖动的证明；停稳和推压恢复仍使用原始数据。不要测完后把不同方法的较好结果混进同一交接资格。

所有接口均在本地 MuJoCo 中运行，没有 ROS 控制发布。模型与接口的真实硬件表现仍需现场确认；抬臂准备、放箱和模式切换没有被这些测试覆盖。

## 最后打包

用同一冻结 `$teamStage\package_release.py`，按 `PACKAGING_ZH.md` 提供导出目录、带箱评测和 `--empty-evaluation-dir`。它会重算资格并绑定源代码/模型 hash。若模型、task 或评分器已经改变，先重新评测；不修改旧报告来消除 hash 不匹配。

门槛没有通过时，只能生成 `DIAGNOSTIC_NOT_QUALIFIED`。`SIM_VALIDATED` 也仅指列出的仿真条件，`hardware_validated` 保持 false。


### 新命令接口与恢复方法

`--command-profile step` 测试遥控器阶跃启动/停止；默认 `ramp` 保留此前轨迹。新 contract 的 `command_filter` 在 policy 内限速，每个 50 Hz tick 仅推进一次。记录里的 `requested_command` 是输入请求，`command` 是实际 actor 看到的值。空手入口支持同一参数。

`walking_recovery_window_v3` 为显式新评测方法，旧报告不覆盖。完整定义、限制和命令见 [QUALIFICATION_METHODS_ZH.md](QUALIFICATION_METHODS_ZH.md)。平均误差不能说明没有关节抽搐。
