# 评测方法版本与适用范围

默认仍为 `instantaneous_v1`。旧报告不改名、不覆盖，也不重新宣称通过。

| 显式方法 | 行走速度与偏航跟踪 | 外力后的恢复 | 停稳 |
| --- | --- | --- | --- |
| `instantaneous_v1` | 原始逐帧误差 | 原始逐帧误差 | 旧方法未单独检查 |
| `walking_window_v2` | 完整连续 1 秒内的有符号误差均值 | 原始逐帧误差 | 原始数据，显式门槛 |
| `walking_recovery_window_v3` | 与 v2 相同 | 移动时用完整 1 秒的有符号 XY 误差均值；站立仍为原始逐帧误差 | 与 v2 相同 |

v3 只改变一个问题：持续行走时，外力撤去后的**平均速度是否恢复到命令**。步态本身会让瞬时速度周期摆动，所以同时保留 `raw_recovery_velocity_error_p95_m_s`。低频平均误差通过，不能证明没有抽搐或高频振动；实测关节速度、踝关节频谱、接触力仍须单独看。

恢复区间仍为实际施力结束后 0.5–2.0 秒。只有整个区间都为同一个非零移动命令，才使用 v3 的平均：先在每个完整连续 1 秒内分别平均有符号 x/y 误差，再求二维模长，最后取所有窗口的 p95。每条控制区间的两端都必须在恢复区间内。阈值仍为 `max(0.05 m/s, 0.5 × 平均命令速度)`。

恢复区间出现启停、速度改变、转向，v3 直接拒绝该项，不能挑出容易的片段。原始 episode 不完整、恢复区间不完整、缺少完整窗口或缺少实际外力记录，都不能通过。零命令站立继续用原始误差；倾角、箱高、双臂真实承力、实际行进距离、停稳、目标限速和施力验证均不放宽。

v3 报告使用独立 `..._v3.json` 和 `...qualification-v3` schema。打包时所有接受测试及附带压力测试必须明确采用同一方法；不同方法的结果不能混成一个已验证包。最终使用 v3 时，必须冻结源码和模型，用新 seed 重新跑全套独立测试。旧轨迹上的重算只用于方法比较。

```powershell
python tests/run_carry_sim.py --deploy-root <booster_deploy目录> --assets-root <booster_assets目录> --output <新的结果目录> --scenario all --mass 0.5 --seconds 20 --seeds 19101 19102 19103 --velocity 0.1 0 0 --push-n 8 --press-n 3 --qualification-method walking_recovery_window_v3
```

同一个模型可以另外运行 `--command-profile step`，测试原版遥控器突然给速度或停止命令。默认 `ramp` 保留原有 1 秒请求斜坡。新模型 contract 的 `command_filter` 在 policy 内逐控制步限速，回放保存 `requested_command`（操作者请求）和 `command`（实际 actor 输入），两者不混用。
