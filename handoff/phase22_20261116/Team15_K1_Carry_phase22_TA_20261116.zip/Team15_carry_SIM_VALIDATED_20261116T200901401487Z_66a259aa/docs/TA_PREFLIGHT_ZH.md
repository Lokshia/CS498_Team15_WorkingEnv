# 现场只读检查

在TA原本可以运行walking的Python3.10/ROS Humble环境，先安装完整carry task，再从解压包目录执行：

```bash
python3 scripts/ta_readonly_preflight.py --deploy-root ~/booster_deploy --benchmark --native-runner --ros-seconds 3 --output preflight_trial01.json
```

检查固定cecc提交的8个核心文件（只规范CRLF→LF）、ONNX与向量哈希和数值一致性、原版CpuOnnxRunner的推理耗时。可选订阅low_state检查22串联电机、三维IMU、有限性与接收间隔，并只读查询joint_ctrl发布者。

脚本不实例化controller，不创建电机指令publisher，不调用RPC，不切模式。ROS订阅会正常参与DDS发现。发布者数量不能证明控制权已交接。

- 没安装task时先省略`--benchmark --native-runner`。
- 完全离线时省略`--ros-seconds 3`。
- 每次换一个输出文件名，不覆盖前次结果。
- benchmark仅ONNX前向，不含ROS、控制调度和电机延迟，不能替代50Hz完整控制周期测量。

本地已测试消息形状/非有限值、源码修改检测和cecc版本检测，并用原版runner完成数值比较。没有在ARM64或真实ROS网络运行订阅分支。检查通过是环境证据，不是机器人操作许可、任务稳定性或硬件认证。
