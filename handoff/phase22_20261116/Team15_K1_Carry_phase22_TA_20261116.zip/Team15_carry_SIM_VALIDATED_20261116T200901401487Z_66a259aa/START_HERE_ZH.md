# Team15 原生部署交接

**通过列明条件的独立仿真资格；没有真机验证。**

唯一任务是 `k1_team15_carry`，使用原版 booster_deploy。

```bash
python3 install.py --deploy-root ~/booster_deploy
cd ~/booster_deploy
python3 scripts/deploy.py --list
python3 -m tasks.team15_carry.check
```

这几步不发送控制命令。现场操作、录包和启动顺序见 README_ZH.md；资格范围和全部失败压力测试见 RELEASE_STATUS.json。
资格与已知限制以 RELEASE_STATUS.json 及 README_ZH.md 为准；若附带 validation/extended/，其中结果单列，不混入验收通过率，也不代表所有外力都能恢复。
通过仿真门槛不等于直线行走、均匀双脚承重或完全无抖动；本包没有真机认证。
空手站立和空手行走单列。空手行走未通过时，空手阶段只给零速度指令，不把托箱行走结果外推为空手步态。
安装只新增 task，不需要 TA 再手改官方控制器或关节映射。同名旧 task 内容不同会拒绝覆盖，先移到 tasks 外备份。
