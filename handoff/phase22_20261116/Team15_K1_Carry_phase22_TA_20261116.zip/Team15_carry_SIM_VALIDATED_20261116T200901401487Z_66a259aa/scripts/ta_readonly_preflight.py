"""Read-only TA diagnostics. No controller, publisher, RPC, or motor commands.

Python 3.10 compatible. Keep this script beside cecc_core_reference.json.
This is an environment diagnostic, not a policy or hardware certification.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import types


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect_checkout(root, reference):
    revision = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'],
        capture_output=True, text=True, timeout=10)
    actual = revision.stdout.strip() if revision.returncode == 0 else None
    files = {}
    for relative, expected in reference['files'].items():
        path = root / relative
        raw = path.read_bytes() if path.is_file() else None
        # Source text may have Git checkout CRLF; compare normalized LF bytes.
        sha = hashlib.sha256(raw.replace(b'\r\n', b'\n')).hexdigest() if raw is not None else None
        files[relative] = {'sha256_lf': sha, 'matches': sha == expected}
    return {'actual_commit': actual, 'reference_commit': reference['commit'],
        'matches_reference_commit': actual == reference['commit'],
        'core_source_matches': all(v['matches'] for v in files.values()), 'files': files,
        'scope': 'Pinned core source files only; other tasks/assets/dependencies are not certified.'}


def state_summary(message):
    serial = message.motor_state_serial
    vectors = {name: [float(v) for v in getattr(message.imu_state, name)]
               for name in ('rpy', 'gyro', 'acc')}
    motors = {name: [float(getattr(m, name)) for m in serial]
              for name in ('q', 'dq', 'tau_est')}
    finite = all(math.isfinite(x) for values in [*vectors.values(), *motors.values()] for x in values)
    vectors = {name:[x if math.isfinite(x) else None for x in v] for name,v in vectors.items()}
    motors = {name:[x if math.isfinite(x) else None for x in v] for name,v in motors.items()}
    return {'serial_count': len(serial), 'parallel_count': len(message.motor_state_parallel),
        'expected_dimensions_and_finite': len(serial) == 22 and finite and all(len(v) == 3 for v in vectors.values()),
        'imu': vectors, 'serial': motors, 'motor_modes': [int(m.mode) for m in serial],
        'motor_lost_counters': [int(m.lost) for m in serial],
        'limitations': 'Shape/finiteness only. Does not validate joint direction, calibration, safety mode, or source latency.'}


def receive_state(seconds):
    import rclpy
    from rclpy.context import Context
    from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
    from booster_interface.msg import LowState, LowCmd, MotorCmd
    from booster_interface.srv import RpcService
    del RpcService  # Import checks installed type; no clients are created.
    fields={name:cls().get_fields_and_field_types() for name,cls in
        [('LowState',LowState),('LowCmd',LowCmd),('MotorCmd',MotorCmd)]}
    required={'LowState':{'imu_state','motor_state_serial','motor_state_parallel'},
        'LowCmd':{'cmd_type','motor_cmd'},'MotorCmd':{'mode','q','dq','tau','kp','kd','weight'}}
    schema_ok=all(names.issubset(fields[name]) for name,names in required.items())
    context = Context()
    rclpy.init(args=[], context=context)
    node = rclpy.create_node('team15_readonly_preflight', context=context,
        enable_rosout=False, start_parameter_services=False)
    samples, arrivals = [], []
    def callback(msg):
        arrivals.append(time.perf_counter())
        samples.append(state_summary(msg))
    try:
        node.create_subscription(LowState, '/low_state', callback,
            QoSProfile(depth=5, reliability=ReliabilityPolicy.BEST_EFFORT,
                       durability=DurabilityPolicy.VOLATILE))
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            rclpy.spin_once(node, timeout_sec=min(.1, max(0., end-time.monotonic())))
        publishers = node.get_publishers_info_by_topic('/joint_ctrl')
        gaps = [(b-a)*1000 for a,b in zip(arrivals, arrivals[1:])]
        return {'message_imports_ok': True, 'cmd_type_serial': int(LowCmd.CMD_TYPE_SERIAL),
            'serial_enum_matches': int(LowCmd.CMD_TYPE_SERIAL) == 1,
            'message_fields':fields,'required_message_fields_present':schema_ok,
            'sample_count': len(samples), 'all_received_states_valid': bool(samples) and all(s['expected_dimensions_and_finite'] for s in samples),
            'first_state': samples[0] if samples else None, 'last_state': samples[-1] if samples else None,
            'max_receive_gap_ms': max(gaps) if gaps else None,
            'joint_ctrl_publishers_at_end': [{'node': p.node_name, 'namespace': p.node_namespace,
                'type': p.topic_type} for p in publishers],
            'observation_only': True, 'motor_command_publishers_created': 0, 'rpc_clients_created': 0,
            'limitations': 'DDS discovery snapshot and local receipt times only; no ownership claim or motor watchdog.'}
    finally:
        node.destroy_node()
        rclpy.shutdown(context=context)


def benchmark_model(task_dir, repetitions):
    import numpy as np
    import onnxruntime as ort
    model = task_dir / 'models/policy.onnx'
    contract_path = task_dir / 'models/policy.contract.json'
    vectors_path = task_dir / 'models/policy.test_vectors.npz'
    contract = json.loads(contract_path.read_text(encoding='utf-8'))
    if digest(model) != contract['onnx_sha256'] or digest(vectors_path) != contract['test_vectors_sha256']:
        raise ValueError('Model/test-vector bytes differ from contract')
    options = ort.SessionOptions()
    options.intra_op_num_threads = options.inter_op_num_threads = 1
    session = ort.InferenceSession(str(model), options, providers=['CPUExecutionProvider'])
    inp, out = session.get_inputs(), session.get_outputs()
    if len(inp) != 1 or len(out) != 1 or inp[0].shape != [1,75] or out[0].shape != [1,22]:
        raise ValueError('Expected [1,75] -> [1,22] model')
    with np.load(vectors_path, allow_pickle=False) as vectors:
        observations = np.asarray(vectors['observations'], dtype=np.float32)
        expected = np.asarray(vectors['actions'], dtype=np.float32)
    if observations.ndim != 2 or observations.shape[1] != 75 or not len(observations) or expected.shape != (len(observations),22):
        raise ValueError('Malformed parity vectors')
    if not np.isfinite(observations).all() or not np.isfinite(expected).all():
        raise ValueError('Nonfinite parity vectors')
    predicted = np.concatenate([session.run(None, {inp[0].name: x[None]})[0] for x in observations])
    error = float(np.max(np.abs(predicted-expected)))
    if not math.isfinite(error) or error > 1e-4:
        raise ValueError('Model parity failed: '+str(error))
    for _ in range(20):
        session.run(None, {inp[0].name: observations[:1]})
    timings=[]
    for i in range(repetitions):
        start=time.perf_counter()
        session.run(None, {inp[0].name: observations[i % len(observations)][None]})
        timings.append((time.perf_counter()-start)*1000)
    return {'onnx_sha256': digest(model), 'ort_version': ort.__version__,
        'vector_count': len(observations), 'parity_max_absolute_error': error,
        'timing_repetitions': repetitions, 'single_thread_cpu_inference_ms': {
            name:float(np.percentile(timings, p)) for name,p in [('p50',50),('p95',95),('p99',99),('max',100)]},
        'control_period_ms': float(contract['control_dt_s'])*1000,
        'limitations': 'ONNX forward pass only; excludes ROS, Torch observation processing, controller scheduling and actuator latency.'}


def inspect_native_runner(root, repetitions=300):
    """Import only this audited task's definitions, not recursive task registration."""
    import numpy as np
    import torch
    sys.path.insert(0,str(root))
    # A namespace avoids running tasks/__init__.py or unrelated site tasks.
    task_dir=root/'tasks/team15_carry'
    namespace='team15_preflight_scoped'
    package=types.ModuleType(namespace);package.__path__=[str(task_dir)]
    sys.modules[namespace]=package
    policy=importlib.import_module(namespace+'.policy')
    if not hasattr(policy,'Team15CarryPolicy'):
        raise ValueError('Native task policy class missing')
    contract_module=importlib.import_module(namespace+'.contract')
    contract=contract_module.load_contract(task_dir/'models/policy.contract.json',model_path=task_dir/'models/policy.onnx')
    if digest(task_dir/'models/policy.test_vectors.npz') != contract['test_vectors_sha256']:
        raise ValueError('Native test-vector hash mismatch')
    from booster_deploy.utils.policy_runner import create_policy_runner
    runner=create_policy_runner(str(task_dir/'models/policy.onnx'),torch.device('cpu'),use_actor_module=False)
    with np.load(task_dir/'models/policy.test_vectors.npz',allow_pickle=False) as vectors:
        observations=np.asarray(vectors['observations'],dtype=np.float32)
        expected=np.asarray(vectors['actions'],dtype=np.float32)
    if observations.ndim!=2 or observations.shape[1]!=75 or not len(observations) or expected.shape!=(len(observations),22):
        raise ValueError('Malformed native test-vector dimensions')
    if not np.isfinite(observations).all() or not np.isfinite(expected).all():
        raise ValueError('Nonfinite native test vectors')
    maximum=0.
    for obs, action in zip(observations,expected):
        actual=runner(torch.from_numpy(obs)).detach().numpy().reshape(22).copy()
        maximum=max(maximum,float(np.max(np.abs(actual-action))))
        if not np.isfinite(actual).all():raise ValueError('Nonfinite native runner output')
    if maximum>1e-4:raise ValueError('Native runner numeric parity failed')
    timings=[]
    for i in range(repetitions):
        obs=torch.from_numpy(observations[i % len(observations)])
        start=time.perf_counter();runner(obs)
        timings.append((time.perf_counter()-start)*1000)
    return {'scoped_policy_import_ok':True,'controller_constructed':False,'torch_version':torch.__version__,
        'onnx_sha256':digest(task_dir/'models/policy.onnx'),
        'task_source_sha256':{p.name:digest(p) for p in sorted(task_dir.glob('*.py'))},
        'runner_class':type(runner).__name__, 'vector_count':len(observations),'parity_max_absolute_error':maximum,
        'native_cpu_runner_ms':{name:float(np.percentile(timings,p)) for name,p in [('p50',50),('p95',95),('p99',99),('max',100)]},
        'limitations':'Native runner with its own default ORT options and I/O binding; still excludes live state processing and motor publishing.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--deploy-root', type=Path, required=True)
    parser.add_argument('--reference', type=Path, default=Path(__file__).with_name('cecc_core_reference.json'))
    parser.add_argument('--ros-seconds', type=float, default=0, help='0: offline only; >0: subscribe without publishing commands')
    parser.add_argument('--benchmark', action='store_true')
    parser.add_argument('--native-runner',action='store_true',help='Scoped task imports plus original CPU inference runner; no controller construction')
    parser.add_argument('--output', type=Path)
    args=parser.parse_args()
    if not math.isfinite(args.ros_seconds) or not 0 <= args.ros_seconds <= 30:
        parser.error('--ros-seconds must be between 0 and 30')
    root=args.deploy_root.resolve(strict=True)
    report={'schema':'team15-readonly-preflight-prototype-v1',
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'host':{'architecture':platform.machine(),'python':platform.python_version(),
            'ros_distro':os.environ.get('ROS_DISTRO'), 'ros_domain_id':os.environ.get('ROS_DOMAIN_ID')},
        'hardware_validated':False, 'deployment_authorized_by_this_report':False, 'errors':[]}
    for name, operation in [('checkout',lambda:inspect_checkout(root,json.loads(args.reference.read_text(encoding='utf-8')))),
        ('model', lambda:benchmark_model(root/'tasks/team15_carry',300) if args.benchmark else {'skipped':True}),
        ('ros',lambda:receive_state(args.ros_seconds) if args.ros_seconds else {'skipped':True})]:
        try: report[name]=operation()
        except Exception as exc: report['errors'].append({'check':name,'error':f'{type(exc).__name__}: {exc}'})
    if args.native_runner:
        try:
            if not report.get('checkout',{}).get('core_source_matches') or not report['checkout']['matches_reference_commit']:
                raise ValueError('Refusing native imports because pinned checkout check did not pass')
            report['native_runner']=inspect_native_runner(root)
        except Exception as exc:report['errors'].append({'check':'native_runner','error':f'{type(exc).__name__}: {exc}'})
    output=json.dumps(report,indent=2,allow_nan=False)+'\n'
    if args.output:
        with args.output.open('x',encoding='utf-8') as stream: stream.write(output)
    print(output,end='')
    checkout=report.get('checkout',{})
    failed=bool(report['errors']) or not checkout.get('matches_reference_commit') or not checkout.get('core_source_matches')
    if args.ros_seconds:
        failed |= not report.get('ros',{}).get('all_received_states_valid',False)
        failed |= not report.get('ros',{}).get('serial_enum_matches',False)
        failed |= not report.get('ros',{}).get('required_message_fields_present',False)
    raise SystemExit(2 if failed else 0)


if __name__=='__main__': main()
