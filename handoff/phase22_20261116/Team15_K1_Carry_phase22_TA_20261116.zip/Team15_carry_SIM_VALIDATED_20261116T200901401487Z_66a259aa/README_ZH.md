# Team15：原版 booster_deploy 无视觉托箱任务

本轮只有一个交付候选：`k1_team15_carry`。使用官方 `scripts/deploy.py`、ROS 控制器和遥控器，不使用独立 hardware bridge。

模型来自 phase22 final3450（停步姿态改善版），checkpoint SHA-256：
`a2451e547f6bb232b36e289c4dea478fa11d23322fa44a7f0ff1bfbf67fabd10`。
ONNX SHA-256：`66a259aa480bd6eb6f4fc9667ebdb3bbf1464b85f805e4cf23edcb7623edadb4`。

**这是通过列明条件的仿真候选，尚未完成真机验证。** 已测试 0.5 kg、慢速前进 0.1 m/s、峰值侧推 8 N/0.3 秒、向下压箱 3 N/1 秒。原生五场景各3个对照种子、每条20秒，15/15通过；真正空手零命令站立3/3通过。GPU8/8、新seed91827三场3/3、停步后晚推压诊断单独记录，不合并成总体成功率。模型是否可用还须查看 `RELEASE_STATUS.json` 和附带扩展测试，不能只看文件名。

停步后脚底贴地和偏载已有改善，但仍约有5°侧倾；晚压后右脚支撑约74.6%。推后高频腿部运动仍高于旧基线，不能称所有阶段完全无抖动。空手行走、实际抬臂/放箱/模式切换、3–5 kg负载均没有得到本包资格验证。空手阶段只给零速度指令。详见 `validation/extended/scope/CURRENT_RESULTS_ZH.md`。

## 1. 安装到 TA 原本能运行 walking 的环境

现场已确认：Booster K1、aarch64、Python 3.10、ROS Humble。继续使用该环境，不复制 Windows `.venv`，不重装 ROS。

解压后，在包目录执行：

```bash
python3 install.py --deploy-root ~/booster_deploy
cd ~/booster_deploy
python3 scripts/deploy.py --list
python3 -m tasks.team15_carry.check
```

应看到 `k1_team15_carry` 和 `offline_check_passed: true`。检查75→22维输入输出、模型/contract/测试向量、动作滤波和目标限速。以上步骤不发送控制命令。

安装器只新增 `tasks/team15_carry/`，不改官方控制器或其他 task。同名文件完全相同可重复安装；不同则拒绝覆盖。把旧 task 整个移出官方 `tasks` 目录备份后再安装，避免重复注册。不要仅替换 walking 的 ONNX；本包三件模型文件和 task 源码必须一起使用。

对照官方提交：`cecc00fc019de3c640af2d0421059b59a2e080c1`。安装回执记录实际提交和核心源码哈希。原版接口读取 `/low_state.motor_state_serial` 和 IMU，发送 `/joint_ctrl` 的 `CMD_TYPE_SERIAL=1`；本 task 不建立第二个硬件控制发布者。

## 2. 先做只读现场检查

回到解压包目录，在相同 Python/ROS 环境中执行：

```bash
python3 scripts/ta_readonly_preflight.py \
  --deploy-root ~/booster_deploy --benchmark --native-runner \
  --ros-seconds 3 --output preflight_trial01.json
```

核对 cecc 核心源码、模型向量、实际原生 ONNX runner、22关节/IMU数据、接收间隔和已有控制发布者。不会实例化机器人控制器、切换模式或发送电机/RPC命令。输出文件必须不存在。完全离线时省略 `--ros-seconds 3`。

本机 CPU 检查不能代替机器人 ARM64/ROS 的现场结果。推理计时不包含 ROS、调度和电机延迟。详见 [只读检查说明](docs/TA_PREFLIGHT_ZH.md)。

## 3. 录制和启动

先另开相同 ROS 环境终端，在解压包目录运行：

```bash
bash scripts/record_rosbag.sh
```

记录 `/low_state`、`/joint_ctrl`、`/remote_controller_state`、`/rosout`。保留整个 bag；不要在机器人网络回放含控制指令的 bag。

由 TA 沿用上次流程支撑机器人并确认停止方式，然后从官方仓库根目录执行：

```bash
export TEAM15_LOG_DIR="$PWD/logs/team15_carry"
python3 scripts/deploy.py --task k1_team15_carry --device cpu --exit-mode damping
```

- **X / x**：准备到参考姿态，机器人已经会运动。
- **A / r**：启动策略。先保持零速度；空手不发步行指令。
- 放好0.5 kg箱子后，按现场确认的流程缓慢给前进指令。本轮验证速度为0.1 m/s；contract把横向和转向指令上限设为0。不要因程序接受更大前进输入就外推验证范围。
- 空格把速度请求清零，由同一 command filter 限速降至0；不是退出或急停。
- Ctrl+C 请求退出到 damping；damping不保证站立，仍需支撑。实体急停沿用 TA 确认的流程。

程序不自动拿起、放下或识别箱子。仿真从“手臂已抬起、箱子已放好”开始；没有测试现场抬臂、增益切换和放箱动作，不能把空手站立结果当成这些过程已通过。

结束后停止录包并执行 `ros2 bag info <录制目录>`。保存 bag、策略JSONL、`INSTALL_RECEIPT.json`、preflight报告，并记下实际重量、指令、支撑和外力时间。

## 4. 本地复测同一模型

### 带箱

官方 `--mujoco` 默认是纯机器人；本包的带箱入口使用同一 native policy、官方机器人几何及自由箱体：

```bash
python tests/run_carry_sim.py \
  --deploy-root /path/to/booster_deploy \
  --assets-root /path/to/booster_assets \
  --output /path/to/new_evaluation \
  --mass 0.5 --seconds 20 --scenario all --seeds 78660 78661 78662 \
  --velocity 0.1 0 0 --push-n 8 --push-duration 0.3 \
  --press-n 3 --press-duration 1 \
  --qualification-method walking_recovery_window_v3 --video
```

五场景为站立、行走、侧推、压箱、行走同时受扰。8 N和3 N是仿真峰值力，不是已证明的真机承受能力；向下压力不等于改变箱体质量。失败保留原始轨迹，不重置替换。

当前 profile 为 `braced_contact_native_v1`，正式输出是 `qualified_native_braced_evaluation_v3.json`。v3保留原始跟踪误差及关节诊断，用完整1秒窗口区分平均行走/恢复与步态摆动；不是无抖动认证。方法定义见 [评分说明](docs/QUALIFICATION_METHODS_ZH.md)。

`simulation/` 自包含场景和评分，不依赖旧项目包。仍需官方 booster_deploy 与 booster_assets。`trajectory.npz`保存完整原生测量，`trace.npz`供冻结评分器重算；全部原始失败也保留。

### 真正空手

```bash
python tests/run_carry_empty_sim.py \
  --deploy-root /path/to/booster_deploy \
  --assets-root /path/to/booster_assets \
  --output /path/to/new_empty_evaluation \
  --seconds 20 --scenario stand --seeds 78670 78671 78672
```

该场景完全移除箱子，不使用透明或极轻替代物。当前资格仅限空手零指令站立。`--scenario walk`可单独研究空手行走，但本候选尚未验证，不可从托箱结果推断。

## 5. 物理与接口

箱体完整尺寸0.20×0.40×0.12 m、质量0.5 kg，自由刚体，靠真实接触托住，没有焊接、隐形托板或辅助承托力。允许轻靠胸部；两臂向上承力合计至少为参考载荷50%，每侧至少10%，低支撑最多连续6步（0.12秒），并检查稳态分位数。参考载荷为实际mg加施加的向下压力，胸部力单独记录。完整显式接触摩擦是 `[0.7, 0.7, 0.005, 0.0001, 0.0001]`；尚未用真实箱子材料标定。

75维输入：角速度3、重力3、相对关节位置22、关节速度22、上次实际目标对应动作22、速度指令3。没有视觉、箱子位置、滑移或实时重量输入。输出22个关节动作。

ONNX包含归一化；部署按contract执行一次 `clip → 一阶平滑 → 每步限速 → 目标范围投影`，previous action由最终目标逆算。速度指令也按策略步限速；JSONL区分requested与applied command。

JSONL记录策略返回前的目标；实际发布看 `/joint_ctrl`，二者都不代表电机执行确认。原版控制器不会把contract里的effort limit自动变成真实电机力矩保护，也没有本插件新增的独立断流watchdog。关节/IMU含义、控制权和物理限位仍采用现场已验证的官方配置。

## 6. 文件范围

当前包只含一个carry任务、同一个模型、安装/录包/只读检查、自包含仿真、中文步骤及同模型原生证据。`validation/extended/`保存GPU、新seed、晚推压结果和已知限制；它们不混入原生15条通过率。没有附带旧模型的下肢扰动测试来代替新模型验证。

`MANIFEST.json`与receipt核对文件哈希。`RELEASE_STATUS.json`中`hardware_validated`为false。开发侧打包步骤见 [PACKAGING_ZH.md](docs/PACKAGING_ZH.md)；本地维护路径见 [LOCAL_VALIDATION_ZH.md](docs/LOCAL_VALIDATION_ZH.md)，无需复制开发机路径到机器人。
