"""Build a single native carrying handoff with an explicit, evidence-bound status.

No upload, ROS, or robot operation. Failed validated gates create no release.
"""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path,PurePosixPath
import shutil
import sys
import zipfile
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from simulation.qualification import qualify,QUALIFICATION_METHODS
from simulation.empty_qualification import qualify_empty

REFERENCE='cecc00fc019de3c640af2d0421059b59a2e080c1'
SCENARIOS=('stand','walk','push','press','combined')
MODEL_FILES=('policy.onnx','policy.contract.json','policy.test_vectors.npz','export_report.json')
TEST_FILES=('test_native_carry.py','test_command_filter.py','test_install.py','test_carry_protocol.py',
    'test_braced_contacts.py','test_simulation_package.py','test_record_rosbag.py','test_package_release.py',
    'test_empty_carry.py','test_ta_readonly_preflight.py','run_carry_sim.py','run_carry_empty_sim.py')


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def model_check(model_dir):
    for name in MODEL_FILES:
        if not (model_dir/name).is_file():raise ValueError(f'Missing model/export evidence: {name}')
    spec=importlib.util.spec_from_file_location('package_contract',HERE/'tasks/team15_carry/contract.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    contract=module.load_contract(model_dir/'policy.contract.json',model_path=model_dir/'policy.onnx')
    hashes={name:sha(model_dir/name) for name in MODEL_FILES}
    if contract.get('test_vectors_sha256')!=hashes['policy.test_vectors.npz']:
        raise ValueError('Missing or mismatching test-vector SHA-256 in model contract')
    parity=read(model_dir/'export_report.json')
    if (parity.get('passed') is not True or parity.get('onnx_sha256')!=hashes['policy.onnx']
            or parity.get('contract_sha256')!=hashes['policy.contract.json']
            or parity.get('real_robot_validated') is not False or parity.get('real_rollout_vectors',0)<1):
        raise ValueError('Numeric parity report is not passed/bound to these model bytes')
    for name,limit in (('onnx_max_abs_error',1e-4),('target_max_abs_error',1e-5)):
        value=parity.get(name)
        if not isinstance(value,(int,float)) or not math.isfinite(value) or not 0<=value<=limit:
            raise ValueError(f'Export numeric parity failed: {name}')
    import onnxruntime as ort
    session=ort.InferenceSession(str(model_dir/'policy.onnx'),providers=['CPUExecutionProvider'])
    with np.load(model_dir/'policy.test_vectors.npz',allow_pickle=False) as vectors:
        obs=np.asarray(vectors['observations']);actions=np.asarray(vectors['actions'])
    if obs.shape!=(parity.get('count'),75) or actions.shape!=(len(obs),22):
        raise ValueError('Export vector count/shapes differ from numeric parity report')
    if not np.isfinite(obs).all() or not np.isfinite(actions).all():raise ValueError('Nonfinite export vectors')
    predicted=np.concatenate([session.run(None,{session.get_inputs()[0].name:row[None].astype(np.float32)})[0] for row in obs])
    error=float(np.max(np.abs(predicted-actions)))
    if not math.isfinite(error) or error>1e-4:raise ValueError('Fresh ONNX/vector parity failed')
    return contract,hashes,dict(passed=True,vectors=len(obs),onnx_max_abs_error=error,
        export_report_sha256=hashes['export_report.json'],hardware_validated=False)


def command_trace_issues(trace, metadata, contract, *, batched):
    """Recompute requested->applied commands using the exact native limiter."""
    issues=[]
    if metadata.get('command_filter')!=contract.get('command_filter'):
        issues.append('Episode command filter differs from model')
    if 'command_filter' not in contract:
        return issues  # Archived clip-only contracts have no new trace requirement.
    if 'requested_command' not in trace:
        return issues+['Requested command trace missing; applied commands cannot be audited']
    values={k:np.asarray(trace[k])[:,0] if batched else np.asarray(trace[k])
        for k in ('requested_command','command','obs_actor')}
    request,applied,obs=(values[k] for k in ('requested_command','command','obs_actor'))
    if (request.shape!=applied.shape or request.ndim!=2 or request.shape[1]!=3
            or obs.shape!=(len(applied),75) or not all(np.isfinite(v).all() for v in values.values())):
        return issues+['Invalid requested/applied command shapes or nonfinite values']
    spec=importlib.util.spec_from_file_location('package_command_filter',HERE/'tasks/team15_carry/command_filter.py')
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    caps=contract['command_limits'];f=contract['command_filter']
    limiter=module.CommandRateLimiter([-caps['vx_backward'],-caps['vy'],-caps['vyaw']],
        [caps['vx_forward'],caps['vy'],caps['vyaw']],f['max_rate_per_s'],contract['control_dt_s'])
    expected=np.stack([limiter.read(raw,tick).applied for tick,raw in enumerate(request)])
    if not np.allclose(expected,applied,rtol=0,atol=1e-7):issues.append('Applied commands differ from exact per-policy-step replay')
    if not np.allclose(applied,obs[:,-3:],rtol=0,atol=1e-7):issues.append('Actor observation command differs from applied command trace')
    return issues


def inspect_evaluation(directory,hashes,contract,*,stress=False):
    report=read(directory/'report.json');issues=[];episodes=[]
    method=report.get('qualification_method','instantaneous_v1')
    if method not in QUALIFICATION_METHODS:raise ValueError('Unknown native qualification method')
    required={'schema':'team15-native-carry-sim2sim-v1','onnx_sha256':hashes['policy.onnx'],
        'contract_sha256':hashes['policy.contract.json'],'actual_upstream_commit':REFERENCE,
        'hardware_validated':False,'ros_commands_sent':0}
    for key,value in required.items():
        if report.get(key)!=value:issues.append(f'{key} mismatch')
    if report.get('harness_sha256')!=sha(HERE/'tests/run_carry_sim.py'):issues.append('native harness source hash mismatch')
    if report.get('scorer_sha256')!=sha(HERE/'simulation/qualification.py'):issues.append('qualification source hash mismatch')
    expected_task={p.name:sha(p) for p in sorted((HERE/'tasks/team15_carry').glob('*.py'))}
    if report.get('native_task_source_sha256')!=expected_task:issues.append('native task source hashes missing or mismatching')
    declared=report.get('expected_episode_count')
    if declared!=len(report.get('episodes',[])):issues.append('Incomplete or undeclared requested episode count')
    requested={(str(s),int(seed)) for s in report.get('requested_scenarios',[]) for seed in report.get('requested_seeds',[])}
    observed=set()
    for item in report.get('episodes',[]):
        scenario=item.get('scenario');seed=item.get('seed')
        if scenario not in SCENARIOS or not isinstance(seed,int):raise ValueError('Invalid scenario/seed in native report')
        identity=(scenario,seed)
        if identity in observed:issues.append('Duplicate scenario/seed in native report')
        observed.add(identity)
        relative=Path(f'{scenario}_seed{seed}');folder=directory/relative
        evaluation=read(folder/'evaluation.json')
        with np.load(folder/'trace.npz',allow_pickle=False) as archive:trace={k:archive[k] for k in archive.files}
        qualification=qualify(trace,evaluation)
        row=qualification['episodes'][0]
        local=command_trace_issues(trace,evaluation,contract,batched=True)
        if evaluation.get('qualification_method','instantaneous_v1')!=method:local.append('Episode qualification method differs from suite')
        if evaluation.get('num_envs')!=1 or qualification['num_episodes']!=1:local.append('Expected one original episode per native seed')
        if evaluation.get('onnx_sha256')!=hashes['policy.onnx'] or evaluation.get('contract_sha256')!=hashes['policy.contract.json']:
            local.append('Episode model/contract hash missing or mismatching')
        if evaluation.get('action_filter')!=contract['action_filter']:local.append('Episode action filter differs from model')
        if evaluation.get('contact_schema')!=contract.get('contact_schema',{'profile':'strict_forearm_v1'}):local.append('Episode contact schema differs from model')
        expected_moving=scenario in ('walk','combined')
        if row['walking']['requested']!=expected_moving:local.append('Scenario command was not exercised')
        if method in ('walking_window_v2','walking_recovery_window_v3') and expected_moving and not row['stopping']['requested']:
            local.append('Native start-walk-stop protocol did not exercise stopping')
        for key,wanted in (('push',scenario in ('push','combined')),('pressure',scenario in ('press','combined'))):
            if row[key]['requested']!=wanted:local.append(f'{key} scenario was not exercised as declared')
        mass=float(report.get('mass_kg',0))
        if not math.isfinite(mass) or mass<=0:local.append('Invalid reported payload mass')
        if 'actual_payload_mass_kg' in trace and not np.allclose(trace['actual_payload_mass_kg'],mass,rtol=0,atol=1e-6):
            local.append('Measured mass differs from claimed test mass')
        result=dict(source_directory=str(directory),relative_directory=relative.as_posix(),scenario=scenario,seed=seed,
            mass_kg=mass,seconds=float(evaluation['seconds']),stress_only=stress,
            passed=bool(row['combined_qualified'] and not local),issues=local,
            conditions=evaluation.get('conditions',{}),formal_qualification=qualification,
            original_trace_sha256=sha(folder/'trace.npz'),evaluation_sha256=sha(folder/'evaluation.json'))
        episodes.append(result)
    if requested!=observed:issues.append('Requested scenario/seed grid differs from recorded episodes')
    if not episodes:issues.append('No recorded episodes')
    return dict(directory=str(directory),stress_only=stress,qualification_method=method,issues=issues,episodes=episodes,report_sha256=sha(directory/'report.json'))


def inspect_empty_evaluation(directory,hashes,contract):
    report=read(directory/'report.json');issues=[];rows=[]
    required={'schema':'team15-native-empty-carry-suite-v1','no_payload_present':True,
        'onnx_sha256':hashes['policy.onnx'],'contract_sha256':hashes['policy.contract.json'],
        'actual_upstream_commit':REFERENCE,'hardware_validated':False,'ros_commands_sent':0}
    for key,value in required.items():
        if report.get(key)!=value:issues.append(f'{key} mismatch')
    if report.get('harness_sha256')!=sha(HERE/'tests/run_carry_empty_sim.py'):issues.append('empty harness source hash mismatch')
    if report.get('scorer_sha256')!=sha(HERE/'simulation/empty_qualification.py'):issues.append('empty scorer source hash mismatch')
    expected_task={p.name:sha(p) for p in sorted((HERE/'tasks/team15_carry').glob('*.py'))}
    if report.get('native_task_source_sha256')!=expected_task:issues.append('empty task source hashes missing or mismatching')
    if report.get('expected_episodes')!=len(report.get('episodes',[])):issues.append('Incomplete empty-hand suite')
    requested={(str(s),int(seed)) for s in report.get('requested_scenarios',[]) for seed in report.get('requested_seeds',[])}
    seen=set()
    for item in report.get('episodes',[]):
        scenario,seed=item.get('scenario'),item.get('seed')
        if scenario not in ('stand','walk') or not isinstance(seed,int):raise ValueError('Invalid empty-hand scenario/seed')
        if (scenario,seed) in seen:issues.append('Duplicate empty-hand scenario/seed')
        seen.add((scenario,seed));relative=Path(f'{scenario}_seed{seed}');folder=directory/relative
        metadata=read(folder/'metadata.json')
        with np.load(folder/'empty_trace.npz',allow_pickle=False) as archive:trace={k:archive[k] for k in archive.files}
        result=qualify_empty(trace,metadata,item.get('failure'));local=command_trace_issues(trace,metadata,contract,batched=False)
        for key,value in (('no_payload_present',True),('nq',29),('nv',28),('nu',22),('free_joints',1),('equality_constraints',0),
                          ('onnx_sha256',hashes['policy.onnx']),('contract_sha256',hashes['policy.contract.json'])):
            if metadata.get(key)!=value:local.append(f'Empty-hand metadata {key} mismatch')
        if metadata.get('scenario')!=scenario:local.append('Empty scenario metadata mismatch')
        if metadata.get('action_filter')!=contract['action_filter']:local.append('Empty action filter differs from model')
        initial=np.asarray(metadata.get('initial_joint_position',[]))
        if initial.shape!=(22,):local.append('Initial measured joint positions missing')
        else:
            measured_slew=np.diff(np.concatenate([initial[None],trace['target']],axis=0),axis=0)/metadata['control_dt_s']
            if not np.allclose(measured_slew,trace['target_speed_rad_s'],rtol=0,atol=1e-6):local.append('Empty target slew cache mismatch')
        if scenario=='stand' and np.max(abs(trace['command']))>1e-6:local.append('Empty standing requires zero command')
        rows.append(dict(source_directory=str(directory),relative_directory=relative.as_posix(),scenario=scenario,seed=seed,
            seconds=float(metadata['seconds']),passed=bool(result['empty_hand_passed'] and not local),issues=local,
            empty_qualification=result,trace_sha256=sha(folder/'empty_trace.npz'),metadata_sha256=sha(folder/'metadata.json')))
    if requested!=seen:issues.append('Requested empty scenario/seed grid differs from recorded episodes')
    if not rows:issues.append('No empty-hand episodes')
    return dict(directory=str(directory),issues=issues,episodes=rows,report_sha256=sha(directory/'report.json'))


def qualification_gate(evidence,required_masses,*,empty_evidence=(),qualification_method='instantaneous_v1',min_seeds=3,min_seconds=20.,min_push=8.,min_pressure=3.):
    reasons=[];approved=[e for e in evidence if not e['stress_only']]
    if qualification_method not in QUALIFICATION_METHODS:raise ValueError('Unknown release qualification method')
    if not approved:reasons.append('No independent native acceptance evaluation supplied')
    for item in evidence:
        if item.get('qualification_method','instantaneous_v1')!=qualification_method:
            reasons.append(f"{item['directory']}: qualification method differs from selected release method {qualification_method}")
        # Stress failures are retained but must still be linked to the same model.
        for problem in item['issues']:reasons.append(f"{item['directory']}: {problem}")
        for row in item['episodes']:
            if row['issues']:reasons.append(f"{row['relative_directory']}: "+'; '.join(row['issues']))
            if not item['stress_only'] and not row['passed']:reasons.append(f"Failed acceptance episode: {row['relative_directory']}")
    coverage=[]
    for mass in required_masses:
        for scenario in SCENARIOS:
            selected=[r for item in approved for r in item['episodes']
                if abs(r['mass_kg']-mass)<1e-6 and r['scenario']==scenario and r['passed'] and r['seconds']>=min_seconds]
            if scenario in ('push','combined'):
                selected=[r for r in selected if r['conditions'].get('push_n',0)>=min_push and r['conditions'].get('push_duration',0)>=.3]
            if scenario in ('press','combined'):
                selected=[r for r in selected if r['conditions'].get('pressure_n',0)>=min_pressure and r['conditions'].get('pressure_duration',0)>=1.]
            seeds=sorted({r['seed'] for r in selected})
            coverage.append(dict(mass_kg=mass,scenario=scenario,qualified_unique_seeds=seeds,required_unique_seeds=min_seeds))
            if len(seeds)<min_seeds:reasons.append(f'{mass:g} kg/{scenario}: only {len(seeds)} qualifying seeds, need {min_seeds}')
    empty_seeds=set();empty_walk=[]
    for item in empty_evidence:
        for problem in item['issues']:reasons.append(f"Empty {item['directory']}: {problem}")
        for row in item['episodes']:
            if row['issues']:reasons.append(f"Empty {row['relative_directory']}: "+'; '.join(row['issues']))
            if row['scenario']=='stand':
                if not row['passed']:reasons.append(f"Failed empty standing: {row['relative_directory']}")
                elif row['seconds']>=min_seconds:empty_seeds.add(row['seed'])
            else:empty_walk.append(dict(seed=row['seed'],seconds=row['seconds'],passed=row['passed']))
    if len(empty_seeds)<min_seeds:reasons.append(f'Empty standing: only {len(empty_seeds)} qualifying seeds, need {min_seeds}')
    return dict(passed=not reasons,reasons=reasons,coverage=coverage,required_masses_kg=required_masses,
        qualification_method=qualification_method,
        empty_standing_qualified_seeds=sorted(empty_seeds),empty_walking_results=empty_walk,
        empty_walking_required_for_box_carry_release=False,
        min_seconds=min_seconds,min_seeds=min_seeds,min_push_n=min_push,min_pressure_n=min_pressure,
        hardware_validated=False,
        interpretation='Minimum independent simulation integration qualification, not a comprehensive robustness claim; all supplied stress failures are retained separately.')


def allowed_sources():
    files=[HERE/'install.py',HERE/'README_ZH.md',HERE/'package_release.py']
    files+=sorted((HERE/'tasks/team15_carry').glob('*.py'))
    files+=sorted((HERE/'tasks/team15_carry').glob('*.md'))
    files+=sorted((HERE/'simulation').glob('*.py'))
    files+=[HERE/'simulation'/name for name in ('README.md','PROVENANCE.json','EXTRACTION_VALIDATION.json','BRACED_PHYSICS_VALIDATION.json')]
    files+=[HERE/'scripts/record_rosbag.sh',HERE/'config/rosbag_qos.yaml',HERE/'docs/RECORDING_ZH.md',HERE/'docs/PACKAGING_ZH.md',HERE/'docs/LOCAL_VALIDATION_ZH.md',
        HERE/'scripts/ta_readonly_preflight.py',HERE/'scripts/cecc_core_reference.json',HERE/'docs/TA_PREFLIGHT_ZH.md',HERE/'docs/QUALIFICATION_METHODS_ZH.md']
    files+=[HERE/'tests'/name for name in TEST_FILES]
    for path in files:
        if not path.is_file():raise ValueError(f'Missing explicitly selected source file: {path}')
        if path.is_symlink():raise ValueError(f'Symlink source is not allowed: {path}')
    return files


def inspect_supplements(path,contract,hashes):
    """Explicit same-model attachments, never included in acceptance counts."""
    if path is None:return []
    manifest=read(path)
    if manifest.get('schema')!='team15-carry-supplement-v1' or manifest.get('hardware_validated') is not False:
        raise ValueError('Invalid supplemental evidence declaration')
    if (manifest.get('source_checkpoint_sha256')!=contract['source_checkpoint_sha256']
            or manifest.get('onnx_sha256')!=hashes['policy.onnx']):
        raise ValueError('Supplement belongs to another model')
    result=[];destinations=set()
    for group in manifest.get('groups',[]):
        files=[];sources=set()
        for item in group['files']:
            source=Path(item['source'])
            relative=PurePosixPath(item['relative_path'])
            if source.is_symlink() or not source.is_file() or sha(source)!=item['sha256']:
                raise ValueError('Supplement source missing, linked or hash changed')
            if (relative.is_absolute() or '..' in relative.parts or '\\' in str(relative) or ':' in str(relative)
                    or relative.suffix not in ('.json','.jsonl','.npz','.mp4','.png','.txt','.md','.py','.log')):
                raise ValueError('Unsafe or unsupported supplemental destination')
            if str(relative) in destinations:raise ValueError('Duplicate supplemental destination')
            destinations.add(str(relative));sources.add(source.resolve())
            files.append(dict(source=str(source.resolve()),relative_path=str(relative),sha256=item['sha256']))
        identities=group.get('identities',[])
        if not identities or not files:raise ValueError('Each supplement requires model identity and explicit files')
        for identity in identities:
            source=Path(identity['source']).resolve(strict=True)
            if source not in sources:raise ValueError('Identity report must be included in supplemental files')
            value=read(source)
            for key in identity['key_path']:value=value[key]
            if identity['kind']=='checkpoint':expected=contract['source_checkpoint_sha256']
            elif identity['kind']=='onnx':expected=hashes['policy.onnx']
            else:raise ValueError('Unknown supplemental identity kind')
            if value!=expected:raise ValueError('Supplement identity report references another model')
        result.append(dict(name=group['name'],interpretation=group['interpretation'],files=files,
            identities=identities,included_in_acceptance_counts=False,hardware_validated=False))
    return result


def copy_file(source,target):
    if source.is_symlink():raise ValueError(f'Symlink input is not allowed: {source}')
    target.parent.mkdir(parents=True,exist_ok=True)
    with source.open('rb') as a,target.open('xb') as b:shutil.copyfileobj(a,b)
    if sha(source)!=sha(target):raise RuntimeError(f'Copy changed bytes: {source}')


def build(args):
    model_dir=args.model_dir.resolve(strict=True)
    contract,hashes,parity=model_check(model_dir)
    evidence=[inspect_evaluation(p.resolve(strict=True),hashes,contract) for p in args.evaluation_dir]
    evidence += [inspect_evaluation(p.resolve(strict=True),hashes,contract,stress=True) for p in args.stress_dir]
    empty_evidence=[inspect_empty_evaluation(p.resolve(strict=True),hashes,contract) for p in args.empty_evaluation_dir]
    supplements=inspect_supplements(getattr(args,'supplement_manifest',None),contract,hashes)
    gate=qualification_gate(evidence,args.required_mass,empty_evidence=empty_evidence,qualification_method=args.qualification_method)
    if args.mode=='validated' and not gate['passed']:
        raise ValueError('VALIDATED PACKAGE REFUSED:\n'+'\n'.join(gate['reasons']))
    sources=allowed_sources()
    source_hashes={p.relative_to(HERE).as_posix():sha(p) for p in sources}
    # Always generate names ourselves: diagnostic material cannot be named current/validated.
    label='SIM_VALIDATED' if args.mode=='validated' else 'DIAGNOSTIC_NOT_QUALIFIED'
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    name=f'Team15_carry_{label}_{stamp}_{hashes["policy.onnx"][:8]}'
    output=args.output_root.resolve();output.mkdir(parents=True,exist_ok=True)
    stage=output/name;stage.mkdir(exist_ok=False)
    for path in sources:copy_file(path,stage/path.relative_to(HERE))
    for filename in MODEL_FILES:
        destination=(stage/'tasks/team15_carry/models'/filename) if filename!='export_report.json' else stage/'validation/export_report.json'
        copy_file(model_dir/filename,destination)
        if sha(destination)!=hashes[filename]:raise RuntimeError('Model/export evidence changed during packaging; stage retained, ZIP not produced')
    for i,item in enumerate(evidence):
        source=Path(item['directory']);dest=stage/'validation'/f'{i:02d}_{"stress" if item["stress_only"] else "acceptance"}'
        copy_file(source/'report.json',dest/'report.json')
        if sha(dest/'report.json')!=item['report_sha256']:raise RuntimeError('Evaluation report changed during packaging')
        for row in item['episodes']:
            rel=Path(row['relative_directory'])
            for filename in ('evaluation.json','trace.npz','trajectory.npz','report.json','demo.mp4'):
                file=source/rel/filename
                if file.is_file():copy_file(file,dest/rel/filename)
            if sha(dest/rel/'trace.npz')!=row['original_trace_sha256'] or sha(dest/rel/'evaluation.json')!=row['evaluation_sha256']:
                raise RuntimeError('Evaluation trace/metadata changed during packaging')
            (dest/rel/'recomputed_qualification.json').write_text(json.dumps(row['formal_qualification'],indent=2)+'\n',encoding='utf-8')
    for i,item in enumerate(empty_evidence):
        source=Path(item['directory']);dest=stage/'validation'/f'empty_{i:02d}'
        copy_file(source/'report.json',dest/'report.json')
        if sha(dest/'report.json')!=item['report_sha256']:raise RuntimeError('Empty report changed during packaging')
        for row in item['episodes']:
            rel=Path(row['relative_directory'])
            for filename in ('metadata.json','empty_trace.npz','empty_qualification.json','empty_hand_demo.mp4'):
                file=source/rel/filename
                if file.is_file():copy_file(file,dest/rel/filename)
            if sha(dest/rel/'empty_trace.npz')!=row['trace_sha256'] or sha(dest/rel/'metadata.json')!=row['metadata_sha256']:
                raise RuntimeError('Empty trace/metadata changed during packaging')
            (dest/rel/'recomputed_empty_qualification.json').write_text(json.dumps(row['empty_qualification'],indent=2)+'\n')
    for group in supplements:
        for item in group['files']:
            destination=stage/'validation/extended'/item['relative_path']
            copy_file(Path(item['source']),destination)
            if sha(destination)!=item['sha256']:raise RuntimeError('Supplement changed during packaging')
    status=dict(schema='team15-native-release-v1',mode=args.mode,label=label,hardware_validated=False,
        simulation_qualified=args.mode=='validated',qualification_gate=gate,numeric_parity=parity,
        reference_upstream_commit=REFERENCE,model_files_sha256=hashes,source_files_sha256=source_hashes,
        created_utc=datetime.now(timezone.utc).isoformat(),approved_scope=dict(masses_kg=args.required_mass if args.mode=='validated' else [],
            note='Only listed simulation conditions; no hardware or 3–5 kg claim without corresponding evidence.'),
        all_evaluations=evidence,empty_hand_evaluations=empty_evidence,qualification_method=args.qualification_method,
        extended_diagnostics=supplements)
    (stage/'RELEASE_STATUS.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
    banner='仅供诊断，尚未通过托箱行走资格。不要作为已验证版本上真机。' if args.mode=='diagnostic' else '通过列明条件的独立仿真资格；没有真机验证。'
    (stage/'START_HERE_ZH.md').write_text(f'# Team15 原生部署交接\n\n**{banner}**\n\n'
        '唯一任务是 `k1_team15_carry`，使用原版 booster_deploy。\n\n'
        '```bash\npython3 install.py --deploy-root ~/booster_deploy\ncd ~/booster_deploy\n'
        'python3 scripts/deploy.py --list\npython3 -m tasks.team15_carry.check\n```\n\n'
        '这几步不发送控制命令。现场操作、录包和启动顺序见 README_ZH.md；资格范围和全部失败压力测试见 RELEASE_STATUS.json。\n'
        '资格与已知限制以 RELEASE_STATUS.json 及 README_ZH.md 为准；若附带 validation/extended/，其中结果单列，不混入验收通过率，也不代表所有外力都能恢复。\n'
        '通过仿真门槛不等于直线行走、均匀双脚承重或完全无抖动；本包没有真机认证。\n'
        '空手站立和空手行走单列。空手行走未通过时，空手阶段只给零速度指令，不把托箱行走结果外推为空手步态。\n'
        '安装只新增 task，不需要 TA 再手改官方控制器或关节映射。同名旧 task 内容不同会拒绝覆盖，先移到 tasks 外备份。\n',encoding='utf-8')
    manifest={p.relative_to(stage).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(stage.rglob('*')) if p.is_file()}
    (stage/'MANIFEST.json').write_text(json.dumps({'schema':'team15-release-manifest-v1','files':manifest},indent=2)+'\n',encoding='utf-8')
    if any(sha(path)!=source_hashes[path.relative_to(HERE).as_posix()] for path in sources):raise RuntimeError('Source changed during packaging; stage retained, ZIP not produced')
    archive=output/(name+'.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in sorted(stage.rglob('*')):
            if path.is_file():z.write(path,arcname=(Path(name)/path.relative_to(stage)).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise RuntimeError('ZIP integrity failure')
        for rel,item in manifest.items():
            if hashlib.sha256(z.read(name+'/'+rel)).hexdigest()!=item['sha256']:raise RuntimeError('ZIP manifest mismatch')
    receipt=dict(stage=str(stage),zip=str(archive),zip_sha256=sha(archive),mode=args.mode,
        simulation_qualified=status['simulation_qualified'],hardware_validated=False,files=len(manifest)+1)
    (output/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir',type=Path,required=True)
    parser.add_argument('--evaluation-dir',type=Path,action='append',default=[])
    parser.add_argument('--stress-dir',type=Path,action='append',default=[])
    parser.add_argument('--empty-evaluation-dir',type=Path,action='append',default=[])
    parser.add_argument('--supplement-manifest',type=Path,help='Explicit same-model extended diagnostics; excluded from acceptance counts')
    parser.add_argument('--required-mass',type=float,nargs='+',default=[.5])
    parser.add_argument('--mode',choices=['diagnostic','validated'],default='diagnostic')
    parser.add_argument('--qualification-method',choices=QUALIFICATION_METHODS,default='instantaneous_v1')
    parser.add_argument('--output-root',type=Path,default=HERE.parents[1]/'releases')
    args=parser.parse_args()
    if not args.required_mass or any(not math.isfinite(x) or x<=0 for x in args.required_mass):parser.error('Required masses must be finite and positive')
    try:result=build(args)
    except (OSError,ValueError,RuntimeError) as exc:parser.exit(2,str(exc)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
