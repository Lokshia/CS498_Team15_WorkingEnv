"""Native task registry config, with no eager ONNX/ROS session construction."""
from booster_deploy.controllers.controller_cfg import ControllerCfg, MujocoControllerCfg, BoosterRobotControllerCfg, VelocityCommandCfg
from booster_deploy.robots.k1 import K1_CFG
from booster_deploy.utils.isaaclab.configclass import configclass
from .contract import CONTRACT_PATH, MODEL_PATH, load_contract
from .policy import Team15CarryPolicyCfg


@configclass
class Team15CarryControllerCfg(ControllerCfg):
    # Original Portal.run validates prepare_mode BEFORE X preparation. Keep
    # registration available while making absent models ineligible to move.
    robot = K1_CFG.replace(prepare_mode='unavailable_missing_carry_model')
    policy = Team15CarryPolicyCfg()
    policy_dt = .02
    # Disabled placeholders permit --list while a model is being trained.
    # Policy construction requires the real exported contract and model.
    vel_command = VelocityCommandCfg(vx_max=0., vy_max=0., vyaw_max=0.)
    mujoco = MujocoControllerCfg(decimation=4)
    booster = BoosterRobotControllerCfg(exit_mode='damping')

    def __post_init__(self):
        super().__post_init__()
        if not all(path.is_file() for path in (CONTRACT_PATH, MODEL_PATH, MODEL_PATH.with_suffix('.test_vectors.npz'))):
            return
        data = load_contract(model_path=MODEL_PATH)
        self.robot = K1_CFG.replace(
            joint_names=list(data['joint_names']), sim_joint_names=list(data['joint_names']),
            default_joint_pos=list(data['nominal_joint_pos_rad']),
            joint_stiffness=list(data['joint_stiffness']), joint_damping=list(data['joint_damping']),
            effort_limit=list(data['effort_limit']), prepare_mode='standing',
            prepare_state=K1_CFG.prepare_state.replace(joint_pos=list(data['nominal_joint_pos_rad'])),
        )
        limits = data['command_limits']
        self.vel_command = VelocityCommandCfg(vx_max=max(limits['vx_forward'], limits['vx_backward']),
            vx_forward_max=limits['vx_forward'], vx_backward_max=limits['vx_backward'],
            vy_max=limits['vy'], vyaw_max=limits['vyaw'])
        self.mujoco.init_pos = list(data.get('sim_init_pos', [0., 0., .5181737009342727]))
