"""Offline model/contract/filter check. Never imports ROS or publishes commands."""
from pathlib import Path
import json
import numpy as np
from .contract import CONTRACT_PATH, MODEL_PATH, load_contract, sha256, project_action
from .policy import upstream_revision


def main():
    contract = load_contract(CONTRACT_PATH, model_path=MODEL_PATH)
    import onnxruntime as ort
    session = ort.InferenceSession(str(MODEL_PATH), providers=['CPUExecutionProvider'])
    inputs, outputs = session.get_inputs(), session.get_outputs()
    if len(inputs) != 1 or len(outputs) != 1 or inputs[0].shape != [1, 75] or outputs[0].shape != [1, 22]:
        raise ValueError('Expected one [1,75] input and one [1,22] output')
    if inputs[0].type != 'tensor(float)' or outputs[0].type != 'tensor(float)':
        raise ValueError('Expected float32 ONNX tensors')
    vectors_path = MODEL_PATH.with_suffix('.test_vectors.npz')
    if not vectors_path.is_file():
        raise FileNotFoundError(f'Missing export parity vectors: {vectors_path}')
    if contract.get('test_vectors_sha256') is not None and sha256(vectors_path) != contract['test_vectors_sha256']:
        raise ValueError('Test-vector bytes do not match deployment contract')
    with np.load(vectors_path, allow_pickle=False) as vectors:
        observations = np.asarray(vectors['observations'], dtype=np.float32)
        actions = np.asarray(vectors['actions'], dtype=np.float32)
    if observations.ndim != 2 or observations.shape[1] != 75 or actions.shape != (len(observations), 22) or not len(observations):
        raise ValueError('Invalid parity vector dimensions')
    if not np.isfinite(observations).all() or not np.isfinite(actions).all():
        raise ValueError('Nonfinite parity vectors')
    maximum = 0.
    for obs, expected in zip(observations, actions):
        actual = session.run(None, {inputs[0].name:obs[None]})[0][0]
        if not np.isfinite(actual).all():
            raise ValueError('Nonfinite model output')
        maximum = max(maximum, float(np.max(np.abs(actual - expected))))
    if maximum > 1e-4:
        raise ValueError(f'Export parity failed: max absolute error {maximum}')
    target, effective = project_action(np.ones(22)*1e6, np.zeros(22), contract)
    limit = np.asarray(contract['action_filter']['max_target_speed_rad_s']) * contract['control_dt_s']
    if np.any(np.abs(target - np.asarray(contract['nominal_joint_pos_rad'])) > limit + 1e-6):
        raise ValueError('Target slew-limit check failed')
    report = {'offline_check_passed':True, **upstream_revision(), 'test_vectors':len(observations),
        'max_absolute_error':maximum, 'observation_dim':75, 'action_dim':22,
        'onnx_sha256':sha256(MODEL_PATH), 'contract_sha256':sha256(CONTRACT_PATH),
        'no_vision':True, 'no_payload_state_input':True, 'action_filter':contract['action_filter'],
        'command_limits':contract['command_limits'], 'hardware_validated':False,
        'limitations':'Export and task contract only; not stability or hardware certification.'}
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (FileNotFoundError, ValueError) as exc:
        print(json.dumps({'offline_check_passed':False, 'error':str(exc), **upstream_revision()}, indent=2))
        raise SystemExit(2)
