"""Per-policy-step command slew limiting; no ROS, actuators, or policy I/O.

Tick 0 after reset observes zero. Later ticks are sequential successful policy
steps, not calls to compute_observation. Re-reading a tick returns its latched
request and result. Rates use nominal policy dt; this is not a scheduler watchdog.
"""
from dataclasses import dataclass
import numbers
import numpy as np


@dataclass(frozen=True)
class CommandSample:
    tick: int
    requested: np.ndarray
    clipped: np.ndarray
    applied: np.ndarray


class CommandRateLimiter:
    def __init__(self, lower, upper, rates, dt):
        self.lower = np.asarray(lower, dtype=np.float64)
        self.upper = np.asarray(upper, dtype=np.float64)
        self.rates = np.asarray(rates, dtype=np.float64)
        self.dt = float(dt)
        if any(v.shape != (3,) or not np.isfinite(v).all()
               for v in (self.lower, self.upper, self.rates)):
            raise ValueError('Expected three finite axis values')
        if not np.isfinite(self.dt) or self.dt <= 0:
            raise ValueError('Policy dt must be positive and finite')
        if np.any(self.lower > 0) or np.any(self.upper < 0):
            raise ValueError('Every command range must contain reset zero')
        if np.any(self.lower > self.upper) or np.any(self.rates < 0):
            raise ValueError('Invalid command range/rate')
        enabled = self.upper > self.lower
        if np.any(enabled & (self.rates <= 0)):
            raise ValueError('Enabled command axes need positive slew rates')
        self.reset()

    def reset(self):
        self._tick = None
        self._value = np.zeros(3, dtype=np.float64)
        self._sample = None

    def read(self, requested, tick):
        if not isinstance(tick, numbers.Integral) or tick < 0:
            raise ValueError('Tick must be a nonnegative policy-step integer')
        request = np.asarray(requested, dtype=np.float64)
        if request.shape != (3,) or not np.isfinite(request).all():
            raise ValueError('Velocity request must contain three finite values')
        if self._tick == tick:
            # First read wins, including telemetry. A mid-tick remote change is
            # sampled next tick, rather than modifying the model observation.
            return self._copy()
        expected = 0 if self._tick is None else self._tick + 1
        if tick != expected:
            raise ValueError('Expected the next policy tick; no catch-up updates')
        clipped = np.clip(request, self.lower, self.upper)
        if tick != 0:
            delta = np.clip(clipped - self._value, -self.rates * self.dt,
                            self.rates * self.dt)
            self._value = np.clip(self._value + delta, self.lower, self.upper)
        self._tick = int(tick)
        self._sample = CommandSample(self._tick, request.copy(), clipped.copy(),
                                     self._value.copy())
        return self._copy()

    def _copy(self):
        s = self._sample
        return CommandSample(s.tick, s.requested.copy(), s.clipped.copy(), s.applied.copy())

