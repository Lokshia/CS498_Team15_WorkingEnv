"""Register one native command-conditioned, no-vision carrying task."""
from booster_deploy.utils.registry import register_task
from .contract import TASK_NAME
from .task import Team15CarryControllerCfg
register_task(TASK_NAME, Team15CarryControllerCfg())
