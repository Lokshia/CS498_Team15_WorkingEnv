"""No-vision 75-input policy for the unmodified booster_deploy controller."""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time
import uuid
import numpy as np
import torch

from booster_deploy.controllers.base_controller import Policy
from booster_deploy.controllers.controller_cfg import PolicyCfg
from booster_deploy.utils.isaaclab import math as lab_math
from booster_deploy.utils.isaaclab.configclass import configclass
from booster_deploy.utils.policy_runner import create_policy_runner
from .contract import JOINT_NAMES, REFERENCE_UPSTREAM_COMMIT, load_contract, project_action, sha256
from .command_filter import CommandRateLimiter


def upstream_revision():
    import booster_deploy.controllers.base_controller as base
    root = Path(base.__file__).resolve().parents[2]
    try:
        actual = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'],
            text=True, stderr=subprocess.DEVNULL).strip()
    except (OSError, subprocess.CalledProcessError):
        actual = None
    return {'reference_upstream_commit': REFERENCE_UPSTREAM_COMMIT,
            'actual_upstream_commit': actual, 'upstream_root': str(root)}


class Team15CarryPolicy(Policy):
    def __init__(self, cfg, controller):
        super().__init__(cfg, controller)
        path = Path(cfg.checkpoint_path)
        self.model_path = path if path.is_absolute() else Path(self.task_path) / path
        self.contract_path = self.model_path.with_suffix('.contract.json')
        self.contract = load_contract(self.contract_path, model_path=self.model_path)
        self.robot = controller.robot
        self.device = torch.device(cfg.device)
        self.robot.data.to(self.device)
        names = list(self.robot.cfg.joint_names)
        if len(names) != 22 or len(set(names)) != 22 or set(names) != set(JOINT_NAMES):
            raise ValueError('Expected exactly the 22 canonical K1 serial joints')
        self.permutation = [names.index(name) for name in JOINT_NAMES]
        self.nominal = np.asarray(self.contract['nominal_joint_pos_rad'], dtype=np.float32)
        self.scale = np.asarray(self.contract['action_scale_rad'], dtype=np.float32)
        if not np.isclose(controller.cfg.policy_dt, self.contract['control_dt_s'], atol=1e-9, rtol=0):
            raise ValueError('Controller policy dt differs from training contract')
        for contract_key, cfg_key in [('nominal_joint_pos_rad', 'default_joint_pos'),
                ('joint_stiffness', 'joint_stiffness'), ('joint_damping', 'joint_damping'), ('effort_limit', 'effort_limit')]:
            values = np.asarray(getattr(self.robot.cfg, cfg_key))[self.permutation]
            if not np.allclose(values, self.contract[contract_key], atol=1e-6, rtol=0):
                raise ValueError(f'Task {cfg_key} differs from model contract')
        if controller.vel_command is None:
            raise ValueError('Carrying policy requires native velocity commands')
        self.runner = create_policy_runner(str(self.model_path), self.device, use_actor_module=False)
        self.last_action = np.zeros(22, dtype=np.float32)
        self._log = None
        self._ready = False
        self._step = 0
        self.command = np.zeros(3, dtype=np.float32)
        self.requested_command = self.command.copy()
        self.clipped_command = self.command.copy()
        self._command_limiter = None
        if 'command_filter' in self.contract:
            caps = self.contract['command_limits']
            self._command_limiter = CommandRateLimiter(
                [-caps['vx_backward'], -caps['vy'], -caps['vyaw']],
                [caps['vx_forward'], caps['vy'], caps['vyaw']],
                self.contract['command_filter']['max_rate_per_s'], self.contract['control_dt_s'])

    def close(self):
        if self._log is not None:
            self._log.close()
            self._log = None

    def _write(self, row):
        if self._log is not None:
            self._log.write(json.dumps(dict(row, wall_time_ns=time.time_ns(), monotonic_s=time.monotonic()),
                allow_nan=False, separators=(',', ':')) + '\n')
            self._log.flush()

    def _fault(self, error):
        self._ready = False
        try:
            self._write({'event':'fault', 'step':self._step, 'error':str(error)})
        finally:
            try:
                self.close()
            finally:
                self.controller.stop()

    def _state(self):
        data = self.robot.data
        for value, size in [(data.root_ang_vel_b, 3), (data.root_quat_w, 4),
                            (data.joint_pos, 22), (data.joint_vel, 22)]:
            if tuple(value.shape) != (size,) or not torch.isfinite(value).all():
                raise ValueError('Invalid/nonfinite K1 state')
        quaternion = data.root_quat_w.to(self.device)
        if abs(float(torch.linalg.vector_norm(quaternion)) - 1) > .001:
            raise ValueError('Expected normalized wxyz quaternion')
        gravity = lab_math.quat_apply_inverse(quaternion, torch.tensor([0., 0., -1.], device=self.device))
        if float(gravity[2]) > -np.cos(np.deg2rad(self.cfg.max_trunk_tilt_deg)):
            raise RuntimeError('Trunk tilt exceeds task stop threshold')
        q = data.joint_pos.detach().cpu().numpy()[self.permutation]
        dq = data.joint_vel.detach().cpu().numpy()[self.permutation]
        gyro = data.root_ang_vel_b.detach().cpu().numpy()
        return gyro, gravity.detach().cpu().numpy(), q, dq

    def _commands(self):
        cmd = self.controller.vel_command
        requested = np.asarray([cmd.lin_vel_x, cmd.lin_vel_y, cmd.ang_vel_yaw], dtype=np.float32)
        if not np.isfinite(requested).all():
            raise ValueError('Nonfinite velocity command')
        caps = self.contract['command_limits']
        limited = np.clip(requested, [-caps['vx_backward'], -caps['vy'], -caps['vyaw']],
                          [caps['vx_forward'], caps['vy'], caps['vyaw']]).astype(np.float32)
        if self._command_limiter is not None:
            sample = self._command_limiter.read(requested, self._step)
            self.requested_command = sample.requested.astype(np.float32)
            self.clipped_command = sample.clipped.astype(np.float32)
            self.command = sample.applied.astype(np.float32)
        else:
            self.requested_command, self.clipped_command, self.command = requested, limited.copy(), limited
        return self.command

    def reset(self):
        self.close()
        self._ready = False
        self._step = 0
        self.command = np.zeros(3, dtype=np.float32)
        self.requested_command = self.command.copy()
        self.clipped_command = self.command.copy()
        if self._command_limiter is not None:
            self._command_limiter.reset()
        try:
            _, _, q, _ = self._state()
            if np.max(np.abs(q - self.nominal)) > self.cfg.start_pose_tolerance_rad:
                raise ValueError('Initial pose is outside carrying start-pose tolerance')
            ranges = np.asarray(self.contract['target_ranges_rad'])
            if np.any(q < ranges[:, 0]) or np.any(q > ranges[:, 1]):
                raise ValueError('Initial joint state lies outside target bounds')
            # First filtered target starts from the measured pose, not a jump
            # to nominal. This effective previous action is also observed.
            self.last_action = ((q - self.nominal) / self.scale).astype(np.float32)
            directory = Path(os.environ.get('TEAM15_LOG_DIR', 'logs/team15_carry'))
            directory.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
            self.log_path = directory / f'inference_{stamp}_{os.getpid()}_{uuid.uuid4().hex[:8]}.jsonl'
            self._log = self.log_path.open('x', encoding='utf-8')
            self._write({'event':'session', 'schema':'team15-native-carry-log-v1', **upstream_revision(),
                'onnx_sha256':sha256(self.model_path), 'contract_sha256':sha256(self.contract_path),
                'contract':self.contract, 'initial_effective_action':self.last_action.tolist(),
                'state_receive_age_available':False, 'hardware_validated':False,
                'log_semantics':'Targets returned before upstream publication, not actuator acknowledgment',
                'prepare_stiffness':list(self.robot.cfg.prepare_state.stiffness),
                'prepare_damping':list(self.robot.cfg.prepare_state.damping),
                'exit_mode':self.controller.cfg.booster.exit_mode})
            self._ready = True
        except Exception as exc:
            self._fault(exc)
            raise

    def compute_observation(self):
        gyro, gravity, q, dq = self._state()
        observation = np.concatenate((gyro, gravity, q - self.nominal, dq, self.last_action, self._commands())).astype(np.float32)
        if observation.shape != (75,) or not np.isfinite(observation).all():
            raise ValueError('Expected exactly 75 finite observations')
        return torch.from_numpy(observation).to(self.device)

    def inference(self):
        try:
            if not self._ready:
                raise RuntimeError('Call policy.reset before inference')
            obs = self.compute_observation()
            with torch.inference_mode():
                output = self.runner(obs.unsqueeze(0))
            if tuple(output.shape) != (1, 22):
                raise ValueError('Expected model output float32[1,22]')
            raw = output[0].detach().cpu().numpy().copy()
            previous = self.last_action.copy()
            target, self.last_action = project_action(raw, previous, self.contract)
            controller_target = np.empty(22, dtype=np.float32)
            controller_target[self.permutation] = target
            self._step += 1
            self._write({'event':'inference', 'step':self._step, 'observation':obs.detach().cpu().tolist(),
                'requested_command':self.requested_command.tolist(), 'command':self.command.tolist(),
                'clipped_command':self.clipped_command.tolist(), 'command_tick':self._step-1,
                'raw_action':raw.tolist(), 'effective_action':self.last_action.tolist(),
                'target_controller_order_rad':controller_target.tolist()})
            return torch.from_numpy(controller_target).to(self.device)
        except Exception as exc:
            self._fault(exc)
            raise


@configclass
class Team15CarryPolicyCfg(PolicyCfg):
    constructor = Team15CarryPolicy
    checkpoint_path: str = 'models/policy.onnx'
    start_pose_tolerance_rad: float = .25
    max_trunk_tilt_deg: float = 45.
