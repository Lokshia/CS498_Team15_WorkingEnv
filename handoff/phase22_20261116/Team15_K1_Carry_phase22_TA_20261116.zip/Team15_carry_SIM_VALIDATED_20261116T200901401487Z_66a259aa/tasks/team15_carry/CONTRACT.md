# Carry deployment export schema

Generated model files: `models/policy.onnx`, `models/policy.contract.json`, `models/policy.test_vectors.npz`.

`contract.py::validate_contract` is the executable schema. Required fields:

- `schema`: `team15-carry-deployment-v1`
- `observation_dim`: 75; `action_dim`: 22; `history_frames`: 1
- `observation_order`: `["body_angular_velocity", "projected_gravity", "joint_position_relative", "joint_velocity", "previous_effective_action", "velocity_command"]`
- `joint_names`: the 22 official serial K1 names in `contract.JOINT_NAMES`
- `normalization_included: true`, `action_scale_included: false`, `default_joint_offset_included: false`
- `no_vision: true`, `actor_uses_payload_state: false`; `control_dt_s`: 0.02
- 22-element lists: `nominal_joint_pos_rad`, `action_scale_rad`, `joint_stiffness`, `joint_damping`, `effort_limit`
- `target_ranges_rad`: 22 [lower, upper] radian pairs
- `command_limits`: nonnegative `vx_forward`, `vx_backward`, `vy`, `vyaw` in m/s, m/s, m/s, rad/s
- `action_clip`: positive normalized limit; `previous_action`: `effective`; `project_joint_targets`: true
- `action_filter`: `{ "type": "first_order_and_slew", "alpha": <0..1>, "max_target_speed_rad_s": <22 positive values> }`
- Real hashes: `onnx_sha256`, `source_checkpoint_sha256`
- Recommended: `test_vectors_sha256`, `sim_init_pos`, experiment/seed/budget and tested conditions.

Clip raw actions, apply `old_target + alpha*(requested_target-old_target)`, limit increment to `speed*dt`, then project to bounds. Feed `(final_target-nominal)/scale` back. At reset, `old_target` is measured joint pose. Training must match. ONNX must not filter again.

NPZ keys: `observations: float32[N,75]`, `actions: float32[N,22]`, reference actor outputs before target filtering. Include nonzero commands and disturbed observations. These vectors do not replace trajectory tests.

Configured `effort_limit` is a simulation parameter. Original real `ctrl_step` sends q/kp/kd, so it is not a guaranteed motor-side torque cap.

Contact profiles are explicit and are never inferred from a filename:

- Archived `strict_forearm_v1`: bilateral forearm support, no chest brace.
- Archived `braced_contact_v1` / schema 1: training cylinder plus end sphere per arm maps to the original native forearm mesh; training torso maps to the two official chest colliders.
- `braced_contact_native_v1` / schema 2: `geometry_source: official_k1_mesh`; each training arm contains exactly `side_hand_collision`, with `trunk_collision` and `trunk_lower_collision` as separate allowed brace geoms. No end sphere is created or required. The model records actual `native_deploy` physics, source XML and mesh hashes, and actual explicit pair material metadata.

Both braced profiles require actual upward force on each arm, total arm reference-load share >=0.5 and each side >=0.1, with at most six 50 Hz control intervals below support limits. The reference is actual payload mg plus applied downward pressure. Chest force is measured separately. Box attachment remains `free_body_no_weld_no_assistive_force`.

For schema 2, the actual MuJoCo explicit-pair friction vector is **[0.7, 0.7, 0.005, 0.0001, 0.0001]**, ordered tangent-1, tangent-2, torsional, rolling-1, rolling-2. It is not a three-component geom friction vector. The native scene validates source asset hashes and preserves the original physical geometry. Shared source geometry still does not prove GPU/CPU trajectory equivalence or real-robot success.

New exports first verify the exact raw training XML bytes, then add `physical_mapping.source_xml_canonical_sha256` and `source_xml_canonicalization: CRLF_to_LF_only`. This allows equivalent Windows CRLF/Linux LF checkouts without ignoring XML values, whitespace, or missing final newlines. The original raw SHA remains unchanged in training metadata and the mapping. Archived contracts without a canonical hash remain raw-strict. Mesh SHA-256 checks never normalize bytes. A relocated training XML can be supplied to the exporter with `--source-asset-xml`; it must still match the recorded raw hash.
