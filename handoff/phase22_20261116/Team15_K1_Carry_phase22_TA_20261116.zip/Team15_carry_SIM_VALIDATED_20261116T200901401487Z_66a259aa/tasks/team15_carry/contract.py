"""Model-side deployment contract. Importing this module never starts ROS."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import numpy as np

TASK_NAME = 'k1_team15_carry'
REFERENCE_UPSTREAM_COMMIT = 'cecc00fc019de3c640af2d0421059b59a2e080c1'
CONTRACT_PATH = Path(__file__).parent / 'models' / 'policy.contract.json'
MODEL_PATH = Path(__file__).parent / 'models' / 'policy.onnx'
JOINT_NAMES = (
    'aahead_yaw_joint', 'aahead_pitch_joint',
    'aaleft_shoulder_pitch_joint', 'left_shoulder_roll_joint', 'left_elbow_pitch_joint', 'left_elbow_yaw_joint',
    'aaright_shoulder_pitch_joint', 'right_shoulder_roll_joint', 'right_elbow_pitch_joint', 'right_elbow_yaw_joint',
    'left_hip_pitch_joint', 'left_hip_roll_joint', 'left_hip_yaw_joint', 'left_knee_pitch_joint', 'left_ankle_pitch_joint', 'left_ankle_roll_joint',
    'right_hip_pitch_joint', 'right_hip_roll_joint', 'right_hip_yaw_joint', 'right_knee_pitch_joint', 'right_ankle_pitch_joint', 'right_ankle_roll_joint',
)
OBSERVATION_ORDER = ['body_angular_velocity', 'projected_gravity', 'joint_position_relative',
                     'joint_velocity', 'previous_effective_action', 'velocity_command']


def validate_contact_contract(data):
    """Missing contact metadata denotes the archived strict-forearm contract."""
    contact=data.get('contact_schema')
    if contact is None:
        return 'strict_forearm_v1'
    profile=contact.get('profile')
    if profile not in ('strict_forearm_v1','braced_contact_v1','braced_contact_native_v1'):
        raise ValueError(f'Unknown contact_schema.profile: {profile!r}')
    if contact.get('max_support_gap_steps')!=6 or contact.get('support_force_threshold_n')!=1e-6:
        raise ValueError('Contact schema must retain six-step grace and measured upward support')
    expected={'left':['left_hand_collision'],'right':['right_hand_collision']}
    if profile in ('braced_contact_v1','braced_contact_native_v1'):
        native=profile=='braced_contact_native_v1'
        expected={side:[f'{side}_hand_collision'] if native else
                  [f'{side}_hand_collision',f'{side}_hand_end_collision'] for side in ('left','right')}
        braces=['trunk_collision','trunk_lower_collision'] if native else ['trunk_collision']
        if (contact.get('schema_version')!=(2 if native else 1) or contact.get('brace_geoms')!=braces
                or contact.get('min_total_support_fraction')!=.5
                or contact.get('min_per_arm_support_fraction')!=.1
                or contact.get('payload_attachment')!='free_body_no_weld_no_assistive_force'):
            raise ValueError('Unsupported braced contact/support-share definition')
        if native and contact.get('geometry_source')!='official_k1_mesh':
            raise ValueError('Native contact schema requires official_k1_mesh geometry')
        payload=data.get('payload_configuration',{})
        half=np.asarray(payload.get('half_size_m'),dtype=float)
        if half.shape!=(3,) or not np.isfinite(half).all() or (half<=0).any():
            raise ValueError('Braced payload_configuration requires positive half_size_m')
        physical=data.get('training_physical_contract',{})
        materials=physical.get('effective_payload_contact_materials',{})
        if native and physical.get('physics_profile')!='native_deploy':
            raise ValueError('Native contact schema requires actual native_deploy training physics')
        if native:
            audit=physical.get('native_physics_audit') or {}
            digest=audit.get('source_xml_sha256','')
            meshes=audit.get('meshes')
            if len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest) or not isinstance(meshes,list) or not meshes:
                raise ValueError('Native physics needs source XML and mesh provenance')
            for mesh in meshes:
                digest=mesh.get('sha256','')
                if len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest) or not mesh.get('relative_path'):
                    raise ValueError('Incomplete native mesh provenance')
            mapping=data.get('physical_mapping') or {}
            canonical=mapping.get('source_xml_canonical_sha256')
            if canonical is not None:
                if (len(canonical)!=64 or any(c not in '0123456789abcdef' for c in canonical)
                        or mapping.get('source_xml_canonicalization')!='CRLF_to_LF_only'
                        or mapping.get('source_xml_sha256')!=audit['source_xml_sha256']):
                    raise ValueError('Invalid canonical XML provenance; raw training provenance must be retained')
        wanted=[.7,.7,.005,.0001,.0001] if native else [.7,.005,.0001]
        for name in [*expected['left'],*expected['right'],*braces]:
            pair=materials.get('robot/'+name,{})
            friction=np.asarray(pair.get('friction'),dtype=float)
            if friction.shape!=(len(wanted),) or not np.allclose(friction,wanted,rtol=0,atol=1e-12):
                raise ValueError(f'Missing or unsupported measured training material: {name}')
            if native and (pair.get('source')!='explicit MuJoCo pair' or pair.get('condim')!=3
                    or pair.get('friction_components')!=['tangent_1','tangent_2','torsional','rolling_1','rolling_2']
                    or pair.get('solref')!=[.0105,1.] or pair.get('solimp')!=[.9,.95,.001,.5,2.]):
                raise ValueError(f'Native explicit pair metadata mismatch: {name}')
    elif contact.get('brace_geoms')!=[]:
        raise ValueError('Strict forearm schema cannot allow a chest brace')
    if contact.get('support_groups')!=expected:
        raise ValueError('Training support geometry groups do not match the native physical mapping')
    return profile


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical_xml_sha256(raw):
    """Only platform line-ending normalization. Do not strip or reserialize XML."""
    return hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()


def vector(data, key, length=22, *, positive=False, nonnegative=False):
    value = np.asarray(data.get(key), dtype=np.float64)
    if value.shape != (length,) or not np.isfinite(value).all():
        raise ValueError(f'{key}: expected {length} finite numbers')
    if positive and np.any(value <= 0) or nonnegative and np.any(value < 0):
        raise ValueError(f'{key}: invalid sign')
    return value


def command_filter_for_training(meta, caps):
    """Document the maximum rate in this task's actual linear command ramps."""
    if meta.get('task_schema') != 'k1-proprio-command-carry-v1':
        raise ValueError('Cannot infer command ramp from an unknown training task')
    conditions = meta['conditions']
    # This schema's command() uses an explicit one-second start ramp.
    stop = (float(conditions['command_stop_ramp_s'])
            if conditions.get('command_stop_time_s') is not None else None)
    durations = [1.] + ([] if stop is None else [stop])
    if not all(np.isfinite(x) and x > 0 for x in durations):
        raise ValueError('Invalid recorded training command ramp duration')
    fastest = min(durations)
    return dict(type='policy_step_slew_v1',
        max_rate_per_s=[max(caps['vx_forward'],caps['vx_backward'])/fastest,
                        caps['vy']/fastest,caps['vyaw']/fastest],
        rate_units=['m/s^2','m/s^2','rad/s^2'], update_period_s=float(meta['control_dt_s']),
        initial_command=[0.,0.,0.], reset_policy='zero',
        duplicate_step_policy='first_request_latched', initial_tick_policy='zero',
        source='training_max_command_over_ramp_duration',
        training_ramp_duration_s=dict(start=1.,stop=stop))


def validate_command_filter(data):
    # An absent field is the explicitly retained legacy clip-only behavior.
    if 'command_filter' not in data:
        return
    f = data['command_filter']
    if not isinstance(f,dict):
        raise ValueError('command_filter must be an explicit configuration')
    expected = dict(type='policy_step_slew_v1',rate_units=['m/s^2','m/s^2','rad/s^2'],
        initial_command=[0.,0.,0.],reset_policy='zero',initial_tick_policy='zero',
        duplicate_step_policy='first_request_latched',
        source='training_max_command_over_ramp_duration')
    for key,value in expected.items():
        if f.get(key) != value:
            raise ValueError(f'Unsupported command_filter.{key}')
    if not np.isclose(f.get('update_period_s',0),data['control_dt_s'],rtol=0,atol=1e-10):
        raise ValueError('Command limiter must use the policy control period')
    duration=f.get('training_ramp_duration_s',{})
    start,stop=duration.get('start'),duration.get('stop')
    if start != 1. or (stop is not None and
        (not isinstance(stop,(int,float)) or not np.isfinite(stop) or stop<=0)):
        raise ValueError('Invalid command ramp provenance')
    fastest=min(start,stop) if stop is not None else start
    caps=data['command_limits']
    expected_rate=np.array([max(caps['vx_forward'],caps['vx_backward']),caps['vy'],caps['vyaw']])/fastest
    rates=vector(f,'max_rate_per_s',length=3,nonnegative=True)
    if not np.allclose(rates,expected_rate,rtol=0,atol=1e-12):
        raise ValueError('Command rates must match recorded training ramp and limits')


def validate_contract(data):
    required = {
        'schema': 'team15-carry-deployment-v1', 'observation_dim': 75, 'action_dim': 22,
        'observation_order': OBSERVATION_ORDER, 'joint_names': list(JOINT_NAMES),
        'normalization_included': True, 'action_scale_included': False,
        'default_joint_offset_included': False, 'no_vision': True,
        'actor_uses_payload_state': False, 'history_frames': 1,
    }
    for key, expected in required.items():
        if data.get(key) != expected:
            raise ValueError(f'Incompatible contract {key}: {data.get(key)!r}')
    if not np.isclose(data.get('control_dt_s', 0), .02, atol=1e-10, rtol=0):
        raise ValueError('This task requires 50 Hz control')
    for key in ('nominal_joint_pos_rad', 'action_scale_rad', 'joint_stiffness', 'joint_damping', 'effort_limit'):
        vector(data, key, positive=key in ('action_scale_rad', 'effort_limit'),
               nonnegative=key in ('joint_stiffness', 'joint_damping'))
    bounds = np.asarray(data.get('target_ranges_rad'), dtype=np.float64)
    if bounds.shape != (22, 2) or not np.isfinite(bounds).all() or np.any(bounds[:, 0] >= bounds[:, 1]):
        raise ValueError('Expected 22 finite increasing target ranges')
    nominal = vector(data, 'nominal_joint_pos_rad')
    if np.any(nominal < bounds[:, 0]) or np.any(nominal > bounds[:, 1]):
        raise ValueError('Nominal pose must be inside target ranges')
    caps = data.get('command_limits', {})
    for key in ('vx_forward', 'vx_backward', 'vy', 'vyaw'):
        value = caps.get(key)
        if not isinstance(value, (int, float)) or not np.isfinite(value) or value < 0:
            raise ValueError(f'Missing/invalid command_limits.{key}')
    validate_command_filter(data)
    processing = data.get('action_filter', {})
    if data.get('previous_action') != 'effective' or data.get('project_joint_targets') is not True:
        raise ValueError('Requires effective previous action and target projection')
    if processing.get('type') != 'first_order_and_slew':
        raise ValueError('Expected first_order_and_slew action filter')
    clip = data.get('action_clip')
    alpha = processing.get('alpha')
    if not isinstance(clip, (int, float)) or not np.isfinite(clip) or clip <= 0:
        raise ValueError('action_clip must be positive')
    if not isinstance(alpha, (int, float)) or not np.isfinite(alpha) or not 0 < alpha <= 1:
        raise ValueError('action_filter.alpha must be in (0,1]')
    vector(processing, 'max_target_speed_rad_s', positive=True)
    for key in ('onnx_sha256', 'source_checkpoint_sha256'):
        value = data.get(key, '')
        if len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
            raise ValueError(f'Missing/invalid {key}')
    validate_contact_contract(data)
    return data


def load_contract(path=CONTRACT_PATH, *, model_path=None):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f'Carry model is not exported yet: missing {path}')
    data = validate_contract(json.loads(path.read_text(encoding='utf-8')))
    if model_path is not None:
        model_path = Path(model_path)
        if not model_path.is_file():
            raise FileNotFoundError(f'Carry model is not exported yet: missing {model_path}')
        if sha256(model_path) != data['onnx_sha256']:
            raise ValueError('ONNX bytes do not match deployment contract')
    return data


def project_action(raw, previous_effective, data):
    """Exact portable processing: clip -> EMA -> target delta -> XML projection.

    Reset previous_effective from measured q: (q - nominal) / scale. EMA uses
    that effective state rather than unobserved filter history. Returns target
    and new state. ONNX must not contain a second filter.
    """
    raw = np.asarray(raw, dtype=np.float64)
    previous = np.asarray(previous_effective, dtype=np.float64)
    if raw.shape != (22,) or previous.shape != (22,) or not np.isfinite(raw).all() or not np.isfinite(previous).all():
        raise ValueError('Expected finite 22-dimensional actions')
    p = data['action_filter']
    nominal = np.asarray(data['nominal_joint_pos_rad'])
    scale = np.asarray(data['action_scale_rad'])
    action = p['alpha'] * np.clip(raw, -data['action_clip'], data['action_clip']) + (1 - p['alpha']) * previous
    target = nominal + action * scale
    old_target = nominal + previous * scale
    delta = np.asarray(p['max_target_speed_rad_s']) * data['control_dt_s']
    target = np.clip(target, old_target - delta, old_target + delta)
    bounds = np.asarray(data['target_ranges_rad'])
    target = np.clip(target, bounds[:, 0], bounds[:, 1])
    return target.astype(np.float32), ((target - nominal) / scale).astype(np.float32)
